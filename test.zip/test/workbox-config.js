const { injectManifest } = require('workbox-build');

injectManifest({
  swSrc: 'src/sw-template.js', // Your custom Service Worker template
  swDest: 'dist/service-worker.js',
  globDirectory: 'dist/',
  globPatterns: ['**/*.{js,css,json,svg,png,jpg,gif}'],
  maximumFileSizeToCacheInBytes: 100 * 1024 * 1024, // 100 MB
}).then(({ count, size }) => {
  console.log(`Generated service-worker.js, which will precache ${count} files, totaling ${size} bytes.`);
}).catch(err => {
  console.error('Service worker generation failed:', err);
});
