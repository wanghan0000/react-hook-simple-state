/**
 * 用于生成（Service workers）版本比对的脚本
 * 将.env的环境变量注入
 */

const fs = require('fs')
const dotenv = require('dotenv')
const path = require('path')

// Get the environment from the command line arguments
const environment = process.argv[2] || 'development'

// Determine the path to the .env file based on the environment
const envFilePath = path.resolve(__dirname, `../.env.${environment}`)

console.log('envFilePath', envFilePath)
// Load environment variables from the specified .env file
dotenv.config({ path: envFilePath })

console.log('REACT_APP_VERSION', process.env.REACT_APP_VERSION)
// Get the version from environment variables
const versionInfo = {
  version: process.env.REACT_APP_VERSION || '1.0.0'
}

// Define the path to the version.json file
const versionFilePath = path.resolve(__dirname, '../public/version.json')

if (fs.existsSync(versionFilePath)) {
  fs.unlinkSync(versionFilePath)
}

// Ensure the directory exists
const versionFileDir = path.dirname(versionFilePath)
if (!fs.existsSync(versionFileDir)) {
  fs.mkdirSync(versionFileDir, { recursive: true })
}

// Write version information to version.json
fs.writeFileSync(versionFilePath, JSON.stringify(versionInfo, null, 2), 'utf8')

console.log(
  `version.json file generated with version: ${versionInfo.version} using environment: ${environment}`
)
