import React, { useEffect } from 'react'
import RouteCenter from '@/router/RouteCenter'
import { useCommonErrorCode } from './commonHooks/useCommonErrorCode'
import { useGlobalInputBlur, useResizeHeight } from './commonHooks/resizeHeight'
import { useLocation } from 'react-router-dom'
import { usePerInfo, useSafeSwitch } from './commonApi'
import { useAuth } from './compoments/AuthProvider'

function ScrollToTop() {
  const location = useLocation()

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [location])

  return null
}

function App() {
  useResizeHeight()

  /**
   *监听接口错误码
   */
  useCommonErrorCode()

  /**
   * 获取安全信息
   */
  useSafeSwitch()
  
  /**
   * 获取基础配置信息
   */
  const {mutate} = usePerInfo()

  const { token } = useAuth()

  useEffect(() => {
    if (token) {
      mutate()
    }else {
      mutate()
    }
  }, [token])

  /**
   * 适配部分移动设备 软键盘弹出 界面没有回滚bug
   */
  useGlobalInputBlur((event) => {
    setTimeout(()=>{
      window.scrollTo(0, 0)
    },0)
  })

  return (
    <div className="App">
      <ScrollToTop />
      <RouteCenter />
    </div>
  )
}

export default App
