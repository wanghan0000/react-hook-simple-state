import React from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from './AuthProvider'
import { Button, Empty, ErrorBlock, Skeleton } from 'antd-mobile'
import styles from './index.module.scss'

interface SkeletonProps {
  children?: any
  isLoading?: boolean
  error?: any
  data?: any
  retryFunc?: () => void
  errorText?: any
  lineCount?: number
  block?: number
}

const SkeletonUI = ({
  children,
  isLoading,
  error,
  data,
  retryFunc,
  errorText,
  lineCount = 5,
  block = 1
}: SkeletonProps) => {
  return (
    <>
      {isLoading && (
        <>
          {Array.from({ length: block }).map((v, index) => {
            return (
              <div key={index} className={styles.skeletonBlock}>
                <Skeleton.Title animated style={{ height: '20px' }} />
                <Skeleton.Paragraph
                  lineCount={lineCount}
                  animated
                  className={styles.skeletonParagraph}
                />
              </div>
            )
          })}
        </>
      )}
      {!isLoading && !!error && (
        <>
          <ErrorBlock
            status="default"
            description={
              <span>{!!errorText ? errorText : error?.message}</span>
            }
          >
            {!!retryFunc && (
              <Button size={'small'} onClick={() => retryFunc?.()}>
                点击重试
              </Button>
            )}
          </ErrorBlock>
        </>
      )}
      {!isLoading && !error && Object.keys(data ?? [])?.length !== 0 ? (
        <>{children}</>
      ) : (
        !isLoading && !error && <Empty description="暂无数据" />
      )}
    </>
  )
}

export default SkeletonUI
