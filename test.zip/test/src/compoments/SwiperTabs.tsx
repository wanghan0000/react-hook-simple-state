import React, { useRef, useState } from 'react'
import { Tabs, Swiper } from 'antd-mobile'
import styles from './index.module.scss'
import { SwiperRef } from 'antd-mobile/es/components/swiper'

export default ( { tabItems,activeIndex, setActiveIndex, childComponents }) => {
  const swiperRef = useRef<SwiperRef>(null)
  return (
    <>
        <Tabs
          className={styles.tabsContent}
          activeKey={tabItems[activeIndex].key}
          onChange={(key) => {
            const index = tabItems.findIndex((item) => item.key === key)
            setActiveIndex(index)
            swiperRef.current?.swipeTo(index)
          }}
        >
          {tabItems.map((item) => (
            <Tabs.Tab title={item.title} key={item.key} />
          ))}
        </Tabs>
   
      <Swiper
        direction="horizontal"
        loop={false}
        indicator={() => null}
        ref={swiperRef}
        defaultIndex={activeIndex}
        onIndexChange={(index) => {
          setActiveIndex(index)
        }}
      >
          {childComponents.map((item:any,key:number)=>{
           return  (
            <Swiper.Item key={key}>
              <div className={styles.swiperContent}>
                  {item}
              </div>
           </Swiper.Item>
           )
          })}
          
     
      </Swiper>
    </>
  )
}
