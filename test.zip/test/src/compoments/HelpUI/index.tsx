/*
 * @Author: Mark
 * @Date: 2024-05-27 16:29:54
 * @LastEditTime: 2024-05-27 16:38:00
 * @LastEditors: MarkMark
 * @Description: 佛祖保佑无bug
 * @FilePath: /agent_h5/src/compoments/HelpUI/index.tsx
 */
import React from "react";
import Styles from "./index.module.scss";
import { useNavigate } from "react-router";

const SpinLoadingUI=()=>{
    const naviagte=useNavigate()
    return(
        <div className={Styles.footerHelp}>
        如需帮助，请联系
        <p
          onClick={() => {
            naviagte('/online')
          }}
        >
          合营咨询
        </p>
      </div>
    )
}
export default SpinLoadingUI