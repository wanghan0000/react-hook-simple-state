import React from 'react'
import styles from './index.module.scss'

export interface SvgProgressProps {
  className?: string
  /**0-1 */
  percent: number
}

const SvgProgress = (props: SvgProgressProps) => {
  const radius = 32
  const circumference = 2 * Math.PI * radius

  // 根据百分比计算 stroke-dashoffset
  const strokeDashoffset = circumference - props.percent * circumference

  const offsetDistance = `${props.percent * 100}%`;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 84 84"
      fill="none"
      className={props.className}
    >
      <circle cx="42" cy="42" r="32" stroke="#E3E4E6" strokeWidth="12"></circle>
      <g filter="url(#filter0_d_148_79372)">
        <path
          className={styles.progressPath}
          d="M 42 10
                a 32 32 0 0 1 0 64
                a 32 32 0 0 1 0 -64"
          stroke="url(#progressGradient-#218BFF-#00BFFF)"
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
        ></path>
      </g>
      <circle
        className={styles.movingCircle}
        // cx={cx}
        // cy={cy}
        r="4"
        fill="white"
        style={{ offsetPath: 'path("M 42 10 a 32 32 0 0 1 0 64 a 32 32 0 0 1 0 -64")', offsetDistance }}
      ></circle>
      <defs>
        <filter
          id="filter0_d_148_79372"
          x="0"
          y="0"
          width="84"
          height="84"
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity="0" result="BackgroundImageFix"></feFlood>
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          ></feColorMatrix>
          <feOffset dy="2"></feOffset>
          <feGaussianBlur stdDeviation="2"></feGaussianBlur>
          <feComposite in2="hardAlpha" operator="out"></feComposite>
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0"
          ></feColorMatrix>
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_148_79372"
          ></feBlend>
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_148_79372"
            result="shape"
          ></feBlend>
        </filter>
        <linearGradient
          id="progressGradient-#218BFF-#00BFFF"
          x1="22.7609"
          y1="74.55"
          x2="29.9599"
          y2="9.51073"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#218BFF"></stop>
          <stop offset="1" stopColor="#00BFFF"></stop>
        </linearGradient>
      </defs>
    </svg>
  )
}

export default SvgProgress
