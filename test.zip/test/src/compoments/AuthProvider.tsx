import { SWRCenter } from '@/api/api'
import { nextTick } from '@/commonHooks/nextTick'
import React, {
  createContext,
  useContext,
  useState,
  ReactNode,
  useEffect
} from 'react'
import { useNavigate } from 'react-router'

interface CustomConfig {
  //我的界面 佣金金额展示
  myProfileEye: boolean
}

interface AuthContextType {
  token: string | null
  login: (data: any) => void
  logout: () => void
  data: any | null
  customConfig: CustomConfig
  setCustomConfig: React.Dispatch<React.SetStateAction<CustomConfig>>
}

const AuthContext = createContext<AuthContextType | null>(null)

interface AuthProviderProps {
  children: ReactNode
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [token, setToken] = useState<string | null>(
    localStorage.getItem('authToken')
  )
  const [customConfig, setCustomConfig] = useState<CustomConfig>({
    myProfileEye: false
  })
  const [loginData, setLoginData] = useState<any | null>(null)
  const navigate = useNavigate()

  const login = (data: any) => {
    setToken(data.token)
    localStorage.setItem('authToken', data.token)
    setLoginData(data)
  }

  const logout = async () => {
    setToken(null)
    setCustomConfig({
      ...customConfig,
      myProfileEye: false
    })
    SWRCenter.getInstance().randomKey()
    localStorage.setItem('authToken', '')
    await nextTick()
    navigate('/login')
  }

  return (
    <AuthContext.Provider
      value={{
        data: loginData,
        token,
        login,
        logout,
        customConfig,
        setCustomConfig
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
