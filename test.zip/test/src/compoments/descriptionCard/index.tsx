import React, { ReactNode } from 'react'
import CopyPng from '@/assets/common/copy.png'
import IconImage from '../IconImage'
import copy from 'copy-to-clipboard'
import styles from './index.module.scss'
import { Toast } from 'antd-mobile'

interface CardItem {
  title: string | ReactNode
  text: string | ReactNode
  copyValue?: string
  titleWidth?: string
  textWidth?: string
  valueColor?: 'red' | 'green' | '' | any
}

interface DescriptionCardProps {
  topNode?: ReactNode
  bodyColumns?: { group: CardItem[] }[]
  className?: string
  bottomNode?: ReactNode
}

const DescriptionCard = ({
  topNode,
  bottomNode,
  bodyColumns = [],
  className
}: DescriptionCardProps = {}) => {
  return (
    <div className={styles.descriptionCard + ' ' + className}>
      <div className={styles.itemBox}>
        {topNode && <div className={styles.top}>{topNode}</div>}

        <div className={styles.bottom}>
          {bodyColumns.map((v, index) => {
            return (
              <div className={styles.itemTr} key={index}>
                {v.group?.map((e, i) => {
                  return (
                    <div className={styles.group} key={i}>
                      {typeof e.title === 'string' ? (
                        <p style={{ width: e.titleWidth}} className={styles.title}>{e.title}</p>
                      ) : (
                        e.title
                      )}
                      {typeof e.text === 'string' ? (
                        <p style={{ width: e.textWidth }} className={styles.text + ' ' + styles[`${e.valueColor}`]}>{e.text}</p>
                      ) : (
                        e.text
                      )}
                      {!!e.copyValue && (
                        <IconImage
                          onClick={() => {
                            if (copy(e.copyValue || '')) {
                              Toast.show({
                                content: '复制成功'
                              })
                            }
                          }}
                          className={styles.copy}
                          imagePath={CopyPng}
                        />
                      )}
                    </div>
                  )
                })}
              </div>
            )
          })}
        </div>

        {bottomNode && <div className={styles.bottomNode}>{bottomNode}</div>}
      </div>
    </div>
  )
}

export default DescriptionCard
