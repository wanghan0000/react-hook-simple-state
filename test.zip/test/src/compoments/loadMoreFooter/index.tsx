import { DotLoading, InfiniteScroll } from 'antd-mobile'
import React from 'react'
import styles from './index.module.scss'

interface LoadMoreFooterProps {
  loadMore: (isRetry: boolean) => Promise<void>
  hasMore: boolean
}

const LoadMoreFooter = ({ loadMore, hasMore }: LoadMoreFooterProps) => {
  return (
    <>
      <InfiniteScroll
        style={{ width: '100%' }}
        loadMore={loadMore}
        hasMore={hasMore}
      >
        {hasMore ? (
          <>
            <span className={styles.infiniteScrollText}>Loading</span>
            <DotLoading />
          </>
        ) : (
          <span className={styles.infiniteScrollText}>
            --- 我是有底线的 ---
          </span>
        )}
      </InfiniteScroll>
    </>
  )
}

export default LoadMoreFooter