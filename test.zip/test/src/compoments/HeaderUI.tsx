import React, { ReactNode } from 'react'
import styles from './index.module.scss'
interface HeaderUIProps {
  title: string
  rightNode?: ReactNode
  showBack?: boolean
  onClickBack?: ()=> void
}

const HeaderUI = ({ title, rightNode ,showBack ,onClickBack}: HeaderUIProps) => {
  return (
    <div className={styles.HeaderUI}>
      <div className={styles.headerView}>
        <div className={styles.leftView}>
        {showBack && <div onClick={onClickBack} className={styles.leftBackIcon}></div>}
        </div>
        <div className={styles.centerView}>
          <div className={styles.headerItemText}>{title}</div>
        </div>
        <div className={styles.rightView}>{rightNode}</div>
      </div>
    </div>
  )
}

export default HeaderUI
