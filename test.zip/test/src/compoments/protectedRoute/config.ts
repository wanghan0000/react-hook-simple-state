/**常用列表 */
export const dictOffenMenus = [
  { key: 'key0', title: '会员管理', link: '/main/members', imageName: 'menu1' },
  { key: 'key1', title: '游戏记录', link: '/gameRecord', imageName: 'menu2' },
  { key: 'key2', title: '额度充值', link: '/recharge', imageName: 'menu3' },
  { key: 'key3', title: '财务报表', link: '/financial', imageName: 'menu4' },
  {
    key: 'key4',
    title: '佣金报表',
    link: '/main/commissions',
    imageName: 'menu5'
  },
  { key: 'key5', title: '推广素材', link: '/material', imageName: 'menu6' },
  { key: 'key6', title: '溢出申请', link: '/overflowApply', imageName: 'menu7' }
]
/**所有列表 */
export const dictAllMenus = [
  ...dictOffenMenus,
  { key: 'key7', title: '账变明细', link: '/billChanges', imageName: 'menu8' },
  {
    key: 'key8',
    title: '代理代存',
    link: '/main/members/agentDeposit',
    imageName: 'menu9'
  },
  { key: 'key9', title: '推广红利', link: '/dividend', imageName: 'menu10' },
  {
    key: 'key10',
    title: 'VIP专享',
    link: '/main/myProfile/exclusive',
    imageName: 'menu11'
  },
  { key: 'key11', title: '佣金提款', link: '/withdrawal', imageName: 'menu12' },
  {
    key: 'key12',
    title: '会员红利',
    link: '/memberBonus',
    imageName: 'menu13'
  },
  {
    key: 'key13',
    title: '推广工具',
    link: '/main/promotions',
    imageName: 'menu14'
  },
  {
    key: 'key14',
    title: '存款记录',
    link: '/depositRecord',
    imageName: 'menu15'
  },
  {
    key: 'key15',
    title: '活跃会员',
    link: '/main/commissions/activeMembers',
    imageName: 'menu16'
  },
  {
    key: 'key16',
    title: '团队信息',
    link: '/teamCenter',
    imageName: 'menu16'
  },
  {
    key: 'key17',
    title: '小组信息',
    link: '/groupCenter',
    imageName: 'menu16'
  },
  {
    key: 'key18',
    title: '代理转账',
    link: '/main/members/agentTransfer',
    imageName: 'menu9'
  },

]
