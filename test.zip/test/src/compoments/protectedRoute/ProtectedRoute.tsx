import { useGetAgentDepositConfig } from '@/views/main/members/api'
import React, { createContext, useContext, useMemo } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { dictAllMenus, dictOffenMenus } from './config'
import styles from '../LazyCompoment/index.module.scss'
import { DotLoading } from 'antd-mobile'

interface ProtectedRouteProps {
  children: any
}

interface IFMenu {
  key: string
  title: string
  link: string
  imageName: string
}

interface RouteContextType {
  dictOffenMenus: IFMenu[]
  dictAllMenus: IFMenu[]
}

const RouteContext = createContext<RouteContextType | null>(null)

const dictRoutes = {
  '/dividend': {
    key: 'showAgentDividend',
    value: 1,
    redirect: '/dividend/history'
  },
  '/teamCenter': {
    key: 'isTeamLeader',
    value: 1,
    redirect: '/main/home'
  },
  '/groupCenter': {
    key: 'isGroupLeader',
    value: 1,
    redirect: '/main/home'
  }
}

const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const location = useLocation() // 获取当前的路由位置

  const { data: config, isLoading } = useGetAgentDepositConfig()

  const allMenus = useMemo(() => {
    if (!config) {
      return []
    }
    let menus = [...dictAllMenus]
    if (config.isTeamLeader !== 1) {
      menus = menus.filter((v) => {
        return v.key !== 'key16'
      })
    }
    if (config.isGroupLeader !== 1) {
      menus = menus.filter((v) => {
        return v.key !== 'key17'
      })
    }
    return menus
  }, [config])

  if (isLoading) {
    return (
      <div className="gbAppLoading">
        <DotLoading />
      </div>
    )
  }

  const item = dictRoutes[location.pathname]
  if (item) {
    if (config[item.key] === item.value) {
      return children
    } else {
      return (
        <RouteContext.Provider
          value={{
            dictOffenMenus: [...dictOffenMenus],
            dictAllMenus: allMenus
          }}
        >
          <Navigate
            to={item.redirect}
            state={{ from: location.pathname }}
            replace
          />
        </RouteContext.Provider>
      )
    }
  }

  return (
    <RouteContext.Provider
      value={{
        dictOffenMenus: [...dictOffenMenus],
        dictAllMenus: allMenus
      }}
    >
      {children}
    </RouteContext.Provider>
  )
}

export default ProtectedRoute

export const useMenus = () => {
  const context = useContext(RouteContext)
  if (!context) {
    throw new Error('useAuth must be used within an RouteContext')
  }
  return context
}
