import React from 'react'
import styles from './index.module.scss'

interface IconImageProps {
  imagePath?: string
  className?: string
  onClick?: ()=> void
}

const IconImage = ({ imagePath, className  ,onClick}: IconImageProps) => {
  return (
        <div className={styles.IconImage + ' ' + className} onClick={onClick}>
            <div>
                <img src={imagePath} alt="IconImage" />
            </div>
        </div>
  )
}

export default IconImage
