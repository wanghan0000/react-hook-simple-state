/*
 * @Author: Mark
 * @Date: 2024-05-27 16:29:54
 * @LastEditTime: 2024-05-27 16:49:05
 * @LastEditors: MarkMark
 * @Description: 佛祖保佑无bug
 * @FilePath: /agent_h5/src/compoments/NoData/index.tsx
 */
import React from "react";
import Styles from "./index.module.scss";
import { useNavigate } from "react-router";

const NoDataUI=()=>{
    return(
        <div className={Styles.noData}>
            <span>--- 暂无数据 ---</span>
          </div>
    )
}
export default NoDataUI