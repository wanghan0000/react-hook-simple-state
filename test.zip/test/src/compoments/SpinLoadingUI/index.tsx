/*
 * @Author: Mark
 * @Date: 2024-05-27 16:29:54
 * @LastEditTime: 2024-05-27 16:46:23
 * @LastEditors: MarkMark
 * @Description: 佛祖保佑无bug
 * @FilePath: /agent_h5/src/compoments/SpinLoadingUI/index.tsx
 */
import React from "react";
import Styles from "./index.module.scss";
import { SpinLoading } from "antd-mobile";

const SpinLoadingUI=()=>{
    return(
        <div className={Styles.loadingUI}>
            <SpinLoading color="primary" />
        </div>
    )
}
export default SpinLoadingUI