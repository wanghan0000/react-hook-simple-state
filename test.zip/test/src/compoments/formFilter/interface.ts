export enum FormDomTypes {
    select,
    search,
    reset,
    filter,
    dateRange,
    date,
    none,
    radio,
    button
}

export interface FormFilterPorops {
    value?: any,
    onChange?: (value: any) => void,
    className?: string
    columns: {
        domType: FormDomTypes,
        prop?: any
        onClick?: (prop?: string)=> void,
        placeHolder?: any,
        options?: {value: any, label: any}[],
        width?: string
        label?: string
        className?: string
        dateFormat?: string
        isShow?: boolean
        maxDate?: any
    }[]
}