import React, { useState } from 'react'
import { FormDomTypes, FormFilterPorops } from './interface'
import category from '@/assets/common/category.png'
import arrow from '@/assets/common/arrow.png'
import Search from '@/assets/main/search.png'
import reset from '@/assets/main/reset.png'
import Search2 from '@/assets/main/Search2.png'
import SelectPopup from '../selectPopup'
import IconImage from '../IconImage'
import calendarIcon from '@/assets/main/calendarIcon.png'
import downArrow from '@/assets/main/downArrow.png'
import styles from './index.module.scss'
import DatePickerPopup from '../datePickerPopup'
import Select from '@/assets/main/select.png'
import UnSelect from '@/assets/main/unselect.png'
import { TimeStringToDate, timestampToMonth, timestampToString } from '@/utils/date'

const FormFilter = (props: FormFilterPorops) => {
  const [showSelect, setShowSelect] = useState({
    show: false,
    prop: '',
    options: []
  })
  const [showDatePick, setShowDatePick] = useState({
    show: false,
    prop: '',
    dateFormat: '',
    maxDate: undefined
  })

  const handleSelectLabel = (v) => {
    return v?.options?.find((e) => e.value === props.value?.[v?.prop])?.label
  }

  return (
    <div className={styles.formFilter + ' ' + props.className}>
      {props.columns?.map((v: any, index) => {
        const { isShow = true} = v
        return (
          <div
            key={index}
            className={
              styles.formItem +
              ' ' +
              (v.domType === FormDomTypes.none ? styles.itemBlock : '') +
              ' ' +
              (v.domType === FormDomTypes.radio ? styles.noBorder : '') +
              ' ' +
              v?.className + ' ' + (isShow ? '' : styles.hideItem)
            }

            style={{ width: v?.width }}
          >
            {v.domType === FormDomTypes.select && (
              <div
                className={styles.selctItem}
                onClick={() =>
                  setShowSelect({
                    show: true,
                    prop: v.prop,
                    options: v?.options || []
                  })
                }
              >
                <img
                  className={styles.selectIcon}
                  src={category}
                  alt="category"
                />
                {!props.value[v?.prop]?.toString?.().length && (
                  <p className={styles.placeHolder}>{v.placeHolder}</p>
                )}
                {!!props.value[v?.prop]?.toString?.().length && (
                  <p>{handleSelectLabel(v)}</p>
                )}
                <img className={styles.triangle} src={arrow} alt="arrow" />
              </div>
            )}
            {v.domType === FormDomTypes.search && (
              <div className={styles.search}>
                <img src={Search} alt="Search" />
                <input
                  type="text"
                  placeholder={v.placeHolder}
                  value={props.value?.[v?.prop]}
                  onChange={(event) => {
                    const { target } = event
                    const data = props.value || {}
                    data[v.prop] = target.value
                    props.onChange?.({
                      ...data
                    })
                  }}
                />
              </div>
            )}
            {v.domType === FormDomTypes.reset && (
              <div
                className={styles.reset}
                onClick={() => {
                  v?.onClick?.()
                }}
              >
                <img src={reset}></img>
                <p>重置</p>
              </div>
            )}
            {v.domType === FormDomTypes.filter && (
              <div
                className={styles.filter}
                onClick={() => {
                  v?.onClick?.()
                }}
              >
                <img src={Search2}></img>
                <p>筛选</p>
              </div>
            )}
            {v.domType === FormDomTypes.button && (
              <div
                className={styles.filter}
                onClick={() => {
                  v?.onClick?.()
                }}
              >
                <p>{v.label}</p>
              </div>
            )}
            {v.domType === FormDomTypes.date && (
              <div className={styles.dateRange}>
                <div>
                  <IconImage
                    className={styles.calendarIcon}
                    imagePath={calendarIcon}
                  />
                </div>
                <input
                  readOnly
                  value={props.value?.[v?.prop]}
                  placeholder={v?.placeHolder}
                  onClick={() => {
                    setShowDatePick({
                      show: true,
                      prop: v?.prop,
                      dateFormat: v.dateFormat,
                      maxDate: v.maxDate
                    })
                  }}
                />
              </div>
            )}
            {v.domType === FormDomTypes.dateRange && (
              <div className={styles.dateRange}>
                <div>
                  <IconImage
                    className={styles.calendarIcon}
                    imagePath={calendarIcon}
                  />
                </div>
                {v.label && <div className={styles.dateLabel}>{v.label}</div>}
                <input
                  readOnly
                  value={props.value?.[v?.prop[0]]}
                  placeholder={v?.placeHolder?.[0]}
                  onClick={() => {
                    setShowDatePick({
                      show: true,
                      prop: v?.prop[0],
                      dateFormat: v.dateFormat,
                      maxDate: v.maxDate
                    })
                  }}
                />
                <i></i>
                <div className={styles.splice}>-</div>
                <input
                  readOnly
                  value={props.value?.[v?.prop[1]]}
                  placeholder={v?.placeHolder?.[1]}
                  onClick={() => {
                    setShowDatePick({
                      show: true,
                      prop: v?.prop[1],
                      dateFormat: v.dateFormat,
                      maxDate: v.maxDate
                    })
                  }}
                />
                <i></i>
                <div className={styles.arrowDown}>
                  <IconImage
                    className={styles.downArrow}
                    imagePath={downArrow}
                  />
                </div>
              </div>
            )}

            {v.domType === FormDomTypes.radio && (
              <div className={styles.radio}>
                <div className={styles.radioLeft}>{v?.label}</div>
                <div className={styles.radioRight}>
                  <div className={styles.radioSelect}>
                    {v.options?.map((e, i) => {
                      return (
                        <div key={i}>
                          <IconImage
                            className={styles.raidoImage}
                            onClick={() => {
                              const data = props?.value || {}
                              data[v.prop] = e.value
                              props.onChange?.({
                                ...data
                              })
                            }}
                            imagePath={
                              props.value?.[v.prop] === e.value
                                ? Select
                                : UnSelect
                            }
                          />
                          {e.label}
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>
        )
      })}

      <SelectPopup
        value={props?.value?.[showSelect?.prop]}
        visible={showSelect.show}
        options={showSelect.options}
        onClose={() => {
          setShowSelect({
            ...showSelect,
            show: false
          })
        }}
        onConfirm={(v) => {
          const data = props?.value || {}
          data[showSelect.prop] = v
          props.onChange?.({
            ...data
          })
        }}
      />
      <DatePickerPopup
        onClose={() => {
          setShowDatePick({
            ...showDatePick,
            show: false
          })
        }}
        precision={showDatePick.dateFormat}
        visible={showDatePick.show}
        maxDate={showDatePick.maxDate}
        onChange={(v) => {
          const data = props?.value || {}
          if (showDatePick.dateFormat === 'month') {
            data[showDatePick.prop] = timestampToMonth(v)
          }else {
            data[showDatePick.prop] = timestampToString(v)
          }
          props.onChange?.({
            ...data
          })
        }}
        value={TimeStringToDate(props.value?.[showDatePick.prop])}
      />
    </div>
  )
}

export default FormFilter
