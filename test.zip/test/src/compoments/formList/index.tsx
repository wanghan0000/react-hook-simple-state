import { Input, List } from 'antd-mobile'
import React, { ReactNode, useState } from 'react'
import styles from './index.module.scss'
import IconImage from '../IconImage'
import OpenEyePng from '@/assets/common/openEye.png'
import HideEyePng from '@/assets/common/hideEye.png'
import SelectPopup from '../selectPopup'

export enum FormListItemType {
  select,
  password,
  input,
  text
}

interface IFListItem {
  domType: FormListItemType
  prefix?: string | ReactNode | undefined
  extra?: ReactNode | undefined
  options?: { value: any; label: string }[]
  prop?: string
  placeHolder?: string
  readonly?: boolean
  onClickEye?: (v?: any) => Promise<any>
  tips?: string
  show?: boolean
  maxLength?: number
  inputMode?: any
  inputSuffix?: ReactNode,
  className?: string
}

interface FormListProps {
  className?: string
  columns: IFListItem[]
  values?: any
  onChange?: (values: any) => void
  rules?: any
}

const FormList = ({
  className = '',
  columns,
  values,
  rules,
  onChange
}: FormListProps) => {
  const [eyeSate, setEyeState] = useState({})
  const [error, setError] = useState({})
  const [showSelect, setShowSelect] = useState({
    show: false,
    prop: '',
    options: []
  })
  return (
    <div className={styles.formList + ' ' + className}>
      <List>
        {columns.map((v, index) => {
          return (
            <List.Item
              prefix={v.prefix}
              arrow={v.domType === FormListItemType.select}
              className={v.tips ? styles.listItemTips : ''}
              style={{
                display: (typeof v.show === 'boolean' ? v.show : true)
                  ? 'block'
                  : 'none'
              }}
              onClick={() => {
                if (v.domType === FormListItemType.select) {
                  setShowSelect({
                    show: true,
                    prop: v.prop || '',
                    options: v?.options ?? ([] as any)
                  })
                }
              }}
              extra={
                v.extra ? (
                  v.extra
                ) : (
                  <>
                    {v.domType === FormListItemType.select && (
                      <div className={styles.selectDiv + ' ' + v.className}>
                        {v.options?.find(
                          (item) => item.value === values[`${v.prop}`]
                        )?.label || (
                          <div className={styles.selectPlaceHolder}>
                            {v.placeHolder}
                          </div>
                        )}

                        <div className={styles.tips}>
                          <span>{v.tips}</span>
                        </div>
                      </div>
                    )}
                    {v.domType === FormListItemType.password && (
                      <div className={styles.inputWarp + ' ' + v.className}>
                        {!v.readonly && (
                          <>
                            <Input
                              type={
                                eyeSate?.[`${v.prop}`] ? 'text' : 'password'
                              }
                              placeholder={v.placeHolder}
                              clearable
                              maxLength={v.maxLength}
                              value={values[`${v.prop}`]}
                              onChange={(e) => {
                                const data = values || {}
                                data[`${v.prop}`] = e
                                if (rules?.[`${v.prop}`]?.validate) {
                                  const state =
                                    rules?.[`${v.prop}`]?.validate?.(e)
                                  error[`${v.prop}`] = state ? '' : 'error'
                                  setError({ ...error })
                                }
                                onChange?.({ ...data })
                              }}
                            />
                           
                            <div
                              className={
                                styles.tips +
                                ' ' +
                                (error?.[`${v.prop}`] === 'error'
                                  ? styles.tipsStateError
                                  : '')
                              }
                            >
                              <span>{v.tips}</span>
                            </div>
                          </>
                        )}
                        {v.readonly && values?.[`${v.prop}`]}
                        <IconImage
                          onClick={() => {
                            const data = { ...eyeSate } || {}
                            data[`${v?.prop}`] = !data[`${v?.prop}`]
                            if (v?.onClickEye) {
                              v?.onClickEye?.(data[`${v?.prop}`])
                            } else {
                              setEyeState({
                                ...data
                              })
                            }
                          }}
                          imagePath={
                            !!eyeSate?.[`${v?.prop}`] ? OpenEyePng : HideEyePng
                          }
                          className={styles.eyeImage}
                        />
                      </div>
                    )}
                    {v.domType === FormListItemType.input && (
                      <div className={styles.inputWarp + ' ' + v.className}>
                        <Input
                          type={'text'}
                          placeholder={v.placeHolder}
                          clearable
                          maxLength={v.maxLength}
                          readOnly={v.readonly}
                          inputMode={v.inputMode}
                          value={values[`${v.prop}`]}
                          onChange={(value) => {
                            if (v.inputMode === 'decimal') {
                              value = value.replace(/[^0-9.]/g, '')
                              // 防止多个小数点
                              if ((value.match(/\./g) || []).length > 1) {
                                value = value.replace(/\.(?=.*\.)/g, '')
                              }
                            }
                            const data = values || {}
                            data[`${v.prop}`] = value
                            if (rules?.[`${v.prop}`]?.validate) {
                              const state =
                                rules?.[`${v.prop}`]?.validate?.(value)
                              error[`${v.prop}`] = state ? '' : 'error'
                              setError({ ...error })
                            }
                            onChange?.({ ...data })
                          }}
                        />
                         {v.inputSuffix}
                        <div
                          className={
                            styles.tips +
                            ' ' +
                            (error?.[`${v.prop}`] === 'error'
                              ? styles.tipsStateError
                              : '')
                          }
                        >
                          <span>{v.tips}</span>
                        </div>
                      </div>
                    )}
                    {v.domType === FormListItemType.text && (
                      <div className={styles.inputWarp + ' ' + v.className}>
                        <div className={styles.text}>
                          {values?.[`${v.prop}`]}
                        </div>
                      </div>
                    )}
                  </>
                )
              }
              key={index}
            />
          )
        })}
      </List>

      <SelectPopup
        value={values?.[showSelect?.prop]}
        visible={showSelect.show}
        options={showSelect.options}
        onClose={() => {
          setShowSelect({
            ...showSelect,
            show: false
          })
        }}
        onConfirm={(v) => {
          const data = values || {}
          data[showSelect.prop] = v
          onChange?.({
            ...data
          })
        }}
      />
    </div>
  )
}

export default FormList
