import React, { ReactNode } from 'react'
import styles from './index.module.scss'
import { List, SpinLoading } from 'antd-mobile'
import LoadMoreFooter from '../loadMoreFooter'

interface LoadMoreListProps {
  datas: any[]
  loadMore: () => Promise<any>
  hasMore: boolean
  firstLoading: boolean
  render: (item: any, index: number) => ReactNode
  itemClassName?: string
}

const LoadMoreList = ({
  datas,
  loadMore,
  hasMore,
  firstLoading,
  render,
  itemClassName
}: LoadMoreListProps) => {
  return (
    <div className={styles.loadMoreList}>
      <List>
        {datas.map((item, index) => (
          <div key={index} className={itemClassName}>{render(datas[index], index)}</div>
        ))}
      </List>
      <LoadMoreFooter loadMore={loadMore} hasMore={hasMore} />
      {firstLoading && (
        <div className={styles.loadingUI}>
          <SpinLoading color="primary" />
        </div>
      )}
    </div>
  )
}

export default LoadMoreList
