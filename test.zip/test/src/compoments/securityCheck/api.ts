
import { apiFetcher } from "@/api/api";
import useSWRMutation from "swr/mutation";

export function useApiSecurityCheck() {
    const params = {
      path: "/member/check",
      type: "post"
    };
    return useSWRMutation(params, (params, arg: { arg: any }) => {
      return apiFetcher<any>(params, { ...arg });
    });
  }