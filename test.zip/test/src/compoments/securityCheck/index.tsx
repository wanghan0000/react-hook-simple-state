import IconImage from '@/compoments/IconImage'
import { Popup, Dialog, Input, Button, Toast, InputRef } from 'antd-mobile'
import React, { useEffect, useRef } from 'react'
import { useState } from 'react'
import HideEyePng from '@/assets/common/hideEye.png'
import OpenEyePng from '@/assets/common/openEye.png'
import styles from './index.module.scss'
import { useApiSecurityCheck } from './api'
import { md5Hash } from '@/utils/md5'

interface SecurityCheckProps {
  visible: boolean
  onClose: () => void
  onSussess: () => void
  //1下级会员真实姓名 2提款,佣金代存 3额度代存,额度充值，推广红利
  eyesType: number
}

export const SecurityCheck = (props: SecurityCheckProps) => {
  //const [visible, setVisible] = useState(false)
  const [eyeState, setEyeState] = useState(false)

  const { trigger } = useApiSecurityCheck()
  const [value, setValue] = useState('')
  // useEffect(() => {
  //   if (props.visible) {
  //     setVisible(true)
  //   }
  // }, [props])

  // useEffect(() => {
  //   if (!visible) {
  //     props.onClose?.()
  //   }
  // }, [visible])

  useEffect(() => {
    if (props.visible) {
      setValue('')
      setEyeState(false)
    }
  }, [props.visible])

  const btnSatus = value.length !== 6

  const inputRef = useRef<InputRef>(null)

  useEffect(() => {
    function adjustDialogPosition() {
      // 根据需要调整 Dialog 的位置或大小
      //console.log('尺寸变化了')
      //console.log(window.innerHeight)
    }
  
    window.addEventListener('resize', adjustDialogPosition);
    return () => {
      window.removeEventListener('resize', adjustDialogPosition);
    };
  }, []);

  return (
    <Dialog
      visible={props.visible}
      onClose={() => {
        props?.onClose?.()
      }}
      closeOnAction={true}
      bodyClassName={styles.saftyDialog}
      title={'安全校验'}
      actions={[
        [
          {
            key: 'cancel',
            text: '取消',
            onClick: () => {}
          },
          {
            key: 'confirm',
            text: '确定',
            disabled: btnSatus,
            onClick: async () => {
              try {
                await trigger({
                  eyesType: props.eyesType,
                  payPassword: md5Hash(value)
                })
                await props.onSussess?.()
              } catch (error: any) {
                Toast.show(error?.message)
              }
            }
          }
        ]
      ]}
      content={
        <div className={styles.checkModalForm}>
          <p>为了您的安全，请输入支付密码查看</p>
          <div className={styles.modalInput}>
            <div className={styles.customInputWarp}>
              <Input
                ref={inputRef}
                maxLength={6}
                className={styles.inputLeft}
                placeholder="请输入支付密码"
                clearable
                type={eyeState ? 'text' : 'password'}
                value={value}
                onChange={(v) => setValue(v)}
              />
              <IconImage
                onClick={() => {
                  setEyeState((value) => !value)
                }}
                imagePath={eyeState ? OpenEyePng : HideEyePng}
                className={styles.inputEye}
              />
            </div>
          </div>
        </div>
      }
    />
  )
}

export default SecurityCheck
