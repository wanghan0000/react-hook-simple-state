import React, { useEffect, useState } from 'react'
import { PickerView, Popup } from 'antd-mobile'
import { PickerValue } from 'antd-mobile/es/components/picker'
import styles from './index.module.scss'


interface SelectPopupProps {
  visible?: boolean,
  value?: any
  options?: {value: any , label: string}[]
  onConfirm?: (value: any) => void
  onClose?: () => void
}

const SelectPopup = (props: SelectPopupProps) => {
  const [visible, setVisible] = useState(false)


  const [value, setValue] = useState<PickerValue[]>([props?.options?.[0]?.value])

  useEffect(()=> {
    if(props?.options?.length) {
        setValue([props.options.find((item)=>item.value === props.value)?.value])
    }
  },[props])

  useEffect(() => {
    setVisible(!!props.visible)
  }, [props.visible])

  useEffect(() => {
    if (!visible) {
      props?.onClose?.()
    }
  }, [visible])
  return (
    <Popup
      visible={visible}
      onMaskClick={() => {
        setVisible(false)
      }}
      className={styles.SelectPopup}
      bodyStyle={{
        borderTopLeftRadius: '8px',
        borderTopRightRadius: '8px'
      }}
    >
      <div>
        <div className={styles.top}>
          <div
            onClick={() => setVisible(false)}
            className={styles.left + ' ' + styles.text}
          >
            取消
          </div>
          <div
            onClick={() => {
              setVisible(false)
              props.onConfirm?.(value[0])
            }}
            className={styles.right + ' ' + styles.text}
          >
            确定
          </div>
        </div>

        <PickerView
          className={styles.pickerView}
          style={{
            '--height': '260px',
            '--item-height': '40px',
            '--item-font-size': '24px'
          }}
          columns={[props?.options || []]}
          value={value}
          onChange={(val, extend) => {
            setValue(val)
          }}
        />
      </div>
    </Popup>
  )
}

export default SelectPopup
