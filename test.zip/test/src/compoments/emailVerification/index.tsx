import { Dialog, Input, Toast } from 'antd-mobile'
import React, { useEffect } from 'react'
import { useState } from 'react'
import styles from './index.module.scss'
import { useApiCheckCode, useApiSendCode } from './api'
import { useAgentInfo } from '@/commonApi'
import useSmsCountDown from '@/commonHooks/useSmsCountDown'

interface EmailVerificationProps {
  visible: boolean
  onClose: () => void
  onSussess: (v: any) => void
  //0=手机号码 1=邮箱设置 2=密码设置 3=异地以及密码次数上限验证
  cate: string
  //功能标识 0手机号码设置/1邮箱设置/2密码设置/3异地登录密码错误次数触发输入后四位手机号发送验证码校验
  type: string
  tips: string
}

export const EmailVerification = (props: EmailVerificationProps) => {
  const [value, setValue] = useState('')

  const { data } = useAgentInfo()
  const { trigger: triggerSendCode, isMutating: codeMutating } =
    useApiSendCode()
  const { trigger: triggerCheckCode } = useApiCheckCode()

  const { secounds, start } = useSmsCountDown('emailVerification')
  const handleSendEmailCode = () => {
    if (secounds || codeMutating) {
      return
    }
    triggerSendCode({
      cate: props.cate,
      type: props.type,
      sendName: data.name,
      version: process.env.REACT_API_VERSION
    })
      .then(() => {
        start()
      })
      .catch((error) => {
        Toast.show(error?.message || JSON.stringify(error))
      })
  }

  return (
    <Dialog
      visible={props.visible}
      onClose={() => {
        props?.onClose?.()
      }}
      closeOnAction={true}
      bodyClassName={styles.emailVerificationDialog}
      title={'校验邮箱验证码'}
      actions={[
        [
          {
            key: 'cancel',
            text: '取消',
            onClick: () => {}
          },
          {
            key: 'confirm',
            text: '确定',
            onClick: async () => {
              try {
                const data = await triggerCheckCode({
                  cate: props.cate,
                  code: value,
                  twoStep: '1'
                })
                await props.onSussess?.(data?.twoStepCode)
              } catch (error: any) {
                Toast.show(error?.message)
              }
            }
          }
        ]
      ]}
      content={
        <div className={styles.checkModalForm}>
          <p>{props.tips}</p>
          <div className={styles.modalInput}>
            <div className={styles.customInputWarp}>
              <Input
                className={styles.inputLeft}
                placeholder="请输入验证码"
                type={'text'}
                value={value}
                onChange={(v) => setValue(v)}
              />
              <div onClick={handleSendEmailCode} className={styles.btnSendCode}>
                {codeMutating && <span className={styles.loader}></span>}
                <span
                  className={
                    styles.codeText +
                    ' ' +
                    (codeMutating || secounds
                      ? styles.disabledText
                      : '')
                  }
                >
                  {!!secounds ? `${secounds}s 后获取验证码` : '获取验证码'}
                </span>
              </div>
            </div>
          </div>
        </div>
      }
    />
  )
}

export default EmailVerification
