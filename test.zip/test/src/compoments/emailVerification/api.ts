import { apiFetcher } from '@/api/api'
import useSWRMutation from 'swr/mutation'

export function useApiSendCode() {
  const params = {
    path: '/member/sendCode',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

export function useApiCheckCode() {
  const params = {
    path: '/member/checkCode',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}
