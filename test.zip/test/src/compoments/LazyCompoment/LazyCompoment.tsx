import React, { ReactNode, Suspense } from 'react'

// 定义 props 类型，
interface LazyComponentProps {
  component: any
  props?: any
}
import { DotLoading } from 'antd-mobile'

// 定义懒加载组件
export default function LazyCompoment({
  component: Component,
  props
}: LazyComponentProps) {
  return (
    <Suspense
      fallback={
        <div className="gbAppLoading">
          <DotLoading />
        </div>
      }
    >
      <Component {...props} />
    </Suspense>
  )
}
