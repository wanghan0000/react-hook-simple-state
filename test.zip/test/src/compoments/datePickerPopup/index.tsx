import { DatePickerView, Popup } from 'antd-mobile'
import React, { useEffect, useState } from 'react'
import styles from './index.module.scss'
import { DatePickerFilter } from 'antd-mobile/es/components/date-picker'
import { timestampToMonth } from '@/utils/date'

const labelRenderer = (type: string, data: number) => {
  switch (type) {
    case 'year':
      return data + '年'
    case 'month':
      return data + '月'
    case 'day':
      return data + '日'
  }
}

const dateFilter: DatePickerFilter = {
  year: (val, { date }) => {
    if (date.getFullYear() < 2023) {
      return false
    }
    return true
  }
}

interface DatePickerPopupProps {
  visible: boolean
  value?: any
  onChange?: (value: any) => void
  onClose?: () => void
  precision?: any
  maxDate?: any
}

const DatePickerPopup = (props: DatePickerPopupProps) => {
  const [visible, setVisible] = useState(false)
  const [value, setValue] = useState<Date>(new Date())

  useEffect(() => {
    setVisible(props.visible)
    if (props.value) {
      setValue(props.value)
    }
  }, [props])

  useEffect(() => {
    if (!visible) {
      props?.onClose?.()
    }
  }, [visible])
  return (
    <Popup
      visible={visible}
      onMaskClick={() => {
        setVisible(false)
      }}
      bodyStyle={{
        borderTopLeftRadius: '8px',
        borderTopRightRadius: '8px',
        minHeight: '180px'
      }}
    >
      <div>
        <div className={styles.top}>
          <div
            onClick={() => setVisible(false)}
            className={styles.left + ' ' + styles.text}
          >
            取消
          </div>
          <div
            onClick={() => {
              const timestamp: any = new Date(value).getTime()
              props.onChange?.(timestamp)
              setVisible(false)
            }}
            className={styles.right + ' ' + styles.text}
          >
            确定
          </div>
        </div>
        <DatePickerView
          className={styles.datePickerView}
          value={value}
          max={props.maxDate}
          precision={props.precision || 'day'}
          onChange={(val: any) => {
            setValue(val)
          }}
          renderLabel={labelRenderer}
          filter={dateFilter}
        />
      </div>
    </Popup>
  )
}

export default DatePickerPopup
