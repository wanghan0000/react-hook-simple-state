import { Button, Mask } from 'antd-mobile'
import React from 'react'
import styles from './index.module.scss'

interface MaskContentPopProps {
  visible?: boolean
  onMaskClick?: () => void
  configs: any[]
  onClickConfirm?: () => void
  title?: string
  showIndex?: boolean
  textCenter?: boolean
  //1 普通模式 2带标题模式
  model?: number
}

const MaskContentPop = (props: MaskContentPopProps) => {
  const { showIndex = true, model = 1 } = props
  return (
    <Mask visible={props.visible} onMaskClick={props.onMaskClick}>
      <div className={styles.tipsBox}>
        <div className={styles.title}>{props?.title || '提示'}</div>
        <div className={styles.cont}>
          <div className={styles.tipsCont}>
            <ol
              className={
                styles.tipsContOl +
                ' ' +
                (showIndex ? styles.showIndex : styles.hideIndex)
              }
            >
              {model === 1 &&
                props.configs.map((v, index) => {
                  return (
                    <li
                      key={index}
                      className={props.textCenter ? styles.textCenter : ''}
                    >
                      {v}
                    </li>
                  )
                })}
              {model === 2 &&
                props.configs.map((v, index) => {
                  return (
                    <div className={styles.contentGroup} key={index}>
                      <p className={styles.contentTitle}>{v.title}</p>
                      {v?.content.map((content, i) => {
                        return <p className={styles.contentText} key={i}>{content}</p>
                      })}
                    </div>
                  )
                })}
            </ol>
          </div>
        </div>
        <div className={styles.tipsBoxBottom}>
          <Button
            onClick={props.onClickConfirm}
            color="primary"
            fill="none"
            className={styles.buttonConfirm}
          >
            我知道了
          </Button>
        </div>
      </div>
    </Mask>
  )
}

export default MaskContentPop
