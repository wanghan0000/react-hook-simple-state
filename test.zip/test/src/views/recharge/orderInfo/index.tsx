import HeaderUI from '@/compoments/HeaderUI'
import React, { useEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import { useTimer } from 'react-timer-hook'
import IconImage from '@/compoments/IconImage'
import { DotLoading, Toast } from 'antd-mobile'
import CopyPng from '@/assets/common/copy.png'
import copy from 'copy-to-clipboard'
import styles from './index.module.scss'
import { useCancleOrder, useGetBillNoStatus } from '../api'

const OrderInfoTime = ({ expiryTimestamp }: any) => {
  const { seconds, minutes } = useTimer({
    expiryTimestamp,
    onExpire: () => console.warn('onExpire called')
  })
  return (
    <div className={styles.timeInfo}>
      <span>{minutes}</span>:
      <span>{seconds < 10 ? '0' + seconds : seconds}</span>
    </div>
  )
}

const OrderInfo = () => {
  const navigate = useNavigate()

  const { trigger, isMutating } = useCancleOrder()

  const location = useLocation()
  const { amount, payTypeName, billNo, expireTime, id } = location.state || {}
  const { data } = useGetBillNoStatus(billNo)

  const [rExpireTime, setRxpireTime] = useState(0)
  useEffect(() => {
    let time: any = localStorage.getItem(billNo)
    if (time) {
      setRxpireTime(Number(time))
    } else {
      time = new Date().getTime() + expireTime * 1000
      setRxpireTime(time)
      localStorage.setItem(billNo, time)
    }
  }, [expireTime, billNo])

  const OrderStatus = useMemo(() => {
    return data?.status || 1
  }, [data])

  return (
    <div>
      <HeaderUI
        title="存款信息"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.orderTop}>
        <div className={styles.depositAmount}>
          <span>{Number(amount).toFixed(2)}</span>元
        </div>
        {OrderStatus == 1 && (
          <div className={styles.tipsTime}>
            请在&nbsp;
           {rExpireTime && <OrderInfoTime
              expiryTimestamp={rExpireTime}
            />}
            &nbsp;内完成支付
          </div>
        )}
        {(OrderStatus == 2 ||
          OrderStatus == 3) && (
            <div className={styles.tipsTime}>
              <div className={styles.timeInfo}>
                <span>订单充值成功</span>
              </div>
            </div>
          )}
        {OrderStatus == 4 && (
          <div className={styles.tipsTime}>
            <div className={styles.red}>
              <span>订单被拒绝</span>
            </div>
          </div>
        )}
        {OrderStatus == 5 && (
          <div className={styles.tipsTime}>
            <div className={styles.red}>
              <span>订单已失效</span>
            </div>
          </div>
        )}
        <div className={styles.tipsChat}>
          如支付存在疑问，请{' '}
          <span
            onClick={() => {
              navigate('/online')
            }}
          >
            联系客服
          </span>{' '}
          确认
        </div>
      </div>
      <div className={styles.payInfoBox}>支付信息</div>
      <div className={styles.rechargeInfo}>
        <div className={styles.depositInfo}>
          <div className={styles.infoLeft}>存款方式</div>
          <div className={styles.infoRight}>{payTypeName}</div>
        </div>

        <div className={styles.depositInfo}>
          <div className={styles.infoLeft}>订单号</div>
          <div className={styles.infoRight}>{billNo}</div>
          <IconImage
            onClick={() => {
              if (copy(billNo)) {
                Toast.show('复制成功')
              }
            }}
            imagePath={CopyPng}
            className={styles.copyImage}
          />
        </div>
      </div>

      <div className={styles.infoTips}>
        <div className={styles.title}>重要提醒</div>
        <div className={styles.msg}>
          1.转账金额须与订单金额一致，否则存款无法及时到账
        </div>
        <div className={styles.msg}>
          2.请及时前往存款，并在30分钟之内完成存款
        </div>
        <div className={styles.msg}>3.若存款存在疑问，请及时联系客服</div>
      </div>

      <div
        className={
          styles.footer + ' ' + (OrderStatus != 1 ? styles.complete : '')
        }
      >
        {OrderStatus == 1 && (
          <button
            onClick={() => {
              trigger({
                id: id
              })
                .then(() => {
                  navigate(-1)
                })
                .catch((error) => {
                  Toast.show(error?.message || JSON.stringify(error))
                })
            }}
            className={styles.btn}
          >
            {isMutating ? <DotLoading /> : '取消存款申请'}
          </button>
        )}
        <button
          onClick={() => {
            navigate('/online')
          }}
          className={styles.btn + ' ' + styles.btnActivity}
        >
          联系客服确认
        </button>
      </div>
    </div>
  )
}

export default OrderInfo
