export default {
    name: "orderInfo",
    author: true,
    /**是否是根路由 */
    isRootRouter: true
};
  