import { apiFetcher, useSWRExpand } from '@/api/api'
import { useEffect, useState } from 'react'
import useSWRMutation from 'swr/mutation'

/**获取充值列表缓存10s */
export const useGetAgentTypes = () => {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/finance/edu/agentTypes',
        type: 'post'
      },
      {}
    ).then((res: any) => {
      return res.typeList || []
    })
  }
  return useSWRExpand('useGetAgentTypes', fetcherFuc, {
    dedupingInterval: 10 * 1000
  })
}

/**立即支付 */
export const useAgentPay = () => {
  const params = {
    path: '/finance/edu/agentPayTo',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

/**取消订单 */
export const useCancleOrder = () => {
  const params = {
    path: '/finance/edu/closeOrderAgent',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//刷新订单状态
export const useGetBillNoStatus = (billNo) => {
  const [isPaused, setIsPaused] = useState(false)

  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/finance/edu/getBillNoStatus',
        type: 'post'
      },
      {
        arg: {
          billNo: billNo
        }
      }
    )
  }
  const result = useSWRExpand('useGetBillNoStatus' + billNo, fetcherFuc, {
    refreshInterval: 5 * 1000,
    revalidateOnFocus: true,
    isPaused: () => isPaused
  })

  useEffect(() => {
    if (result && result.data) {
      setIsPaused(result?.data?.status != 1)
    }
  }, [result])
  return result
}
