import React, { useEffect, useMemo, useState } from 'react'
import IconImage from '@/compoments/IconImage'
import RecommondTag from '@/assets/common/recommondTag.png'
import VirtualIcon from '@/assets/common/virtualIcon.png'
import { Button, Toast } from 'antd-mobile'
import UsdtIcon from '@/assets/common/usdtIcon.png'
import { useAgentPay, useGetAgentTypes } from '../../api'
import SkeletonUI from '@/compoments/SkeletonUI'
import { openLink } from '@/utils'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'

interface DepositWaysProps {
  value: any
  onChange: (value: any) => void
}

const DepositWays = (props: DepositWaysProps) => {
  const { data: typeList, isLoading, error } = useGetAgentTypes()

  const datas = useMemo(() => {
    if (typeList) {
      return typeList.map((v) => {
        return {
          ...v,
          imagePath: v.icon,
          title: v.typeName,
          showTag: v.recommend === 1
        }
      })
    } else {
      return []
    }
  }, [typeList])

  return (
    <div className={styles.paymentView}>
      <div className={styles.paymentTitle}>
        <span>存款方式</span>
      </div>
      <div className={styles.paymentContent}>
        {datas.map((v, index) => {
          return (
            <div
              onClick={() => props.onChange(index)}
              key={index}
              className={
                styles.payementItem +
                ' ' +
                (props.value === index ? styles.activityPaymentItem : '')
              }
            >
              {v.showTag && (
                <IconImage
                  imagePath={RecommondTag}
                  className={styles.paymentTag}
                />
              )}
              <IconImage
                imagePath={v.imagePath}
                className={styles.paymentIcon}
              />
              <span className={styles.payementName}>{v.title}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

const DepositMoney = (props: any) => {
  const config = props.config || {}

  const fixedAmount = useMemo(() => {
    return config?.fixed_amount || []
  }, [config])

  const [activityIndex, setActivityIndex] = useState(-1)

  useEffect(()=>{
    const index = fixedAmount.findIndex((item)=>{
      return item === props.value?.amount
    })
    setActivityIndex(index)
  },[props.value,fixedAmount])

  const error = useMemo(() => {
    if (!config) {
      return false
    } else {
      if (!props.value?.amount) {
        return false
      }
      const amount = Number(props?.value?.amount || 0)
      const { deposit_min_amount, deposit_max_amount } = config
      if (amount < Number(deposit_min_amount)) {
        return true
      }
      if (amount > Number(deposit_max_amount)) {
        return true
      }
      return false
    }
  }, [config, props])

  return (
    <div className={styles.depositAmountView}>
      <div className={styles.depositAmountTitle}>存款金额</div>
      <div className={styles.depositAmountContent}>
        {fixedAmount.map((v, index) => {
          return (
            <div
              onClick={() => {
                setActivityIndex(index)
                props.value['amount'] = fixedAmount[index]
                props?.onChange({
                  ...props.value
                })
              }}
              key={index}
              className={
                styles.depositAmountItem +
                ' ' +
                (activityIndex === index
                  ? styles.depositAmountItemActivity
                  : '')
              }
            >
              <span className={styles.depositAmountNumber}>{v}</span>
            </div>
          )
        })}
      </div>
      <div className={styles.depositAmountInputView}>
        <div className={styles.amountInput}>
          <span className={styles.amountTips}>存款金额</span>
          <div className={styles.inputWarp}>
            <input
              type="number"
              inputMode="decimal"
              pattern="[0-9.]*"
              value={props.value.amount}
              onChange={(e: any) => {
                const data = props.value || {}
                let value = e?.target?.value
                value = value.replace(/[^0-9.]/g, '')
                // 防止多个小数点
                if ((value.match(/\./g) || []).length > 1) {
                  value = value.replace(/\.(?=.*\.)/g, '')
                }
                data.amount = value
                props?.onChange?.(data)
              }}
              placeholder={`请输入${config?.deposit_min_amount}-${config?.deposit_max_amount}元`}
            />
            <div
            onClick={()=>{
              const data = props.value || {}
              data.amount = ''
              props?.onChange?.(data)
            }}
            className={styles.inputAmountCleaar}></div>
          </div>
        </div>
      </div>
      {error && <div className={styles.depositAmountErrorTips}>
      {`请输入正确的存款金额(${config?.deposit_min_amount}-${config?.deposit_max_amount})`}
      </div>}
    </div>
  )
}

const DepositVirtual = (props: any) => {
  const kins = [
    {
      imagePath: UsdtIcon,
      value: 'USDT'
    }
  ]

  const config = props.config || {}

  const fixedAmount = useMemo(() => {
    return config?.fixed_amount || []
  }, [config])


  useEffect(()=>{
    const index = fixedAmount.findIndex((item)=>{
      return item === props.value?.amount
    })
    setActivityIndex(index)
  },[props.value,fixedAmount])

  const protocols = useMemo(() => {
    if (config?.dc_protocol?.length) {
      return config.dc_protocol.map((v) => {
        return v === '0'
          ? { value: v, label: 'TRC20' }
          : {
              value: v,
              label: 'ERC20'
            }
      })
    } else {
      return [
        {
          value: '0',
          label: 'TRC20'
        }
      ]
    }
  }, [config])

  const estimateAmount = useMemo(() => {
    if (!config) {
      return '0.00'
    } else {
      const amount = Number(props?.value?.amount || 0)
      return ((amount * 100) / (Number(config?.exchange || 0) * 100)).toFixed(2)
    }
  }, [config, props])

  const error = useMemo(() => {
    if (!config) {
      return false
    } else {
      if (!props.value?.amount) {
        return false
      }
      const amount = Number(props?.value?.amount || 0)
      const { deposit_min_amount, deposit_max_amount } = config
      if (amount < Number(deposit_min_amount)) {
        return true
      }
      if (amount > Number(deposit_max_amount)) {
        return true
      }
      return false
    }
  }, [config, props])

  const [virtualCurrencyIndex, setVirtualCurrencyIndex] = useState(0)
  const [activityIndex, setActivityIndex] = useState(-1)
  return (
    <div className={styles.usdtView}>
      <div className={styles.paymentInfo}>
        <div className={styles.usdtKing}>
          <div className={styles.usdtLable}>虚拟币种类</div>
          <div className={styles.usdtContent}>
            {kins.map((v, index) => {
              return (
                <div
                  onClick={() => setVirtualCurrencyIndex(index)}
                  className={
                    styles.kinsItem +
                    ' ' +
                    (virtualCurrencyIndex === index
                      ? styles.kinsItemActivity
                      : '')
                  }
                  key={index}
                >
                  <IconImage
                    imagePath={v.imagePath}
                    className={styles.kinsIcon}
                  />
                  <span
                    className={
                      styles.usdtKinSpan +
                      ' ' +
                      (virtualCurrencyIndex === index
                        ? styles.usdtKinSpanActivity
                        : '')
                    }
                  >
                    {v.value}
                  </span>
                </div>
              )
            })}
          </div>
        </div>
        <div className={styles.usdtProtocol}>
          <div className={styles.usdtLable}>虚拟币协议</div>
          <div className={styles.usdtContent}>
            {protocols?.map?.((v, index) => {
              return (
                <div
                  onClick={() => {
                    const data = props.value || {}
                    data.protocol = v.value
                    props.onChange?.(data)
                  }}
                  className={
                    styles.kinsItem +
                    ' ' +
                    (props.value.protocol === v.value
                      ? styles.kinsItemActivity
                      : '')
                  }
                  key={index}
                >
                  <span
                    className={
                      styles.usdtKinSpan +
                      ' ' +
                      (props.value.protocol === v.value
                        ? styles.usdtKinSpanActivity
                        : '')
                    }
                  >
                    {v.label}
                  </span>
                </div>
              )
            })}
          </div>
        </div>

        <div className={styles.depositAmountTitle + ' ' + styles.virTualTitle}>
          存款金额
        </div>
        <div className={styles.depositAmountContent}>
          {fixedAmount.map((v, index) => {
            return (
              <div
                onClick={() => {
                  setActivityIndex(index)
                  props.value['amount'] = fixedAmount[index]
                  props?.onChange({
                    ...props.value
                  })
                }}
                key={index}
                className={
                  styles.depositAmountItem +
                  ' ' +
                  (activityIndex === index
                    ? styles.depositAmountItemActivity
                    : '')
                }
              >
                <span className={styles.depositAmountNumber}>{v}</span>
              </div>
            )
          })}
        </div>

        <div className={styles.usdtDepositTile}>存款金额（CNY）</div>
        <div className={styles.depositAmountInputView}>
          <div className={styles.amountInput}>
            <span className={styles.amountTips}>存款金额</span>
            <div className={styles.inputWarp}>
              <input
                type="number"
                inputMode="decimal"
                pattern="[0-9.]*"
                value={props.value.amount}
                onChange={(e: any) => {
                  const data = props.value || {}
                  let value = e?.target?.value
                  value = value.replace(/[^0-9.]/g, '')
                  // 防止多个小数点
                  if ((value.match(/\./g) || []).length > 1) {
                    value = value.replace(/\.(?=.*\.)/g, '')
                  }
                  data.amount = value
                  props?.onChange?.(data)
                }}
                placeholder={`请输入${config?.deposit_min_amount}-${config?.deposit_max_amount}元`}
              />
              <div
                onClick={() => {
                  const data = props.value || {}
                  data.amount = ''
                  props?.onChange?.(data)
                }}
                className={styles.inputAmountCleaar}
              ></div>
            </div>
          </div>
        </div>
        {error && (
          <div className={styles.depositAmountErrorTips}>
            {`请输入正确的存款金额(${config?.deposit_min_amount}-${config?.deposit_max_amount})`}
          </div>
        )}
        <div className={styles.tipsContent}>
          <span
            className={styles.usdtTips}
          >{`预计支付 ${estimateAmount} USDT，`}</span>
          <span className={styles.usdtTips}>
            {`参考汇率 1USDT ≈ ${config?.exchange}CNY`}
          </span>
        </div>
        <div className={styles.usdtTips}>实际到账金额将以支付时的汇款计算</div>
      </div>
    </div>
  )
}

const Body = () => {
  const naviagte = useNavigate()
  const [formData, setFormData] = useState({
    depositWay: 0,
    amount: '',
    protocol: '0'
  })
  const navigate = useNavigate()

  const { data: typeList, isLoading, error } = useGetAgentTypes()

  const { trigger, isMutating } = useAgentPay()

  const btnDisabled = useMemo(() => {
    if (!typeList) {
      return
    }
    const config = typeList[formData.depositWay]
    if (config) {
      if (!formData.amount) {
        return true
      }
      const { deposit_min_amount, deposit_max_amount } = config
      const amount = Number(formData.amount || 0)
      if (amount < Number(deposit_min_amount)) {
        return true
      }
      if (amount > Number(deposit_max_amount)) {
        return true
      }
      return false
    }
  }, [typeList, formData])

  const handleSubmit = async () => {
    const config = typeList[formData.depositWay]
    let expectedUsdt = Number(formData?.amount || 0)
    expectedUsdt = (expectedUsdt * 100) / (Number(config?.exchange || 0) * 100)
    try {
      const data = await trigger({
        payAmt: formData.amount,
        expectedUsdt: expectedUsdt,
        payType: config.pay_type_id,
        protocol: formData.protocol
      })
      openLink(data?.payUrl)
      navigate('/recharge/orderInfo', {
        state: data
      })
    } catch (error: any) {
      Toast.show(error?.message)
    }
  }

  return (
    <div>
      <SkeletonUI data={typeList} isLoading={isLoading} error={error} block={3}>
        <form>
          <DepositWays
            value={formData.depositWay}
            onChange={(v) => {
              setFormData({
                ...formData,
                depositWay: v
              })
            }}
          />
          {/* {formData.depositWay === 0 && <DepositMoney />} */}

          {typeList?.map?.((item, index) => {
            return (
              <div key={index}>
                {formData.depositWay === index ? (
                  <>
                    {item.pay_type_id === '1003' && (
                      <DepositVirtual
                        value={formData}
                        config={typeList?.[formData.depositWay]}
                        onChange={(v) => setFormData({ ...v })}
                      />
                    )}
                    {item.pay_type_id !== '1003' && (
                      <DepositMoney
                        config={item}
                        value={formData}
                        onChange={(v) => setFormData({ ...v })}
                      />
                    )}
                  </>
                ) : null}
              </div>
            )
          })}
        </form>

        <div className={styles.rechargeFooter}>
          <Button
            onClick={handleSubmit}
            disabled={btnDisabled}
            loading={isMutating}
            className={styles.rechargeBtn}
            style={{ '--text-color': 'var(--adm-color-white)' }}
          >
            立即存款
          </Button>
          <div className={styles.rechargeChat}>
            如需帮助，请联系
            <span
              onClick={() => {
                naviagte('/online')
              }}
            >
              合营咨询
            </span>
          </div>
        </div>
      </SkeletonUI>
    </div>
  )
}

export default Body
