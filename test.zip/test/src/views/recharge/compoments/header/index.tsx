import { NoticeBar } from 'antd-mobile'
import React, { useState } from 'react'
import IconImage from '@/compoments/IconImage'
import TrumpetPng from '@/assets/common/trumpet.png'
import WalletIcon from '@/assets/common/walletIcon.png'
import HideEyePng from '@/assets/common/hideEye.png'
import SecurityCheck from '@/compoments/securityCheck'
import { useGetDrawMoney } from '@/views/main/members/api'
import styles from './index.module.scss'

const Header = () => {
  const [scrollText, setScrollText] = useState('暂无公告，请留意平台最新动态')

  const [amount, setAmount] = useState('****')
  const [showSecurity, setShowSecurity] = useState(false)
  const { trigger } = useGetDrawMoney()
  return (
    <div>
      <NoticeBar
        icon={<IconImage imagePath={TrumpetPng} className={styles.trumpet} />}
        className={styles.notceBar}
        color="default"
        content={
          <div className={styles.spantext}>
            <span>{scrollText}</span>
            <span>{scrollText}</span>
            <span>{scrollText}</span>
          </div>
        }
      />

      <div className={styles.balanceWarp}>
        <div className={styles.balanceView}>
          <div className={styles.top}>
            <IconImage imagePath={WalletIcon} className={styles.image} />
            <span className={styles.balanceBox}>
              当前余额:
              <span className={styles.balance}>{amount}</span>
            </span>
            {amount === '****' && (
              <IconImage
                onClick={() => setShowSecurity(true)}
                imagePath={HideEyePng}
                className={styles.hideEye}
              />
            )}
          </div>

          <div className={styles.tips}>
            额度仅能用于下线会员代存或代理转账，不可取款提现
          </div>
        </div>
      </div>

      <SecurityCheck
        eyesType={3}
        onSussess={async () => {
          //请求数据
          await trigger({}).then((data) => {
            setAmount(data?.valetMoney)
            setShowSecurity(false)
          })
        }}
        visible={showSecurity}
        onClose={() => setShowSecurity(false)}
      />
    </div>
  )
}

export default Header
