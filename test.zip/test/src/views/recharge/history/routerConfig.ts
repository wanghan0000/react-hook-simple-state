export default {
    name: "history",
    author: true,
    /**是否是根路由 */
    isRootRouter: true
};
  