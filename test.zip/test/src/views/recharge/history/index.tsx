import HeaderUI from '@/compoments/HeaderUI'
import FormFilter from '@/compoments/formFilter'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import LoadMoreList from '@/compoments/loadMoreList'
import { getCurrentDateString, getStartAndEndOfMonth } from '@/utils/date'
import DescriptionCard from '@/compoments/descriptionCard'
import { useGetFinancePayRecordList } from './api'
import { Toast } from 'antd-mobile'
import styles from './index.module.scss'

const payStatusOptions = [
  { value: -1, label: '全部' },
  { value: 1, label: '待确认' },
  { value: 2, label: '存款成功' },
  { value: 4, label: '已取消' },
]
const payTypeOptions = [
    { value: 0, label: '全部' },
    { value: 1001, label: '银行卡转卡' },
    { value: 1002, label: '支付宝' },
    { value: 1003, label: 'usdt 扫码提款' },
  ]

const DepositRecordItem = (props: any) => {
  const bodyColumns = useMemo(
    () => [
      { group: [{ title: '申请时间', text: props.createdAt }] },
      { group: [{ title: '订单号', text: props.billNo }] },
      { group: [{ title: '支付方式', text: props.payTypeName }] }
    ],
    [props]
  )
  return (
    <DescriptionCard
      topNode={
        <div className={styles.recordTop}>
          <span className={styles.recordAmount}>¥{props?.vAmount}</span>
          <div className={styles.recordStatus3}>
            <i></i>
            <div>{props.vStateText}</div>
          </div>
        </div>
      }
      bodyColumns={bodyColumns}
    />
  )
}

const DepositRecord = () => {
  const navigate = useNavigate()

  const [formData, setFormData] = useState({
    payStatus: -1, // 支付状态 1: 待确认, 2: 存款成功 4: 已取消
    payType: 0, // 支付类型 1001 //银行卡转卡 1002 //支付宝 1003 //usdt 扫码提款 
    startDate: getStartAndEndOfMonth(0).startOfMonth,
    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
  })

  const { pager, filter, reset, nextPage, error } = useGetFinancePayRecordList(formData)

  const columns = useMemo(
    () => [
        {
            domType: FormDomTypes.select,
            placeHolder: '选择状态',
            prop: 'payStatus',
            width: '120px',
            options: payStatusOptions,
        },
        {
            domType: FormDomTypes.select,
            prop: 'payType',
            placeHolder: '选择交易类型',
            options: payTypeOptions,
            width: '120px'
        },
        {
            domType: FormDomTypes.dateRange,
            prop: ['startDate', 'endDate'],
            placeHolder: ['开始时间', '结束时间']
        },
        {
            domType: FormDomTypes.reset,
            onClick: () => {
                const params = {
                    payStatus: -1,
                    payType: 0,
                    startDate: getStartAndEndOfMonth(0).startOfMonth,
                    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
                }
                setFormData(params)
                reset(params)
            }
        },
        {
            domType: FormDomTypes.filter,
            onClick: () => {
                filter(formData)
            }
        }
    ],
    [formData, filter]
  )

  async function loadMore() {
    await nextPage(formData)
  }

  useEffect(() => {
    if (error) {
      Toast.show({
        content: error?.message,
      })
      setFormData({
        ...formData,
        startDate: getStartAndEndOfMonth(0).startOfMonth,
        endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
      })
    }
  }, [error])

  return (
    <div>
      <HeaderUI
        title="充值记录"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />
      <div className={styles.depositRecordBox}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>

      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <DepositRecordItem {...item} />
          }}
          itemClassName={styles.depositRecordItem}
        />
      </div>
    </div>
  )
}

export default DepositRecord
