import { usePagePlus } from '@/commonHooks/usePagePlus'

const payStatusOptions = [
  { value: 1, label: '待确认' },
  { value: 2, label: '存款成功' },
  { value: 4, label: '已取消' },
]
export function useGetFinancePayRecordList(params) {
   function transformData(data: any) {
      return data.map((v)=>{
          return {
              ...v,
              vAmount: Number(v.orderAmount)?.toFixed?.(2),
              vStateText: payStatusOptions.find((item) => item.value === v.payStatus)
                ?.label
          }
      })
   }
    
  return usePagePlus({
    catchKey: 'useGetFinancePayRecordList',
    apiPath: '/finance/edu/payRecordsList',
    formData: params,
    transformData: transformData
  })
}
