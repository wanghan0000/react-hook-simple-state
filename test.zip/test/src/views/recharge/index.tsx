import HeaderUI from '@/compoments/HeaderUI'
import React from 'react'
import { useNavigate } from 'react-router'
import RecordPng from '@/assets/common/record.png'
import Header from './compoments/header'
import Body from './compoments/body'
import styles from './index.module.scss'

const Recharge = () => {
  const navigate = useNavigate()
  return (
    <div>
      <HeaderUI
        title="额度充值"
        showBack={true}
        onClickBack={() => navigate(-1)}
        rightNode={
          <>
            <img
              onClick={() => {
                navigate('/recharge/history')
              }}
              className={styles.record}
              src={RecordPng}
              alt="RecordPng"
            />
          </>
        }
      />
      <div className={styles.content}>
        <Header />
      </div>
      <div className={styles.body}>
        <Body />
      </div>
    </div>
  )
}

export default Recharge
