export default {
    name: "forgetPassword",
};
  