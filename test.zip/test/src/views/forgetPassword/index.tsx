import { Button, Input, List, Steps, Tabs, Toast } from 'antd-mobile'
import React, { useEffect, useMemo, useState } from 'react'
import HeaderUI from '@/compoments/HeaderUI'
import { useNavigate } from 'react-router'
import IconImage from '@/compoments/IconImage'
import StepIconActivity from '@/assets/common/stepIconActivity.png'
import SetpIcon from '@/assets/common/stepIcon.png'
import FormList, { FormListItemType } from '@/compoments/formList'
import {
  useForgetCheckInfo,
  useGetSecurityQuestionNoLogin,
  useModifyUserPassNoLogin,
  useVerifySecurityNoLogin
} from './api'
import SkeletonUI from '@/compoments/SkeletonUI'
import RefreshPng from '@/assets/common/refresh.png'
import { md5Hash } from '@/utils/md5'
import styles from './index.module.scss'
import { containsTwoLetters } from '@/logicUtils'

const Step3 = (props: any) => {
  const { isMutating, trigger } = useModifyUserPassNoLogin()

  const naviagate = useNavigate()
  const [formData, setFormData] = useState({
    secondPassword: '',
    confirmPassword: ''
  })

  


  const handleSubmit = async () => {
    try {
      await trigger({
        agentName: props.agentName,
        confirmPassword: md5Hash(formData.confirmPassword),
        secondPassword: md5Hash(formData.secondPassword)
      })
      Toast.show('修改成功')
      naviagate('/login', {
        replace: true
      })
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }

  const reg = /[^0-9A-Za-z]/
  const rules = {
    secondPassword: {
      validate: (value) => {
        if (!value || !value.length) {
          return true
        }
        if (
          value.length < 8 ||
          value.length > 12 ||
          !containsTwoLetters(value, 1) ||
          reg.test(value)
        ) {
          return false
        }
        return true
      }
    },
    confirmPassword: {
      validate: (value) => {
        if (!value || !value.length) {
          return true
        }
        if(value !== formData.secondPassword) {
          return false
        }
        return true
      }
    }
  }

  const columns = [
    {
      domType: FormListItemType.password,
      prefix: '新登录密码',
      prop: 'secondPassword',
      placeHolder: '输入新的代理登录密码',
      maxLength: 12,
      tips: '代理密码长度为8-12位，字母+数字组合'
    },
    {
      domType: FormListItemType.password,
      prefix: '确认密码',
      prop: 'confirmPassword',
      placeHolder: '再次输入代理登录密码',
      maxLength: 12,
      tips: !rules.confirmPassword.validate(formData.confirmPassword) ? '两次密码输入不一致' : ''
    }
  ]

  const btnButtonState = useMemo(() => {
    if (!formData.secondPassword.length) {
      return true
    }
    if (!formData.confirmPassword.length) {
      return true
    }
    let state = rules.secondPassword.validate(formData.secondPassword)
    if(!state) {
      return true
    }
    state = rules.confirmPassword.validate(formData.confirmPassword)
    if(!state) {
      return true
    }
    return false
  }, [formData])


  return (
    <>
      <FormList
        className={styles.formList + ' ' + styles.formListStep3}
        columns={columns}
        values={formData}
        onChange={(v) => {
          setFormData(v)
        }}
        rules={rules}
      />

      <div className={styles.addFooter}>
        <Button
          disabled={btnButtonState}
          loading={isMutating}
          onClick={handleSubmit}
          className={styles.addBtn}
          style={{ '--text-color': 'var(--adm-color-white)' }}
        >
          验证
        </Button>
        <div className={styles.addChat}>
          如需帮助，请联系
          <span
            onClick={() => {
              naviagate('/online')
            }}
          >
            合营咨询
          </span>
        </div>
      </div>
    </>
  )
}

const Step2 = (props: any) => {
  const naviagate = useNavigate()
  const [formData, setFormData] = useState({
    answer: ''
  })
  const { data, error, isMutating, trigger } = useGetSecurityQuestionNoLogin()
  const [isLoading, setIsLoading] = useState(true)
  const { trigger: triggerSubmit, isMutating: submitMutating } =
    useVerifySecurityNoLogin()

  const btnStatus = useMemo(() => {
    if (formData.answer.length < 6) {
      return true
    }
    return false
  }, [formData])
  useEffect(() => {
    trigger({
      agentName: props.agentName
    })
      .then(() => {
        setIsLoading(false)
      })
      .catch((error) => {
        Toast.show(error?.message || JSON.stringify(error))
        setIsLoading(false)
      })
  }, [])

  const handleSubmit = async () => {
    try {
      await triggerSubmit({
        ...formData,
        question: data?.question,
        agentName: props.agentName
      })
      props?.onSuccess?.()
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }
  return (
    <>
      <SkeletonUI block={2} data={data} isLoading={isLoading} error={error}>
        <div className={styles.main}>
          <List>
            <List.Item>
              <>
                <div className={styles.title}>
                  <div className={styles.titleText}>{data?.question}</div>
                  <div
                    className={styles.right}
                    onClick={() => {
                      if (isMutating) {
                        return
                      }
                      trigger({
                        agentName: props.agentName
                      })
                    }}
                  >
                    <IconImage
                      imagePath={RefreshPng}
                      className={
                        styles.iamge +
                        ' ' +
                        (isMutating ? styles.loadingImage : '')
                      }
                    />
                    换一题
                  </div>
                </div>
                <div className={styles.input}>
                  <Input
                    placeholder="请输入密保答案"
                    value={formData.answer}
                    onChange={(v) => {
                      setFormData({
                        ...formData,
                        answer: v
                      })
                    }}
                  />
                </div>
              </>
            </List.Item>
          </List>
        </div>

        <div className={styles.addFooter}>
          <Button
            disabled={btnStatus}
            loading={submitMutating}
            className={styles.addBtn}
            onClick={handleSubmit}
            style={{ '--text-color': 'var(--adm-color-white)' }}
          >
            下一步，设置新密码
          </Button>
          <div className={styles.addChat}>
            如需帮助，请联系
            <span
              onClick={() => {
                naviagate('/online')
              }}
            >
              合营咨询
            </span>
          </div>
        </div>
      </SkeletonUI>
    </>
  )
}
function isEmailValid(email) {
  // 使用正则表达式来匹配邮箱地址是否以 @outlook.com 或 @gmail.com 结尾
  const regex = /@(outlook\.com|gmail\.com)$/i

  // 返回匹配结果
  return regex.test(email)
}

const Step1 = (props: any) => {
  const naviagate = useNavigate()
  const [formData, setFormData] = useState({
    agentName: '',
    authCode: '',
    gmail: ''
  })

  const { trigger, isMutating } = useForgetCheckInfo()
  const columns = [
    {
      domType: FormListItemType.input,
      prefix: '代理账号',
      prop: 'agentName',
      placeHolder: '请输入代理账号',
      maxLength: 12
    },
    {
      domType: FormListItemType.input,
      prefix: '身份验证',
      prop: 'authCode',
      placeHolder: '请输入身份验证',
      show: props.type === '3',
      maxLength: 6,
      tips: '请输入6位身份验证码'
    },
    {
      domType: FormListItemType.input,
      prefix: '邮箱账号',
      prop: 'gmail',
      placeHolder: '请输入代理邮箱',
      show: props.type === '2',
      tips: '代理邮箱账号仅支持@outlook.com或@gmail.com'
    }
  ]

  const rules = {
    gmail: {
      validate: (value) => {
        if (!value || !value.length) {
          return true
        }
        return isEmailValid(value)
      }
    },
    authCode: {
      validate: (value) => {
        if (!value || !value.length) {
          return true
        }
        return value.length === 6
      }
    }
  }

  const btnButtonState = useMemo(() => {
    if (!formData.agentName.length) {
      return true
    }
    if (props.type === '3') {
      if (!formData.authCode?.length) {
        return true
      }
      if (formData.authCode.length !== 6) {
        return true
      }
    }
    if (props.type === '2') {
      if (!isEmailValid(formData.gmail)) {
        return true
      }
      if (!formData.gmail.length) {
        return true
      }
    }
    return false
  }, [formData, props])

  const handleSubmit = async () => {
    try {
      await trigger({
        agentName: formData.agentName,
        type: props.type,
        authCode: props.type === '3' ? formData.authCode : undefined,
        gmail: props.type === '2' ? formData.gmail : undefined
      })
      props.onSuccess?.(formData.agentName)
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }
  return (
    <>
      <FormList
        className={styles.formList + ' ' + styles.formListStep3}
        columns={columns}
        values={formData}
        rules={rules}
        onChange={(v) => {
          setFormData(v)
        }}
      />

      <div className={styles.addFooter}>
        <Button
          disabled={btnButtonState}
          loading={isMutating}
          onClick={handleSubmit}
          className={styles.addBtn}
          style={{ '--text-color': 'var(--adm-color-white)' }}
        >
          验证
        </Button>
        <div className={styles.addChat}>
          如需帮助，请联系
          <span
            onClick={() => {
              naviagate('/online')
            }}
          >
            合营咨询
          </span>
        </div>
      </div>
    </>
  )
}

const ForgetPassword = () => {
  const [status, setStatus] = useState('0')
  const navigate = useNavigate()

  const [current, setCurrent] = useState(0)
  const [agentName, setAgentName] = useState('')
  return (
    <div>
      <HeaderUI
        title={'找回密码'}
        showBack={true}
        onClickBack={() => {
          navigate(-1)
        }}
      />
      {current === 0 && (
        <Tabs
          className={styles.tabs}
          activeLineMode="fixed"
          onChange={(v) => {
            setStatus(v)
          }}
          style={{
            '--fixed-active-line-width': '140px',
            '--title-font-size': '14px'
          }}
        >
          <Tabs.Tab
            title={
              <span
                className={
                  styles.tabsTitle +
                  ' ' +
                  (status === '0' ? styles.activityTile : '')
                }
              >
                身份验证码验证
              </span>
            }
            key="0"
          />
          <Tabs.Tab
            title={
              <span
                className={
                  styles.tabsTitle +
                  ' ' +
                  (status === '1' ? styles.activityTile : '')
                }
              >
                代理邮箱验证
              </span>
            }
            key="1"
          />
        </Tabs>
      )}

      <div className={styles.stepsContent}>
        <Steps current={current}>
          <Steps.Step
            title="身份验证"
            className={current >= 0 ? styles.activityStep : ''}
            icon={
              <IconImage
                className={styles.imageIcon}
                imagePath={current >= 0 ? StepIconActivity : SetpIcon}
              />
            }
          />
          <Steps.Step
            title="安全校验"
            className={current >= 1 ? styles.activityStep : ''}
            icon={
              <IconImage
                className={styles.imageIcon}
                imagePath={current >= 1 ? StepIconActivity : SetpIcon}
              />
            }
          />
          <Steps.Step
            title="设置新密码"
            className={current >= 2 ? styles.activityStep : ''}
            icon={
              <IconImage
                className={styles.imageIcon}
                imagePath={current >= 2 ? StepIconActivity : SetpIcon}
              />
            }
          />
        </Steps>
      </div>

      <div className={styles.content}>
        {current === 0 && (
          <Step1
            onSuccess={(agentName) => {
              setCurrent(1)
              setAgentName(agentName)
            }}
            type={status === '0' ? '3' : '2'}
          />
        )}
        {current === 1 && (
          <Step2
            agentName={agentName}
            onSuccess={() => {
              setCurrent(2)
            }}
          />
        )}
        {current === 2 && <Step3 agentName={agentName} />}
      </div>
    </div>
  )
}

export default ForgetPassword
