import { apiFetcher } from '@/api/api'
import useSWRMutation from 'swr/mutation'

export function useForgetCheckInfo() {
  const params = {
    path: '/member/forgetPassWord/checkInfo',
    type: 'post',
    needToken: false
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

export function useGetSecurityQuestionNoLogin() {
  const params = {
    path: '/member/forgetPassWord/getSecurityQuestionNoLogin',
    type: 'post',
    needToken: false
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

export function useVerifySecurityNoLogin() {
  const params = {
    path: '/member/forgetPassWord/verifySecurityNoLogin',
    type: 'post',
    needToken: false
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

export function useModifyUserPassNoLogin() {
  const params = {
    path: '/member/forgetPassWord/modifyUserPassNoLogin',
    type: 'post',
    needToken: false
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}
