import { apiFetcher, useSWRExpand } from '@/api/api'
import { usePagePlus } from '@/commonHooks/usePagePlus'

/**获取个人财务数据 缓存10秒*/
export function useGetExcelTotal(params) {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/finance/excel/total',
        type: 'post'
      },
      {
        arg: params
      }
    )
  }
  return useSWRExpand('useGetExcelTotal' + JSON.stringify(params), fetcherFuc, {
    dedupingInterval: 30 * 1000
  })
}

/**获取团队财务*/
export function useTeamReport(params) {
  return usePagePlus({
    catchKey: 'useTeamReport',
    apiPath: '/team/teamReport',
    formData: params
  })
}
