export default {
    name: "financial",
    author: true
};
  