import { Tabs } from 'antd-mobile'
import React, { useState } from 'react'
import { useGetAgentDepositConfig } from '@/views/main/members/api'
import styles from './index.module.scss'

interface TopTabsPops {
  index: string
  onChange(index: string)
}

const TopTabs = (props: TopTabsPops) => {
  const { data, isLoading } = useGetAgentDepositConfig()

  return (
    <div className={styles.topTabs}>
      <Tabs
        activeKey={props.index}
        className={styles.tabs}
        activeLineMode="fixed"
        onChange={(v) => {
          props.onChange(v)
        }}
        style={{
          '--fixed-active-line-width': '90px',
          '--title-font-size': '14px'
        }}
      >
        <Tabs.Tab
          title={
            <span
              className={
                styles.tabsTitle +
                ' ' +
                (props.index === '0' ? styles.activityTile : '')
              }
            >
              个人财务
            </span>
          }
          key="0"
        />
        <Tabs.Tab
          title={
            <span
              className={
                styles.tabsTitle +
                ' ' +
                (props.index === '1' ? styles.activityTile : '')
              }
            >
              {data?.isTeamLeader === 1 ? '团队财务' : '小组财务'}
            </span>
          }
          key="1"
        />
      </Tabs>
    </div>
  )
}

export default TopTabs
