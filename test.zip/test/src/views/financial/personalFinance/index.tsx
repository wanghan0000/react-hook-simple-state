import React, { useEffect, useMemo, useState } from 'react'

import { getCurrentDateString, getStartAndEndOfMonth } from '@/utils/date'
import { useGetExcelTotal } from '../api'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import FormFilter from '@/compoments/formFilter'
import IconImage from '@/compoments/IconImage'
import { SpinLoading, Toast } from 'antd-mobile'
import AmountIcon from '@/assets/common/amontIcon.png'
import styles from './index.module.scss'
import { Navigate, useNavigate } from 'react-router'
import { ExclamationCircleOutline } from 'antd-mobile-icons'

const FinancialItem = (props: any) => {
  const navigator = useNavigate()
  return (
    <div className={styles.financialItem}>
      <div
        onClick={() => {
          props?.url && navigator(props.url)
        }}
      >
        {props.text}
        {props?.url && (
          <ExclamationCircleOutline style={{ marginLeft: '4px' }} />
        )}
      </div>
      <div>{props.value}</div>
    </div>
  )
}

const PersonalFinance = () => {
  const [formData, setFormData] = useState({
    startDate: getStartAndEndOfMonth(0).startOfMonth,
    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
  })
  const [requestParams, setRequestParmas] = useState({
    ...formData
  })
  const { data, isValidating, error } = useGetExcelTotal(requestParams)
  const depositAndWithdrawData = useMemo(() => {
    return [
      {
        text: '存款',
        value: data?.deposit ? '¥' + Number(data?.deposit).toFixed(2) : '¥0.00'
      },
      {
        text: '提款',
        value: data?.draw ? '¥' + Number(data?.draw).toFixed(2) : '¥0.00'
      }
    ]
  }, [data])
  const otherData = useMemo(() => {
    return [
      {
        text: '红利',
        value: data?.promo ? Number(data?.promo).toFixed(2) : '0.00'
      },
      {
        text: '返水',
        value: data?.rebate ? Number(data?.rebate).toFixed(2) : '0.00'
      },
      {
        text: '场馆费',
        value: data?.thirdPartySpend
          ? Number(data?.thirdPartySpend).toFixed(2)
          : '0.00'
      },
      {
        text: '账户调整',
        value: data?.adjust ? Number(data?.adjust).toFixed(2) : '0.00'
      },
      {
        text: '存提手续费',
        value: data?.fee ? Number(data?.fee).toFixed(2) : '0.00',
        url: '/financial/personalFinance/feeDetails'
      }
    ]
  }, [data])

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.dateRange,
        prop: ['startDate', 'endDate'],
        placeHolder: ['开始时间', '结束时间'],
        maxDate: new Date()
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            startDate: getStartAndEndOfMonth(0).startOfMonth,
            endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
          }
          setFormData(params)
          setRequestParmas(params)
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          setRequestParmas({ ...formData })
        },
        className: styles.filter
      }
    ],
    [formData]
  )

  useEffect(() => {
    if (error) {
      Toast.show(error?.message)
      const params = {
        startDate: getStartAndEndOfMonth(0).startOfMonth,
        endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
      }
      setFormData(params)
    }
  }, [error])

  return (
    <div className={styles.financial}>
      <div className={styles.formBox}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>

      <div className={styles.infoBox}>
        <div className={styles.info}>
          <div className={styles.infoTitle}>
            <IconImage className={styles.imageIcon} imagePath={AmountIcon} />
            <span>总输赢</span>
          </div>
          <p className={styles.infoAmount}>
            {data?.profit ? Number(data?.profit).toFixed(2) : '0.00'}
          </p>
        </div>
        <div className={styles.info}>
          <div className={styles.infoTitle}>
            <IconImage className={styles.imageIcon} imagePath={AmountIcon} />
            <span>净输赢</span>
          </div>
          <p className={styles.infoAmount}>
            {data?.netProfit ? Number(data?.netProfit).toFixed(2) : '0.00'}
          </p>
        </div>
      </div>

      <div className={styles.depositWithdrawal}>
        <p className={styles.title}>存提数据</p>
        {depositAndWithdrawData.map((v, index) => {
          return <FinancialItem key={index} {...v} />
        })}
      </div>

      <div className={styles.otherContent}>
        <p className={styles.title}>存提数据</p>
        {otherData.map((v, index) => {
          return <FinancialItem key={index} {...v} />
        })}
      </div>

      <div className={styles.tipsBox}>
        <p>温馨提示</p>
        <p>
          总输赢、净输赢中正数表示公司盈利，负数表示公司亏损，每天数据只做普通参考，并不做实际佣金派发标准。
        </p>
      </div>

      {isValidating && (
        <div className={styles.loadingUI}>
          <SpinLoading color="primary" />
        </div>
      )}
    </div>
  )
}

export default PersonalFinance
