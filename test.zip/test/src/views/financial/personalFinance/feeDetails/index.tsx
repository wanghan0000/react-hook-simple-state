/*
 * @Author: Mark
 * @Date: 2024-05-22 17:02:28
 * @LastEditTime: 2024-05-27 16:49:25
 * @LastEditors: MarkMark
 * @Description: 佛祖保佑无bug
 * @FilePath: /agent_h5/src/views/financial/personalFinance/feeDetails/index.tsx
 */
import HeaderUI from '@/compoments/HeaderUI'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import React, { useEffect, useMemo, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import { useGetExcelPayDrawFee } from './api'
import SwiperTabs from '@/compoments/SwiperTabs'
import { List, PullToRefresh, SpinLoading } from 'antd-mobile'
import { sleep } from 'antd-mobile/es/utils/sleep'
import Styles from './index.module.scss'
import { title } from 'process'
import SpinLoadingUI from '@/compoments/SpinLoadingUI'
import NoDataUI from '@/compoments/NoDataUI'
interface IFFeeDetail {
  payType: number
  payTypeStr: string
  fee: string
  money: string
  rate: string
}
interface IFFeeData {
  depositData: IFFeeDetail[]
  withdrawalData: IFFeeDetail[]
}
const columnsDeposit = [
  { id: 0, title: '存款方式' },
  { id: 1, title: '金额' },
  { id: 2, title: '费率' },
  { id: 3, title: '手续费' }
]
const columnsWithdraw = [
  { id: 0, title: '提款方式' },
  { id: 1, title: '取款金额' },
  { id: 2, title: '费率' },
  { id: 3, title: '手续费' }
]
const DepositeFee = ({ columns, resData, mutate }) => {

  return (
    <div className={Styles.feeDetailsWrap_DepositeFee}>
      <div className={Styles.feeDetailsWrap_DepositeFee_header}>
        {columns?.map((item, index) => <p key={index}>{item.title}</p>)}
      </div>
      <div className={Styles.feeDetailsWrap_DepositeFee_content}>
        {resData?.length > 0 ? (
          <PullToRefresh
            onRefresh={async () => {
              await sleep(1000)
              await mutate()
            }}
          >
            {resData?.map((item, index) => (
              <List
                key={index}
                className={Styles.feeDetailsWrap_DepositeFee_content_list}
              >
                <List.Item key={item.payType}>{item.payTypeStr}</List.Item>
                <List.Item key={item.money}>{item.money}</List.Item>
                <List.Item key={item.rate}>{item.rate}</List.Item>
                <List.Item key={item.fee}>{item.fee}</List.Item>
              </List>
            ))}
          </PullToRefresh>
        ) : (
          resData?.length == 0  && <NoDataUI/>
        )}
      </div>
    </div>
  )
}
const WithdrawFee = ({ columns, resData, mutate }) => {
  return <DepositeFee columns={columns} resData={resData} mutate={mutate} />
}
const Feedetails = () => {
  const navigate = useNavigate()
  const [activeIndex, setActiveIndex] = useState(0)

  const [tabItems, setTabItems] = useState([
    { key: 'depositeFee', title: '存款手续费' },
    { key: 'withdrawFee', title: '提款手续费' }
  ])
  const {
    data: resData,
    mutate,
    isLoading,
    isValidating,
    error,
    randomKey
  } = useGetExcelPayDrawFee({
    feeType: activeIndex == 0 ? 1 : 3
  })
  
  
  const childComponents = [
    <DepositeFee
      key={0}
      columns={columnsDeposit}
      resData={resData?.data}
      mutate={mutate}
    />,
    <WithdrawFee
      key={1}
      columns={columnsWithdraw}
      resData={resData?.data}
      mutate={mutate}
    />
  ]

  return (
    <div className={Styles.feeDetailsWrap}>
      <HeaderUI
        title="存提手续费详情"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />
      <SwiperTabs
        tabItems={tabItems}
        activeIndex={activeIndex}
        setActiveIndex={setActiveIndex}
        childComponents={childComponents}
      />
      {isLoading && (
          <SpinLoadingUI/>
      )}
    </div>
  )
}

export default Feedetails
