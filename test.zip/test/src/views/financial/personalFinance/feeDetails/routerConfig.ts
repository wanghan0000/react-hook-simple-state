/*
 * @Author: Mark
 * @Date: 2024-05-22 20:33:54
 * @LastEditTime: 2024-05-22 20:33:56
 * @LastEditors: MarkMark
 * @Description: 佛祖保佑无bug
 * @FilePath: /agent_h5/src/views/financial/personalFinance/feeDetails/routerConfig.ts
 */
export default {
    name: "feeDetails",
    author: true,
    isRootRouter: true
};
  