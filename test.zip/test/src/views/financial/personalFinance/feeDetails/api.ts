import { apiFetcher, useSWRExpand } from '@/api/api'
import { usePagePlus } from '@/commonHooks/usePagePlus'

/**财务报表，存提手续费详情 缓存10秒*/
export function useGetExcelPayDrawFee(params) {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/finance/excel/payDrawFee',
        type: 'post'
      },
      {
        arg: params
      }
    )
  }
  return useSWRExpand('useGetExcelPayDrawFee' + JSON.stringify(params), fetcherFuc, {
    dedupingInterval: 30 * 1000
  })
}

/**获取团队财务*/
export function useTeamReport(params) {
  return usePagePlus({
    catchKey: 'useTeamReport',
    apiPath: '/team/teamReport',
    formData: params
  })
}
