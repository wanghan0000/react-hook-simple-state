import FormFilter from '@/compoments/formFilter'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import { getMonth, getStartAndEndOfMonth } from '@/utils/date'
import React, { useMemo, useState } from 'react'
import LoadMoreList from '@/compoments/loadMoreList'
import { useTeamReport } from '../api'
import DescriptionCard from '@/compoments/descriptionCard'
import styles from './index.module.scss'
import { useApiGetAllGroup } from '@/views/main/commissions/api'

const TeamInfoItem = (props: any) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [
          { title: '代理账号', text: props?.agentName },
          { title: '存款', text: `${props?.deposit}` }
        ]
      },
      {
        group: [
          { title: '提款', text: props?.draw },
          { title: '总输赢', text: `${props?.netAmount}` }
        ]
      },
      {
        group: [
          { title: '场馆费', text: props?.thirdPartySpend },
          { title: '红利', text: `${props?.promo}` }
        ]
      },
      {
        group: [
          { title: '返水', text: props?.rebate },
          { title: '净输赢', text: `${props?.netProfit}` }
        ]
      },
      {
        group: [
          { title: '补单输赢', text: props?.repairNetProfit },
          { title: '存提手续费', text: `${props?.fee}` }
        ]
      }
    ],
    [props]
  )
  return <DescriptionCard bodyColumns={bodyColumns} />
}

const TeamInfo = () => {
  const [formData, setFormData] = useState({
    groupName: -1,
    agentName: '',
    commissionDate: getMonth(-1).startOfMonth
  })
  const { filter, pager, nextPage, reset, error } = useTeamReport({
    ...formData
  })

  //const { data: options } = useApiGetAllGroup()

  // const dictGroups = useMemo(() => {
  //   if (options?.length) {
  //     const arr = [...options]
  //     arr.unshift({
  //       value: -1,
  //       label: '全部'
  //     })
  //     return arr
  //   } else {
  //     return [
  //       {
  //         value: -1,
  //         label: '全部'
  //       }
  //     ]
  //   }
  // }, [options])

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.search,
        placeHolder: '代理账号',
        prop: 'agentName',
        width: '150px'
      },
      // {
      //   domType: FormDomTypes.select,
      //   placeHolder: '代理小组',
      //   prop: 'groupName',
      //   width: '130px',
      //   options: dictGroups
      // },
      {
        domType: FormDomTypes.date,
        prop: 'commissionDate',
        dateFormat: 'month',
        width: '150px',
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            groupName: -1,
            agentName: '',
            commissionDate: getMonth(-1).startOfMonth
          }
          setFormData(params)
          reset(params)
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({ ...formData })
        }
      }
    ],
    [formData]
  )

  async function loadMore() {
    await nextPage({
      ...formData
    })
  }

  return (
    <div>
      <div className={styles.formFilter}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>

      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <TeamInfoItem {...item} />
          }}
          itemClassName={styles.teamInfoItem}
        />
      </div>
    </div>
  )
}

export default TeamInfo
