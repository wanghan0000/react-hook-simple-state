import HeaderUI from '@/compoments/HeaderUI'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import React, { useEffect, useMemo, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import { useGetAgentDepositConfig } from '../main/members/api'
import TopTabs from './components/topTabs'
import PersonalFinance from './personalFinance'
import TeamInfo from './teamInfo'

const Financial = () => {
  const navigate = useNavigate()

  const { data, isLoading } = useGetAgentDepositConfig()

  const loacation = useLocation()
  const [index, setIndex] = useState(loacation?.state?.tableIndex || '0')

  return (
    <div>
      <HeaderUI
        title="财务报表"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      {(!!data?.isTeamLeader || !!data?.isGroupLeader) && (
        <TopTabs index={index} onChange={(v) => setIndex(v)} />
      )}

      {!isLoading && (
        <>
          {index === '0' && <PersonalFinance />}
          {index === '1' && <TeamInfo />}
        </>
      )}
    </div>
  )
}

export default Financial
