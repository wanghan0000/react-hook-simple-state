import HeaderUI from '@/compoments/HeaderUI'
import IconImage from '@/compoments/IconImage'
import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import RecordImage from '@/assets/common/agentDepositRecordIcon.png'
import FormList, { FormListItemType } from '@/compoments/formList'
import { useGetAllGameVenue } from '@/commonApi'
import { Button, Toast } from 'antd-mobile'
import SecurityCheck from '@/compoments/securityCheck'
import { useGetAgentDepositConfig, useGetDrawMoney } from '../main/members/api'
import { useAgentDividendOrder, useGetMemberApiBalance } from './api'
import styles from './index.module.scss'
import { useCheckSecurity } from '../main/myProfile/securityCenter/api'

const Dividend = () => {
  const navigate = useNavigate()

  const [formData, setFormData] = useState({
    disableAmount: '****',
    memberName: '',
    venueId: '',
    flowSetting: '1',
    flowRatio: '',
    amount: '',
    validateType: 1,
    googleCode: '', // 谷歌验证码
    payPassword: '' // 支付密码
  })
  const [showSecurity, setShowSecurity] = useState(false)
  const { data: venues = [] } = useGetAllGameVenue()
  const { trigger } = useGetDrawMoney()
  const { data: depositConfig } = useGetAgentDepositConfig()
  const { trigger: triggerBlance, isMutating: isBalanceLoading } =
    useGetMemberApiBalance()
  const { trigger: triggerSubmit, isMutating: isSubmitLoading } =
    useAgentDividendOrder()
  const { data: config } = useCheckSecurity()

  useEffect(() => {
    if (config?.googleWhite === 1) {
      setFormData({
        ...formData,
        validateType: 2
      })
    }
  }, [config])

  const columns = useMemo(() => {
    const { promoMin, promoMax, turnoverMin, turnoverMax } =
      depositConfig?.agentDividend ?? {}

    let options = [
      { value: 1, label: '谷歌验证码' },
      { value: 2, label: '支付密码' }
    ]

    if (config?.googleWhite === 1) {
      options = [{ value: 2, label: '支付密码' }]
    }

    return [
      {
        domType:
          formData.disableAmount === '****'
            ? FormListItemType.password
            : FormListItemType.text,
        prefix: '可用额度',
        prop: 'disableAmount',
        readonly: true,
        className: 'select-content',
        onClickEye: async () => {
          setShowSecurity(true)
        }
      },
      {
        domType: FormListItemType.input,
        prefix: '下级账号',
        prop: 'memberName',
        placeHolder: '请输入下级账号'
      },
      {
        domType: FormListItemType.select,
        prefix: '场馆',
        prop: 'venueId',
        placeHolder: '请选择场馆',
        options: venues.filter((item) => item.value !== -1),
        className: 'select-content'
      },
      {
        domType: FormListItemType.select,
        prefix: '流水设置',
        prop: 'flowSetting',
        placeHolder: '请选择流水',
        tips: '只限制该笔红利流水，场馆余额强制转出',
        options: [{ value: '1', label: '红利 * 流水倍数' }],
        className: 'select-content'
      },
      {
        domType: FormListItemType.input,
        prefix: '红利金额',
        placeHolder: '请输入红利金额',
        tips: `${promoMin}≤单次红利金额≤${promoMax}`,
        prop: 'amount'
      },
      {
        domType: FormListItemType.input,
        prefix: '流水倍数',
        prop: 'flowRatio',
        placeHolder: '请输入流水倍数',
        tips: `${turnoverMin}≤提款流水倍数≤${turnoverMax}`
      },
      {
        domType: FormListItemType.select,
        prefix: '验证方式',
        prop: 'validateType',
        options: options,
        className: 'select-content'
      },
      {
        domType: FormListItemType.input,
        prefix: '谷歌验证码',
        prop: 'googleCode',
        placeHolder: '请输入谷歌验证码',
        show: formData.validateType === 1
      },
      {
        domType: FormListItemType.input,
        prefix: '支付密码',
        prop: 'payPassword',
        placeHolder: '请输入支付密码',
        show: formData.validateType === 2
      }
    ]
  }, [formData, venues, depositConfig, config])

  const rules = useMemo(() => {
    const { promoMin, promoMax, turnoverMin, turnoverMax } =
      depositConfig?.agentDividend ?? {}
    return {
      amount: {
        validate: (value) => {
          if (!value) {
            return true
          }
          const v = Number(value)
          if (v < Number(promoMin) || v > Number(promoMax)) {
            return false
          }
          return true
        }
      },
      flowRatio: {
        validate: (value) => {
          if (!value) {
            return true
          }
          const v = Number(value)
          if (v < Number(turnoverMin) || v > Number(turnoverMax)) {
            return false
          }
          return true
        }
      }
    }
  }, [depositConfig])

  const handleSubmit = async () => {
    try {
      const data = await triggerBlance({
        memberName: formData.memberName,
        channelCode: venues.find(
          (item: any) => item.value === formData.venueId
        )?.enName
      })
      await triggerSubmit({
        ...formData,
        balance: data?.amount,
        flowRatio: Number(formData.flowRatio)
      })
    } catch (error: any) {
      Toast.show(error?.message)
    }
  }

  const buttonDisabled = useMemo(() => {
    if (isBalanceLoading || isSubmitLoading) {
      return
    }
    const { promoMin, promoMax, turnoverMin, turnoverMax } =
      depositConfig?.agentDividend ?? {}
    const vAmount = Number(formData.amount)
    const vFlowRatio = Number(formData.flowRatio)
    if (vAmount < Number(promoMin) || vAmount > Number(promoMax)) {
      return true
    }
    if (vFlowRatio < Number(turnoverMin) || vFlowRatio > Number(turnoverMax)) {
      return true
    }
    if (!formData.memberName?.length) {
      return true
    }
    if (formData.validateType === 1 && !formData.googleCode?.length) {
      return true
    }
    if (formData.validateType === 2 && !formData.payPassword?.length) {
      return true
    }
    return false
  }, [formData, depositConfig, isBalanceLoading, isSubmitLoading])

  return (
    <div>
      <HeaderUI
        title="推广红利"
        showBack={true}
        onClickBack={() => navigate(-1)}
        rightNode={
          <IconImage
            onClick={() => {
              navigate('/dividend/history')
            }}
            className={styles.recordImage}
            imagePath={RecordImage}
          />
        }
      />

      <FormList
        className={styles.formList}
        columns={columns}
        values={formData}
        rules={rules}
        onChange={(v) => {
          setFormData(v)
        }}
      />

      <div className={styles.agentDividendBtn}>
        <Button
          onClick={handleSubmit}
          loading={isBalanceLoading || isSubmitLoading}
          disabled={buttonDisabled}
        >
          提交
        </Button>
      </div>

      <SecurityCheck
        eyesType={3}
        onSussess={async () => {
          //请求数据
          await trigger({}).then((data) => {
            setFormData({
              ...formData,
              disableAmount: data?.valetMoney
            })
            setShowSecurity(false)
          })
        }}
        visible={showSecurity}
        onClose={() => setShowSecurity(false)}
      />
    </div>
  )
}

export default Dividend
