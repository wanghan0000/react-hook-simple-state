export default {
    name: "history",
    author: true,
    isRootRouter: true
};
  