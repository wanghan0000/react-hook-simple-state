import HeaderUI from '@/compoments/HeaderUI'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'
import FormFilter from '@/compoments/formFilter'
import { getCurrentDateString, getStartAndEndOfMonth } from '@/utils/date'
import { useGetDividendOrderList } from '../api'
import { Toast } from 'antd-mobile'
import LoadMoreList from '@/compoments/loadMoreList'
import DescriptionCard from '@/compoments/descriptionCard'

const dictStatus = [
  { value: -1, label: '全部' },
  { value: 1, label: '处理中' },
  { value: 2, label: '成功' },
  { value: 3, label: '失败' }
]

const HistoryItem = (props: any) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [{ title: '场馆', text: props?.venueName }]
      },
      {
        group: [{ title: '下级账号', text: props.memberName }]
      },
      {
        group: [{ title: '流水倍数', text: props?.flowTimes || 0 }]
      },
      {
        group: [{ title: '发放时间', text: props.updatedAt }]
      }
    ],
    [props]
  )
  return (
    <DescriptionCard
      topNode={
        <div className={styles.descriptionCardTop}>
          <span className={styles.cardItemLeft}>
            <p>红利金额：</p>
            <p>{Number(props?.money).toFixed(2)}</p>
          </span>
          <div className={styles.cardStatus}>
            <i></i>
            <div>
              {dictStatus.find((item) => item.value === props?.status)?.label ??
                '--'}
            </div>
          </div>
        </div>
      }
      bodyColumns={bodyColumns}
    />
  )
}

const History = () => {
  const navigate = useNavigate()

  const [formData, setFormData] = useState({
    status: '',
    startDate: getStartAndEndOfMonth(0).startOfMonth,
    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
  })

  const { filter, pager, nextPage, reset, error } = useGetDividendOrderList({
    ...formData,
    status: formData.status === '' ? -1 : formData.status
  })

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.select,
        placeHolder: '选择申请状态',
        prop: 'status',
        options: dictStatus
      },
      {
        domType: FormDomTypes.dateRange,
        prop: ['startDate', 'endDate'],
        placeHolder: ['开始时间', '结束时间']
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            status: '',
            startDate: getStartAndEndOfMonth(0).startOfMonth,
            endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
          }
          setFormData(params)
          reset({
            ...params,
            status: formData.status === '' ? -1 : formData.status
          })
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({
            ...formData,
            status: formData.status === '' ? -1 : formData.status
          })
        }
      }
    ],
    [formData]
  )

  async function loadMore() {
    await nextPage({
      ...formData,
      status: formData.status === '' ? -1 : formData.status
    })
  }

  useEffect(() => {
    if (error) {
      Toast.show({
        content: error?.message
      })
      setFormData({
        ...formData,
        startDate: getStartAndEndOfMonth(0).startOfMonth,
        endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
      })
    }
  }, [error])

  return (
    <div>
      <HeaderUI
        title="红利记录"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.formFilter}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>

      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <HistoryItem {...item} />
          }}
          itemClassName={styles.historyItem}
        />
      </div>
    </div>
  )
}

export default History
