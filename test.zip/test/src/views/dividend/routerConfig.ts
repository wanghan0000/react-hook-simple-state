export default {
    name: "dividend",
    author: true
};
  