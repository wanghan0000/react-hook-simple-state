import { apiFetcher } from '@/api/api'
import { usePagePlus } from '@/commonHooks/usePagePlus'
import useSWRMutation from 'swr/mutation'

export const useGetMemberApiBalance = () => {
  const params = {
    path: '/finance/dividend/getMemberApiBalance',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

export const useAgentDividendOrder = () => {
  const params = {
    path: '/finance/dividend/agentDividendOrder',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}


export const useGetDividendOrderList = (params) => {
    return usePagePlus({
        catchKey: 'useGetDividendOrderList',
        apiPath: '/finance/dividend/getDividendOrderList',
        formData: params
    })
}