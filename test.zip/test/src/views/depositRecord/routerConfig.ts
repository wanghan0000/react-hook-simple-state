export default {
    name: "depositRecord",
    author: true
};
  