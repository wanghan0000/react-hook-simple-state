import HeaderUI from '@/compoments/HeaderUI'
import FormFilter from '@/compoments/formFilter'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import LoadMoreList from '@/compoments/loadMoreList'
import { getCurrentDateString, getStartAndEndOfMonth } from '@/utils/date'
import DescriptionCard from '@/compoments/descriptionCard'
import { useGetPayRecordList } from './api'
import { Toast } from 'antd-mobile'
import styles from './index.module.scss'

const dictPayTypes = [
  { value: '', label: '全部' },
  { value: 1, label: '银行卡转卡' },
  { value: 2, label: '网银转公帐' },
  { value: 3, label: '支付宝转卡' },
  { value: 4, label: '极速大额特惠' },
  { value: 5, label: '云闪付转卡' },
  { value: 6, label: '支付宝转卡H5' },
  { value: 7, label: '微信H5' },
  { value: 8, label: '支付宝H5' },
  { value: 9, label: 'QQH5' }
]

const DepositRecordItem = (props: any) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [
          { title: '会员账号', text: props.vAccount },
          { title: '到账金额', text: `¥${props.vAmount}` }
        ]
      },
      {
        group: [{ title: '赠送金额', text: `¥${props.vRebateAmount}` }]
      },
      {
        group: [
          { title: '存款时间', text: props.vTime },
          { title: '支付方式', text: props.payName }
        ]
      },
      {
        group: [
          {
            title: '订单号',
            text: props?.billNo,
            copyValue: props?.billNo
          }
        ]
      },
      {
        group: [{ title: '已获取存款卡', text: props?.whetherGetCard ?? '--' }]
      }
    ],
    [props]
  )
  return (
    <DescriptionCard
      topNode={
        <div className={styles.recordTop}>
          <span className={styles.recordAmount}>¥{props?.vAmount}</span>
          <div className={styles.recordStatus3}>
            <i></i>
            <div>{props.vStateText}</div>
          </div>
        </div>
      }
      bodyColumns={bodyColumns}
    />
  )
}

const DepositRecord = () => {
  const navigate = useNavigate()

  const [formData, setFormData] = useState({
    name: '',
    startDate: getStartAndEndOfMonth(0).startOfMonth,
    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
  })

  const { pager, filter, reset, nextPage, error } = useGetPayRecordList(formData)

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.search,
        placeHolder: '会员账号',
        prop: 'name',
        width: '120px'
      },

      //   {
      //     domType: FormDomTypes.select,
      //     placeHolder: '选择状态',
      //     prop: 'imageTitle',
      //     width: '120px',
      //     options: dictPayTypes,
      //   },
      //   {
      //     domType: FormDomTypes.select,
      //     prop: '',
      //     placeHolder: '选择支付方式',
      //     options: dictPayTypes,
      //     width: '120px'
      //   },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            name: '',
            startDate: getStartAndEndOfMonth(0).startOfMonth,
            endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
          }
          setFormData(params)
          reset(params)
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter(formData)
        }
      },
      {
        domType: FormDomTypes.dateRange,
        prop: ['startDate', 'endDate'],
        placeHolder: ['开始时间', '结束时间'],
        maxDate: new Date()
      }
    ],
    [formData, filter]
  )

  async function loadMore() {
    await nextPage(formData)
  }

  useEffect(() => {
    if (error) {
      Toast.show({
        content: error?.message,
      })
      setFormData({
        ...formData,
        startDate: getStartAndEndOfMonth(0).startOfMonth,
        endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
      })
    }
  }, [error])

  return (
    <div>
      <HeaderUI
        title="存款记录"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />
      <div className={styles.depositRecordBox}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>

      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <DepositRecordItem {...item} />
          }}
          itemClassName={styles.depositRecordItem}
        />
      </div>
    </div>
  )
}

export default DepositRecord
