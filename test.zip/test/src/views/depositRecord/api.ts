import { usePagePlus } from '@/commonHooks/usePagePlus'

const dictPaystatus = [
  { code: 1, dictValue: '发起' },
  { code: 2, dictValue: '确认' },
  { code: 3, dictValue: '已对账' },
  { code: 1, dictValue: '用户关闭' },
  { code: 1, dictValue: '订单失效' }
]



/**获取最后充值数据 缓存30秒*/
export function useGetPayRecordList(params) {
   function transformData(data: any) {
        return data.map((v)=>{
            return {
                ...v,
                vAccount: v.name,
                vTime: v.createdAt,
                vAmount: Number(v.orderAmount)?.toFixed?.(2),
                vStateText: v.payStatusName,
                vRebateAmount: Number(v.rebateAmount)?.toFixed?.(2)
            }
        })
   }
    
  return usePagePlus({
    catchKey: 'useGetPayRecordList',
    apiPath: '/member/payRecordList',
    formData: params,
    transformData: transformData
  })
}
