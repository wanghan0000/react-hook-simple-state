import HeaderUI from '@/compoments/HeaderUI'
import IconImage from '@/compoments/IconImage'
import React, { useState } from 'react'
import { useNavigate } from 'react-router'
import QuestionMark from '@/assets/main/questionMark.png'
import MaskContentPop from '@/compoments/maskContentPop'
import { useGetAgentDepositConfig } from '../main/members/api'
import TopTabs from './compoments/topTabs'
import TeamInformation from './compoments/teamInformation'
import TeamGroup from './compoments/teamGroup'
import OperationRecord from './compoments/operationRecord'
import styles from './index.module.scss'

const TeamCenter = () => {
  const configs = [
    '对副线代理进行分组，组长可以查看组员的业绩（财务报表，佣金报表，下级成员业绩），代您进行管理；'
  ]
  const navigate = useNavigate()
  const [visible, setVisible] = useState(false)
  const [index, setIndex] = useState('0')
  const { data, isLoading } = useGetAgentDepositConfig()
  return (
    <div>
      <HeaderUI
        title="团队信息"
        showBack={true}
        onClickBack={() => navigate(-1)}
        rightNode={
          <div className={styles.headerRight}>
            <IconImage
              onClick={() => setVisible(true)}
              imagePath={QuestionMark}
              className={styles.questionMark}
            />
          </div>
        }
      />
      {!!data?.showGroup && (
        <TopTabs index={index} onChange={(v) => setIndex(v)} />
      )}
      {!isLoading && (
        <>
          {index === '0' && <TeamInformation />}
          {index === '1' && <TeamGroup />}
          {index === '2' && <OperationRecord />}
        </>
      )}

      <MaskContentPop
        visible={visible}
        onMaskClick={() => setVisible(false)}
        title={'温馨提示'}
        onClickConfirm={() => setVisible(false)}
        configs={configs}
        showIndex={false}
        textCenter={true}
      />
    </div>
  )
}

export default TeamCenter
