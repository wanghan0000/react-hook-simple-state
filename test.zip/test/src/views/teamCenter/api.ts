import { apiFetcher, useSWRExpand } from '@/api/api'
import { usePagePlus } from '@/commonHooks/usePagePlus'
import {
  getStartAndEndOfMonth,
  timeEndFormat,
  timeStartFormat
} from '@/utils/date'
import useSWRMutation from 'swr/mutation'

/*  获取团队信息*/
export function useGetTeamInfo() {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/team/getTeamInfo',
        type: 'post'
      },
      {}
    )
  }
  return useSWRExpand('useGetTeamInfo', fetcherFuc, {
    dedupingInterval: 60 * 1000
  })
}

/**获取团队列表*/
export function useTeamUserList(params) {
  const fetcherFuc = () => {
    let startDate
    let endDate
    if (params.status === 1) {
      startDate = timeStartFormat(0)
      endDate = timeEndFormat(0)
    } else if (params.status === 2) {
      startDate = timeStartFormat(1)
      endDate = timeEndFormat(2)
    } else if (params.status === 3) {
      startDate = getStartAndEndOfMonth(0).startOfMonth
      endDate = getStartAndEndOfMonth(0).endOfMonth
    } else if (params.status === 4) {
      startDate = getStartAndEndOfMonth(-1).startOfMonth
      endDate = getStartAndEndOfMonth(-1).endOfMonth
    }
    return apiFetcher(
      {
        path: '/team/teamUserList',
        type: 'post'
      },
      {
        arg: {
          agentName: params.agentName,
          startDate,
          endDate
        }
      }
    )
  }
  return useSWRExpand('useTeamUserList' + JSON.stringify(params), fetcherFuc, {
    dedupingInterval: 60 * 1000
  })
}

/**添加备注 */
export function useAddRemark() {
  const params = {
    path: '/team/addRemark',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

/**获取团队信息列表 */
export function useGetGroupInfo(params) {
  function transformRawData(data: any) {
    const result = Object.keys(data.list || []).map((key) => ({
      title: key,
      groups: data.list[key]
    }))
    return result
  }

  return usePagePlus({
    catchKey: 'useTeamGroupInfo',
    apiPath: '/team/getGroupInfo',
    formData: params,
    transformRawData: transformRawData
  })
}

/**编辑用户名 */
export function useEditGroup() {
  const params = {
    path: '/team/editGroup',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

/**解散小组 */
export function useDisabledGroup() {
  const params = {
    path: '/team/disbandGroup',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

/**新增小组 */
export function useAddGroup() {
  const params = {
    path: '/team/addGroup',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

/**获取代理小组信息 */
export function useGetGroupAgentInfo() {
  const params = {
    path: '/team/getGroupAgentInfo',
    type: 'post'
  }

  const fetcherFuc = (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg }).then((data: any) => {
      console.log('data', data)
      const groupNames = Object.keys(data.group)

      return {
        groupNames: groupNames,
        group: data.group || [],
        noGroup: data.noGroup || []
      }
    })
  }

  return useSWRMutation(params, fetcherFuc)
}

/**组员管理 */
export function useDistributeAgentGroup() {
  const params = {
    path: '/team/distributeAgentGroup',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

/**获取操作记录 */
export function useOperateLog(params) {
  return usePagePlus({
    catchKey: 'useOperateLog',
    apiPath: '/team/operateLog',
    formData: params
  })
}
