import React, { useState } from 'react'
import { Dialog, TextArea, Toast } from 'antd-mobile'
import { useAddRemark } from '../../api'
import styles from './index.module.scss'

interface AddRemarkProps {
  visible: boolean
  onClose: () => void
  onSuccess: () => void
  agentName: string
}

const AddRemark = (props: AddRemarkProps) => {
  const { trigger } = useAddRemark()

  const [value, setValue] = useState('')
  return (
    <Dialog
      visible={props.visible}
      onClose={() => {
        props?.onClose?.()
      }}
      closeOnAction={true}
      bodyClassName={styles.addRemarkDialog}
      title={'添加备注'}
      actions={[
        [
          {
            key: 'cancel',
            text: '取消',
            onClick: () => {
              props.onClose()
            }
          },
          {
            key: 'confirm',
            text: '确认',
            onClick: async () => {
              try {
                await trigger({
                  agentName: props.agentName,
                  remark: value
                })
                Toast.show('操作成功')
                props.onSuccess()
                props.onClose()
                setValue('')
              } catch (error: any) {
                Toast.show(error?.message || JSON.stringify(error))
              }
            }
          }
        ]
      ]}
      content={
        <div className={styles.checkModalForm}>
          <div className={styles.modalInput}>
            <div className={styles.title}>
              <p>代理账号：</p>
              <p>{props.agentName}</p>
            </div>

            <div>
              <div className={styles.remarkTips}>备注</div>
              <TextArea
                style={{
                  '--font-size': '13px'
                }}
                className={styles.textArea}
                placeholder="请输入备注信息，不超过100字"
                showCount
                maxLength={100}
                rows={4}
                value={value}
                onChange={(v) => setValue(v)}
              />
            </div>
          </div>
        </div>
      }
    />
  )
}

export default AddRemark
