import React, { useEffect, useMemo, useState } from 'react'
import {
  useAddGroup,
  useDisabledGroup,
  useDistributeAgentGroup,
  useGetGroupInfo
} from '../../api'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import FormFilter from '@/compoments/formFilter'
import LoadMoreList from '@/compoments/loadMoreList'
import DescriptionCard from '@/compoments/descriptionCard'
import { Button, Dialog, Toast } from 'antd-mobile'
import EditGroupName from '../editGroupName'
import AddGroup from '../addGroup'
import TeamManager from '../teamManager'
import styles from './index.module.scss'

const TeamGroupItem = (props: any) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [
          {
            title: '代理账号',
            text: (
              <div className={styles.itemGroupInfo}>
                <p>{props.agentName}</p>
                <p>{props.isLeader === 1 ? '组长' : ''}</p>
              </div>
            )
          }
        ]
      },
      {
        group: [{ title: '入组时间', text: `${props.createdAt}` }]
      }
    ],
    [props]
  )
  return <DescriptionCard bodyColumns={bodyColumns} />
}

const TeamGroup = () => {
  const [formData, setFormData] = useState({
    agentName: '',
    gropName: ''
  })

  const { pager, filter, reset, nextPage, error, resetMutate } =
    useGetGroupInfo({
      ...formData
    })

  const [showEdit, setShowEdit] = useState({
    visible: false,
    groupName: ''
  })
  const [showAddGroup, setShowAddGroup] = useState(false)
  const [showGroupManager, setShowGroupManager] = useState(false)

  const { trigger } = useDisabledGroup()
  const { trigger: triggerAdd } = useAddGroup()
  const { trigger: translateTrigger } = useDistributeAgentGroup()

  const options = useMemo(() => {
    if (pager.list?.length) {
      return pager.list.map((v) => {
        return {
          value: v.title,
          label: v.title
        }
      })
    } else {
      return []
    }
  }, [pager])

  useEffect(() => {
    if (options.length && !formData?.gropName?.length) {
      setFormData({
        ...formData,
        gropName: options[0].value
      })
    }
  }, [options, formData])

  const grops = useMemo(() => {
    if (!pager?.list?.length || !formData?.gropName?.length) {
      return []
    }
    return (
      pager.list.find((v) => {
        return v.title === formData.gropName
      })?.groups || []
    )
  }, [pager, formData])

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.search,
        placeHolder: '代理账号',
        prop: 'agentName',
        width: '140px'
      },
      {
        domType: FormDomTypes.select,
        placeHolder: '请选择',
        options: options,
        width: '140px',
        prop: 'gropName'
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            ...formData,
            agentName: ''
          }
          setFormData(params)
          reset(params)
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({ ...formData })
        }
      },
      {
        domType: FormDomTypes.button,
        label: '新增小组',
        onClick: () => {
          setShowAddGroup(true)
        }
      },
      {
        domType: FormDomTypes.button,
        label: '组员管理',
        onClick: () => {
          setShowGroupManager(true)
        }
      }
    ],
    [options, formData]
  )

  async function loadMore() {
    await nextPage({ ...formData })
  }

  return (
    <div className={styles.teamGroup}>
      {
        <div className={styles.formFilter}>
          <FormFilter
            value={formData}
            onChange={(v) => {
              setFormData({
                ...v
              })
            }}
            columns={columns}
          />
        </div>
      }

      {!!grops.length && (
        <div className={styles.listInfo}>
          <p>共{` ${grops.length} `}人</p>
          <div className={styles.btnGroups}>
            <Button
              size={'small'}
              onClick={() => {
                setShowEdit({
                  groupName: formData.gropName,
                  visible: true
                })
              }}
            >
              编辑
            </Button>
            <Button
              size={'small'}
              onClick={() => {
                Dialog.confirm({
                  bodyClassName: styles.dialogBody,
                  title: '解散小组',
                  content: `${formData.gropName}将被解散，小组成员回归未分组，是否继续？`,
                  onConfirm: async () => {
                    try {
                      await trigger({
                        groupName: formData.gropName
                      })
                      await resetMutate({ ...formData })
                      setFormData({
                        ...formData,
                        gropName: ''
                      })
                    } catch (error: any) {
                      Toast.show(error?.message || JSON.stringify(error))
                    }
                  }
                })
              }}
            >
              解散
            </Button>
          </div>
        </div>
      )}
      <div className={styles.list}>
        <LoadMoreList
          datas={grops}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <TeamGroupItem {...item} />
          }}
          itemClassName={styles.teamGroupItem}
        />
      </div>

      <EditGroupName
        visible={showEdit.visible}
        groupName={showEdit.groupName}
        onClose={() =>
          setShowEdit({
            ...showEdit,
            visible: false
          })
        }
        onSuccess={(v: any) => {
          setFormData({
            ...formData,
            gropName: v
          })
          resetMutate({
            ...formData
          })
        }}
      />
      <AddGroup
        visible={showAddGroup}
        onClose={() => setShowAddGroup(false)}
        onSubmit={async (values) => {
          await triggerAdd(values)
          await resetMutate({
            ...formData
          })
        }}
      />
      <TeamManager
        visible={showGroupManager}
        onClose={() => setShowGroupManager(false)}
        onSubmit={async (params: any) => {
          await translateTrigger(params)
          await resetMutate({
            ...formData
          })
        }}
      />
    </div>
  )
}

export default TeamGroup
