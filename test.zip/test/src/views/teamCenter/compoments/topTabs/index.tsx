import { Tabs } from 'antd-mobile'
import React, { useState } from 'react'
import styles from './index.module.scss'

interface TopTabsPops {
  index: string
  onChange(index: string)
}

const TopTabs = (props: TopTabsPops) => {
  return (
    <div className={styles.topTabs}>
      <Tabs
        className={styles.tabs}
        activeLineMode="fixed"
        onChange={(v) => {
          props.onChange(v)
        }}
        style={{
          '--fixed-active-line-width': '90px',
          '--title-font-size': '14px'
        }}
      >
        <Tabs.Tab
          title={
            <span
              className={
                styles.tabsTitle +
                ' ' +
                (props.index === '0' ? styles.activityTile : '')
              }
            >
              团队信息
            </span>
          }
          key="0"
        />
        <Tabs.Tab
          title={
            <span
              className={
                styles.tabsTitle +
                ' ' +
                (props.index === '1' ? styles.activityTile : '')
              }
            >
              团队分组
            </span>
          }
          key="1"
        />
        <Tabs.Tab
          title={
            <span
              className={
                styles.tabsTitle +
                ' ' +
                (props.index === '2' ? styles.activityTile : '')
              }
            >
              操作记录
            </span>
          }
          key="2"
        />
      </Tabs>
    </div>
  )
}

export default TopTabs
