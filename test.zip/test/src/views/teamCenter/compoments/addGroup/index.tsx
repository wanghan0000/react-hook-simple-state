import { Dialog, Input, Toast } from 'antd-mobile'
import React, { useMemo, useState } from 'react'
import styles from './index.module.scss'

interface AddGroupProps {
  visible: boolean
  onClose: () => void
  onSubmit: (values: any) => Promise<any>
}

const AddGroup = (props: AddGroupProps) => {
  const [formData, setFormData] = useState({
    groupName: '',
    leader: ''
  })
  const disabled = useMemo(() => {
    if (!formData.groupName.length || !formData.leader.length) return true
    return false
  }, [formData])
  return (
    <Dialog
      visible={props.visible}
      onClose={() => {
        props?.onClose?.()
      }}
      closeOnAction={true}
      bodyClassName={styles.addDialog}
      title={'新增小组'}
      actions={[
        [
          {
            key: 'cancel',
            text: '取消',
            onClick: () => {
              props.onClose()
            }
          },
          {
            key: 'confirm',
            text: '确认',
            disabled: disabled,
            onClick: async () => {
              try {
                await props.onSubmit(formData)
                Toast.show('操作成功')
                props.onClose()
              } catch (error: any) {
                Toast.show(error.message || JSON.stringify(error))
              }
            }
          }
        ]
      ]}
      content={
        <div className={styles.checkModalForm}>
          <div className={styles.modalInput}>
            <div>
              <div className={styles.title}>
                <p>小组名称：</p>
              </div>
              <Input
                style={{
                  '--font-size': '13px'
                }}
                className={styles.textArea}
                placeholder="请输入15位以内的小组名称"
                maxLength={15}
                max={15}
                value={formData.groupName}
                onChange={(v) => {
                  setFormData({
                    ...formData,
                    groupName: v
                  })
                }}
              />
            </div>

            <div className={styles.bottomInput}>
              <div className={styles.title}>
                <p>组长：</p>
              </div>
              <Input
                style={{
                  '--font-size': '13px'
                }}
                className={styles.textArea}
                placeholder="请输入代理账号"
                maxLength={20}
                max={20}
                value={formData.leader}
                onChange={(v) => {
                  setFormData({
                    ...formData,
                    leader: v
                  })
                }}
              />
            </div>
          </div>
        </div>
      }
    />
  )
}

export default AddGroup
