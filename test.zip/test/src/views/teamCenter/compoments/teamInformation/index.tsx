import React, { useMemo, useRef, useState } from 'react'
import { useGetTeamInfo, useTeamUserList } from '../../api'
import LoadMoreList from '@/compoments/loadMoreList'
import DescriptionCard from '@/compoments/descriptionCard'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import FormFilter from '@/compoments/formFilter'
import { Button } from 'antd-mobile'
import AddRemark from '../addRemark'
import styles from './index.module.scss'
import { useNavigate } from 'react-router'
const TeamInformationItem = (props: any) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [{ title: '首存人数', text: `${props.firstPayCount}` }]
      },
      {
        group: [{ title: '加入团队时间', text: `${props.createdAt}` }]
      },
      {
        group: [{ title: '备注', text: `${props.remark}` }]
      }
    ],
    [props]
  )
  return (
    <DescriptionCard
      topNode={
        <div className={styles.descriptionCardTop}>
          <span className={styles.cardItemLeft}>
            <p>代理账号：</p>
            <p>{props.agentName}</p>
            {props.isCaptain === 1 && (
              <svg
                className={styles.firstIcon}
                viewBox="64 64 896 896"
                focusable="false"
                data-icon="flag"
                width="1em"
                height="1em"
                fill="rgba(156,165,255,1)"
                aria-hidden="true"
              >
                <path d="M880 305H624V192c0-17.7-14.3-32-32-32H184v-40c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8 8v784c0 4.4 3.6 8 8 8h56c4.4 0 8-3.6 8-8V640h248v113c0 17.7 14.3 32 32 32h416c17.7 0 32-14.3 32-32V337c0-17.7-14.3-32-32-32z"></path>
              </svg>
            )}
          </span>
          <div className={styles.cardRight}>
            <p>下级人数：</p>
            <div>{props.subMemberCount}</div>
          </div>
        </div>
      }
      bodyColumns={bodyColumns}
      bottomNode={
        <div className={styles.bottomNode}>
          <div className={styles.btnGroups}>
            <Button
              onClick={props.onClickTeamFinancial}
              size={'small'}
              color={'primary'}
            >
              团队财务
            </Button>
            <Button
              onClick={props.onClickTeamCommissions}
              size={'small'}
              color={'primary'}
            >
              团队佣金
            </Button>
            <Button
              onClick={props.onClickRemark}
              size={'small'}
              color={'primary'}
            >
              备注
            </Button>
          </div>
        </div>
      }
    />
  )
}

const TeamInformation = () => {
  const [formData, setFormData] = useState({
    agentName: '',
    status: 3
  })
  const { data } = useGetTeamInfo()
  const navigate = useNavigate()

  const [requestParams, setRequestParams] = useState({
    agentName: '',
    status: 3
  })
  const {
    data: listData,
    isValidating,
    error,
    mutate
  } = useTeamUserList(requestParams)

  const [showRemark, setShowRemark] = useState({
    agentName: '',
    visible: false
  })
  const options = useRef([
    { value: 1, label: '今日' },
    { value: 2, label: '昨天' },
    { value: 3, label: '本月' },
    { value: 4, label: '上月' }
  ])

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.search,
        placeHolder: '代理账号',
        prop: 'agentName'
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            agentName: '',
            status: 3
          }
          setFormData(params)
          setRequestParams(params)
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          setRequestParams({ ...formData })
        }
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.radio,
        label: '状态',
        prop: 'status',
        options: options.current
      }
    ],
    [formData]
  )

  const items = useMemo(
    () => [
      {
        value: data?.mainName ?? '--',
        label: '主线账号'
      },
      {
        value: data?.teamName ?? '--',
        label: '团队名称'
      },
      {
        value: data?.teamAgentCount ?? '--',
        label: '团队代理'
      },
      {
        value: data?.memberCount ?? '--',
        label: '下级会员数'
      }
    ],
    [data]
  )
  return (
    <div className={styles.teamInformation}>
      <div className={styles.top}>
        <span className={styles.title}>团队概览</span>
        <div className={styles.itemContent}>
          {items?.map((v, index) => {
            return (
              <div key={index} className={styles.topItem}>
                <div>
                  <span className={styles.topItemTitle}>{v.label}</span>
                  <span className={styles.topItemValue}>{v.value}</span>
                </div>
                {index !== items.length - 1 && (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="1"
                    height="20"
                    viewBox="0 0 1 20"
                    fill="none"
                  >
                    <path
                      d="M0.5 0.25L0.499999 19.75"
                      stroke="#E3E4E6"
                      strokeWidth="0.5"
                      strokeLinecap="square"
                    ></path>
                  </svg>
                )}
              </div>
            )
          })}
        </div>

        <div className={styles.formFilter}>
          <FormFilter
            value={formData}
            onChange={(v) => {
              setFormData({
                ...v
              })
            }}
            columns={columns}
          />
        </div>
      </div>

      <div className={styles.list}>
        <LoadMoreList
          datas={listData?.list || []}
          loadMore={async () => {}}
          hasMore={false}
          firstLoading={isValidating}
          render={(item, index) => {
            return (
              <TeamInformationItem
                onClickRemark={() =>
                  setShowRemark({
                    agentName: item.agentName,
                    visible: true
                  })
                }
                onClickTeamFinancial={() => {
                  navigate('/financial', {
                    state: {
                      tableIndex: '1'
                    }
                  })
                }}
                onClickTeamCommissions={() =>
                  navigate('/main/commissions', {
                    state: {
                      tableIndex: '1'
                    }
                  })
                }
                {...item}
              />
            )
          }}
          itemClassName={styles.teamInformationItem}
        />
      </div>

      <AddRemark
        visible={showRemark.visible}
        agentName={showRemark.agentName}
        onClose={() => {
          setShowRemark({
            ...showRemark,
            visible: false
          })
        }}
        onSuccess={() => {
          mutate()
        }}
      />
    </div>
  )
}

export default TeamInformation
