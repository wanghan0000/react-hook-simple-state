import { Checkbox, Dialog, Toast } from 'antd-mobile'
import React, { useEffect, useMemo, useState } from 'react'
import SelectPopup from '@/compoments/selectPopup'
import { useGetGroupAgentInfo } from '../../api'
import category from '@/assets/common/category.png'
import SkeletonUI from '@/compoments/SkeletonUI'
import arrow from '@/assets/common/arrow.png'
import { deepClone } from '@/utils'
import styles from './index.module.scss'
interface TeamManagerProps {
  visible: boolean
  onClose: () => void
  onSubmit: (params: any) => Promise<any>
}

const SelectItem = (props: any) => {
  const [visible, setVisible] = useState(false)
  const handleSelectLabel = (v) => {
    return props?.options?.find((e) => e.value === v)?.label
  }

  return (
    <div className={styles.formItem}>
      <div
        className={styles.selctItem}
        onClick={() => {
          setVisible(true)
        }}
      >
        <img className={styles.selectIcon} src={category} alt="category" />
        {!props.value?.toString?.().length && (
          <p className={styles.placeHolder}>没有分组</p>
        )}
        {!!props.value?.toString?.().length && (
          <p>{handleSelectLabel(props.value)}</p>
        )}
        <img className={styles.triangle} src={arrow} alt="arrow" />
      </div>

      <SelectPopup
        value={props.value}
        visible={visible}
        options={props.options}
        onClose={() => {
          setVisible(false)
        }}
        onConfirm={(v) => {
          props.onChange?.(v)
        }}
      />
    </div>
  )
}

const GroupItem = ({ value = false, onChange, agentName }) => {
  return (
    <div className={styles.groupItem}>
      <Checkbox
        className={styles.checkbox}
        checked={value}
        onChange={onChange}
      />
      <span>{agentName}</span>
    </div>
  )
}

const GroupsBox = ({ groups = [] as any[], onChange }) => {
  return (
    <div className={styles.groupsBox}>
      {groups.map((v, index) => {
        return (
          <GroupItem
            key={v.agentName}
            value={v.isChecked}
            onChange={(checked) => {
              v.isChecked = checked
              onChange([...groups])
            }}
            agentName={v.agentName}
          />
        )
      })}
    </div>
  )
}

const TeamManager = (props: TeamManagerProps) => {
  const { trigger, data, isMutating, error } = useGetGroupAgentInfo()

  const [isSubmit, setIsSubmit] = useState(false)
  const [formData, setFormData] = useState({
    isLoading: true,
    noGroup: [] as any[],
    groupNames: [] as any[],
    group: [] as any[],
    groupName: '',
    isChange: false
  })

  const disabled = useMemo(() => {
    return !formData.isChange
  }, [formData])

  const options = useMemo(() => {
    if (data) {
      return data.groupNames.map((v) => {
        return {
          value: v,
          label: v
        }
      })
    }
    return []
  }, [data])

  useEffect(() => {
    if (data) {
      const cloneData = deepClone(data)
      setFormData({
        ...cloneData,
        isLoading: false,
        groupName: data.groupNames?.[0] || ''
      })
    }
  }, [data])

  useEffect(() => {
    if (props.visible) {
      trigger({})
    }
  }, [props.visible])

  const translateToRight = (groups = [] as any[]) => {
    if (isSubmit) {
      return
    }
    const checkedItem = groups.find((v) => v.isChecked)
    const unCheckeds = groups.filter((v) => !v.isChecked)

    const currentGroup = formData.group[formData.groupName]
    currentGroup.push({
      agentName: checkedItem.agentName
    })
    setFormData({
      ...formData,
      noGroup: unCheckeds,
      isChange: true
    })
  }

  const translateToLeft = (groups = [] as any[]) => {
    if (isSubmit) {
      return
    }
    const checkedItem = groups.find((v) => v.isChecked)
    const unCheckeds = groups.filter((v) => !v.isChecked)

    const currentGroup = formData.noGroup
    currentGroup.push({
      agentName: checkedItem.agentName
    })
    formData.group[formData.groupName] = unCheckeds
    setFormData({
      ...formData,
      isChange: true
    })
  }

  return (
    <>
      <Dialog
        className={styles.teamManagerDialog}
        visible={props.visible}
        onClose={() => {
          props?.onClose?.()
        }}
        title={'组员管理'}
        actions={[
          [
            {
              key: 'cancel',
              text: '取消',
              onClick: () => {
                props.onClose()
              }
            },
            {
              key: 'confirm',
              text: '确认',
              disabled: disabled,
              onClick: async () => {
                const params = {
                  agentNames: formData.group[formData.groupName].map((v)=>{
                    return v.agentName
                  }).toString(),
                  groupName: formData.groupName
                }
                setIsSubmit(true)
                try {
                  await props.onSubmit(params)
                  Toast.show('操作成功')
                  props.onClose()
                } catch (error: any) {
                  Toast.show(error?.message || JSON.stringify(error))
                }
                setIsSubmit(false)
              }
            }
          ]
        ]}
        content={
          <SkeletonUI isLoading={formData.isLoading} data={[1]} error={error}>
            <div className={styles.content}>
              <div className={styles.box}>
                <SelectItem
                  options={[{ value: 0, label: '未分组' }]}
                  value={0}
                />
                <GroupsBox
                  groups={formData.noGroup}
                  onChange={(group) => {
                    translateToRight(group)
                  }}
                />
              </div>
              <div className={styles.center}></div>
              <div className={styles.box}>
                <SelectItem
                  value={formData.groupName}
                  options={options}
                  onChange={(v) => {
                    if(isSubmit) {
                      return
                    }
                    const cloneData = deepClone(data)
                    setFormData({
                      ...cloneData,
                      isLoading: false,
                      groupName: v,
                      isChange: false
                    })
                  }}
                />
                <GroupsBox
                  groups={formData.group[formData.groupName]}
                  onChange={(group) => {
                    translateToLeft(group)
                  }}
                />
              </div>
            </div>
          </SkeletonUI>
        }
      ></Dialog>
      <SelectPopup />
    </>
  )
}

export default TeamManager
