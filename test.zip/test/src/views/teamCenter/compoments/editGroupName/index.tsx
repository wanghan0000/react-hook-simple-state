import React, { useEffect, useMemo, useState } from 'react'
import { Dialog, Input, Toast } from 'antd-mobile'
import { useEditGroup } from '../../api'
import styles from './index.module.scss'
interface EditGroupNameProps {
  visible: boolean
  onClose: () => void
  onSuccess: (v:any) => void
  groupName: string
}

const EditGroupName = (props: EditGroupNameProps) => {
  const [value, setValue] = useState('')
  const disabled = useMemo(() => {
    return !value.length
  }, [value])

  useEffect(() => {
    if (!props.visible) {
      setValue('')
    }
    if (props.visible) {
      setValue(props.groupName)
    }
  }, [props])

  const { trigger } = useEditGroup()
  return (
    <Dialog
      visible={props.visible}
      onClose={() => {
        props?.onClose?.()
      }}
      closeOnAction={true}
      bodyClassName={styles.editGroupNameDialog}
      title={'添加备注'}
      actions={[
        [
          {
            key: 'cancel',
            text: '取消',
            onClick: () => {
              props.onClose()
            }
          },
          {
            key: 'confirm',
            text: '确认',
            disabled: disabled,
            onClick: async () => {
              try {
                await trigger({
                  groupName: value,
                  oldGroupName: props.groupName
                })
                Toast.show('操作成功')
                props.onSuccess(value)
                props.onClose()
              } catch (error: any) {
                Toast.show(error?.message || JSON.stringify(error))
              }
            }
          }
        ]
      ]}
      content={
        <div className={styles.checkModalForm}>
          <div className={styles.modalInput}>
            <div className={styles.title}>
              <p>小组名称：</p>
            </div>

            <div>
              <Input
                style={{
                  '--font-size': '13px'
                }}
                className={styles.textArea}
                placeholder="请输入15位以内的小组名称"
                maxLength={15}
                max={15}
                value={value}
                onChange={(v) => setValue(v)}
              />
            </div>
          </div>
        </div>
      }
    />
  )
}

export default EditGroupName
