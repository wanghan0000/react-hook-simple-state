import { FormDomTypes } from '@/compoments/formFilter/interface'
import React, { useMemo, useState } from 'react'
import FormFilter from '@/compoments/formFilter'
import { useOperateLog } from '../../api'
import { getCurrentDateString, getStartAndEndOfMonth } from '@/utils/date'
import LoadMoreList from '@/compoments/loadMoreList'
import DescriptionCard from '@/compoments/descriptionCard'
import styles from './index.module.scss'

const OperationRecordItem = (props: any) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [{ title: '小组名称', text: props.groupName }]
      },
      {
        group: [{ title: '代理账号', text: props.agentName }]
      },
      {
        group: [{ title: '操作内容', text: props.operateContent }]
      },
      {
        group: [{ title: '操作时间', text: props.createdAt }]
      }
    ],
    []
  )
  return <DescriptionCard bodyColumns={bodyColumns} />
}

const OperationRecord = () => {
  const [formData, setFormData] = useState({
    groupName: '',
    agentName: '',
    startDate: getStartAndEndOfMonth(0).startOfMonth,
    endDate: getCurrentDateString(0, true, 'YYYY-MM-DD')
  })

  const { filter, pager, nextPage, reset, error } = useOperateLog({
    ...formData
  })
  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.search,
        placeHolder: '小组名称',
        prop: 'groupName',
        width: '150px'
      },
      {
        domType: FormDomTypes.search,
        placeHolder: '代理账号',
        prop: 'agentName',
        width: '150px'
      },
      {
        domType: FormDomTypes.dateRange,
        prop: ['startDate', 'endDate'],
        placeHolder: ['开始时间', '结束时间']
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            groupName: '',
            agentName: '',
            startDate: getCurrentDateString(-9, false, 'YYYY-MM-DD'),
            endDate: getCurrentDateString(0, true, 'YYYY-MM-DD')
          }
          setFormData(params)
          reset(params)
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({
            ...formData
          })
        },
        className: styles.endItem
      }
    ],
    [formData]
  )

  async function loadMore() {
    await nextPage({
      ...formData
    })
  }

  return (
    <div>
      <div className={styles.formFilter}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>

      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <OperationRecordItem {...item} />
          }}
          itemClassName={styles.operationRecordItem}
        />
      </div>
    </div>
  )
}

export default OperationRecord
