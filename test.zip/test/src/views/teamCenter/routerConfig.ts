export default {
    name: "teamCenter"
};
  