import React, { useRef, useState } from 'react'
import logoPng from './assets/logo.png'
import platform1 from './assets/platform1.png'
import platform2 from './assets/platform2.png'
import platform3 from './assets/platform3.png'
import avater from './assets/avatar.png'
import server from './assets/server.png'
import locak2 from './assets/lock2.png'
import Sigin from './compoments/sigin'
import SiginUp from './compoments/siginup'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'

const Login = () => {
  const naviagte = useNavigate()
  //0 登录  1注册
  const [state, setState] = useState(0)

  const sponsors = useRef([
    {
      path: platform1,
      title: '诺丁汉森林',
      desc: '胸前广告赞助商'
    },
    {
      path: platform2,
      title: '皇家马德里',
      desc: '亚洲区域官方合作伙伴'
    },
    {
      path: platform3,
      title: '切尔西',
      desc: '官方合作伙伴'
    }
  ])

  const handleChangeState = () => {
    const s = state === 0 ? 1 : 0
    setState(s)
  }
  const handleOpenForget = () => {
    naviagte('/forgetPassword')
  }
  const handleOpenServer = () => {
    //
    naviagte('/online')
  }

  const bottoms = [
    {
      path: avater,
      title: state === 0 ? '立即注册' : '立即登录',
      onClick: handleChangeState
    },
    {
      path: locak2,
      title: '忘记密码',
      onClick: handleOpenForget
    },
    {
      path: server,
      title: '合营咨询',
      onClick: handleOpenServer
    }
  ]

  return (
    <>
      <div className={styles.backGround}>
        <div className={styles.imageContainer}>
          <div>
            <img className={styles.image} src={logoPng} alt="logo" />
          </div>
        </div>
        {/* <div className={styles.sponsors}>
          {sponsors.current.map((v, index: number) => {
            return (
              <div className={styles.sponsorItem} key={index}>
                <div className={styles.sponsorImg}>
                  <div>
                    <img src={v.path} alt="sponsor" />
                  </div>
                </div>
                <p className={styles.sponsorTitle}>{v.title}</p>
                <p className={styles.sponsorDesc}>{v.desc}</p>
              </div>
            );
          })}
        </div> */}
        <div className={styles.entryMain}>
          {state === 0 && <Sigin />}
          {state === 1 && <SiginUp />}
        </div>
        <div className={styles.bottomWrap}>
          {bottoms.map((v, index) => {
            return (
              <div
                key={index}
                className={styles.bottomItem}
                onClick={v.onClick}
              >
                <div className={styles.bottomIcon}>
                  <div>
                    <img className={styles.image} src={v.path} alt="icon" />
                  </div>
                </div>
                <p className={styles.bottomText}>{v.title}</p>
              </div>
            )
          })}
        </div>
      </div>
    </>
  )
}

export default Login
