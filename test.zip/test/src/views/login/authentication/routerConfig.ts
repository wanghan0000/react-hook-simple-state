export default {
    name: "authentication",
    isRootRouter: true
};
  