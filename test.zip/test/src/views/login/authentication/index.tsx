import HeaderUI from '@/compoments/HeaderUI'
import React, { useMemo } from 'react'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'
import { List } from 'antd-mobile'

const Authentication = () => {
  const navigate = useNavigate()

  const clomuns = useMemo(
    () => [
      {
        title: '安全密保',
        text: '',
        onClick: () => {
            //
        }
      },
      {
        title: '身份验证码',
        text: '',
        onClick: () => {
            //
        }
      },
    ],
    []
  )


  return (
    <div>
      <HeaderUI
        title="验证方式"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.main}>
        <List>
          {clomuns.map((v, index) => {
            return (
              <List.Item
                key={index}
                onClick={v.onClick}
                clickable
                extra={<div>{v.text}</div>}
              >
                {v.title}
              </List.Item>
            )
          })}
        </List>
      </div>
    </div>
  )
}

export default Authentication
