import React, { useMemo, useState } from "react";
import styles from './index.module.scss'
import { Button, Input, List } from "antd-mobile";
import IconImage from "@/compoments/IconImage";
import RefreshPng from '@/assets/common/refresh.png'
import { useGetSecurityQuestion } from "@/views/main/myProfile/securityCenter/api";

const Question = () => {

    const { trigger, data, isMutating, error } = useGetSecurityQuestion()
    const [formData, setFormData] = useState({
        answer: ''
      })

      const btnButtonState = useMemo(() => {
        if (!formData.answer.length) {
          return true
        }
        return false
      }, [formData])
      
      const handleSubmit = () => {
        //
      }

    return <div>
    <div className={styles.main}>
          <List>
            <List.Item>
              <>
                <div className={styles.title}>
                  <div className={styles.titleText}>{data?.question}</div>
                  <div
                    className={styles.right}
                    onClick={() => {
                      if (isMutating) {
                        return
                      }
                      trigger({})
                    }}
                  >
                    <IconImage
                      imagePath={RefreshPng}
                      className={
                        styles.iamge +
                        ' ' +
                        (isMutating ? styles.loadingImage : '')
                      }
                    />
                    换一题
                  </div>
                </div>
                <div className={styles.input}>
                  <Input
                    placeholder="请输入密保答案"
                    value={formData.answer}
                    onChange={(v) => {
                      setFormData({
                        ...formData,
                        answer: v
                      })
                    }}
                  />
                </div>
              </>
            </List.Item>
     
 
          </List>
        </div>

        <div className={styles.addFooter}>
          <Button
            disabled={btnButtonState}
            onClick={handleSubmit}
            //loading={submitMutating}
            className={styles.addBtn}
            style={{ '--text-color': 'var(--adm-color-white)' }}
          >
            提交验证
          </Button>
        </div>
    </div>
}

export default Question