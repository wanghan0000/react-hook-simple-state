export default {
    name: "question",
    isRootRouter: true
};
  