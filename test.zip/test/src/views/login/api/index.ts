import { apiFetcher } from '@/api/api'
import useSWR from 'swr'
import useSWRMutation from 'swr/mutation'

export function useApiCaptcha() {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/member/captcha',
        type: 'get'
      },
      {}
    )
  }
  return useSWR<any>('getCaptcha', fetcherFuc, {
    dedupingInterval: 60 * 1000
  })
}

export interface IFLogin {
  //密码
  password: string
  //用户名
  username: string
  //图形验证码id
  captchaId?: string
  //是否验证
  isValidate?: number
  //图形验证码
  captchaVal?: number
  gmailSuffix?: string
  oldPassword?: string //不清楚要这个字段干什么

  CodeId?: string
  imgCode?: string
}

export interface IFSiginUp {
  //确认密码
  confirmPassword: string
  //邮箱
  gmail: string
  //验证码
  gmailCode: string
  //用户名
  name: string
  //密码
  password: string
}

export interface IFSendEmailCode {
  //邮箱
  address: string
  //不清楚 默认值'1'
  cate: string
  //用户名
  sendName?: string
  //不清楚 默认值'1'
  type: string
  //版本号
  version: string | undefined
}

export function useApiLogin() {
  const params = {
    path: '/member/login',
    type: 'post',
    needToken: false
  }
  return useSWRMutation(params, (params, arg: { arg: IFLogin }) => {
    return apiFetcher<IFLogin>(params, { ...arg })
  })
}

export function useSendSiginUpEmailCode() {
  const params = {
    path: '/member/sendCodeNotLogin',
    type: 'post',
    needToken: false
  }
  return useSWRMutation(params, (params, arg: { arg: IFSendEmailCode }) => {
    return apiFetcher<IFSendEmailCode>(params, { ...arg })
  })
}

export function useSendSiginUp() {
  const params = {
    path: '/member/register',
    type: 'post',
    needToken: false
  }
  return useSWRMutation(params, (params, arg: { arg: IFSiginUp }) => {
    return apiFetcher<IFSendEmailCode>(params, { ...arg })
  })
}

//验证图形验证码
export function useValidateGeeCheck() {
  const params = {
    path: '/member/validateGeeCheck',
    type: 'post',
    needToken: false
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//获取配置
export function useGetKaptchcate() {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/member/kaptchcate',
        type: 'post',
        needToken: false
      },
      {
        arg: {
          kType: 4
        }
      }
    )
  }
  // let isRequest = true
  // try {
  //   const defaultData = localStorage.getItem('kaptchcate')
  //   if (defaultData) {
  //     const obj = JSON.parse(defaultData)
  //     if (Number(obj?.timeStamp) < Date.now() +  60 * 1000 * 5) {
  //       isRequest = false
  //     }
  //   }
  // } catch (error) {
  //   isRequest = true
  //   console.error(error)
  // }

  return useSWR<any>('useGetKaptchcate', fetcherFuc, {
    dedupingInterval: 30 * 60 * 1000,
  })
}
