import React from 'react'
import { useAuth } from '@/compoments/AuthProvider'
import { useEffect, useRef, useState } from 'react'
import { nextTick } from '@/commonHooks/nextTick'
import { useSendSiginUp, useSendSiginUpEmailCode } from '../../api'
import { DotLoading, Toast } from 'antd-mobile'
import { md5Hash } from '@/utils/md5'
import { useNavigate } from 'react-router'
import EmailSelect from '../emailSelect'
import useSmsCountDown from '@/commonHooks/useSmsCountDown'
import styles from './../styles/index.module.scss'
import { containsTwoLetters, isLetter } from '@/logicUtils'

const SiginUp = () => {
  const [account, setAccount] = useState('')
  const [password, setPassword] = useState('')
  const [againPassword, setAgainPassword] = useState('')
  const [email, setEmail] = useState({
    value: '',
    suffix: '@outlook.com'
  })
  const [emailCode, setEmailCode] = useState('')
  const [buttonState, setButtonState] = useState(false)
  const [showPop, setShowPop] = useState(false)
  const accountRef = useRef<HTMLInputElement>(null)
  const passwordRef = useRef<HTMLInputElement>(null)
  const againPasswordRef = useRef<HTMLInputElement>(null)
  const emailRef = useRef<HTMLInputElement>(null)
  const emailCodeRef = useRef<HTMLInputElement>(null)
  const { login } = useAuth()

  const { secounds, start } = useSmsCountDown('registerEmail')

  const emailOptions = ['@gmail.com', '@outlook.com']

  const [inputState, setInputState] = useState({
    accountFocus: false,
    passwordFocus: false,
    againPasswordFocus: false,
    emailFocus: false,
    emailCodeFocus: false,
    eyeSate: false,
    accountError: false,
    passwordError: false,
    againPasswordError: false
  })
  const { trigger, data, isMutating, error } = useSendSiginUp()
  const { trigger: triggerEmail, isMutating: emailMutating } =
    useSendSiginUpEmailCode()
  const navigate = useNavigate()
  useEffect(() => {
    if (
      account?.length &&
      password?.length &&
      againPassword?.length &&
      !inputState.accountError &&
      !inputState.passwordError &&
      !inputState.againPasswordError &&
      email.value?.length &&
      emailCode?.length
    ) {
      setButtonState(true)
    } else {
      setButtonState(false)
    }
  }, [account, password, againPassword, inputState, email, emailCode])

  useEffect(() => {
    if (error) {
      Toast.show(error?.message)
    }
  }, [error])

  useEffect(() => {
    if (data) {
      Toast.show('注册成功')
      login(data)
      nextTick().then(() => {
        navigate('/main', {
          replace: true,
          state: {
            showWelcome: true
          }
        })
      })
    }
  }, [data])

  const handleOnChangeAccount = (e: any) => {
    const { target } = e
    setAccount(target.value)
    setInputState({
      ...inputState,
      accountError: validateAccount(target.value)
    })
  }

  const handleOnChangePassword = (e: any) => {
    const { target } = e
    setPassword(target.value)
    setInputState({
      ...inputState,
      passwordError: validatePassword(target.value)
    })
  }

  const handleAccountFocus = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      accountFocus: true,
      passwordFocus: false,
      againPasswordFocus: false,
      emailFocus: false,
      emailCodeFocus: false
    })
  }
  const handleAccountBlur = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      accountFocus: false
    })
  }

  const handlePasswordFocus = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      passwordFocus: true,
      accountFocus: false,
      againPasswordFocus: false,
      emailFocus: false,
      emailCodeFocus: false
    })
  }

  const handlePasswordBlur = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      passwordFocus: false
    })
  }

  const handleAgainPasswordFocus = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      passwordFocus: false,
      accountFocus: false,
      againPasswordFocus: true,
      emailFocus: false,
      emailCodeFocus: false
    })
  }

  const handleAgainPasswordBlur = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      againPasswordFocus: false
    })
  }

  const handleAgainOnChangePassword = (e: any) => {
    const { target } = e
    setAgainPassword(target.value)
    setInputState({
      ...inputState,
      againPasswordError: validateAgainPassword(target.value)
    })
  }

  const handleEmailFocus = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      passwordFocus: false,
      accountFocus: false,
      againPasswordFocus: false,
      emailFocus: true,
      emailCodeFocus: false
    })
  }

  const handleEmailBlur = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      emailFocus: false
    })
  }

  const handleOnChangeEmail = (e: any) => {
    const { target } = e
    setEmail({
      ...email,
      value: target.value
    })
  }

  const handleEmailCodeFocus = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      passwordFocus: false,
      accountFocus: false,
      againPasswordFocus: false,
      emailFocus: false,
      emailCodeFocus: true
    })
  }

  const handleEmailCodeBlur = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      emailCodeFocus: false
    })
  }

  const handleOnChangeEmailCode = (e: any) => {
    const { target } = e
    setEmailCode(target?.value)
  }

  const handleSubmit = () => {
    if (!buttonState || isMutating) {
      return
    }
    trigger({
      password: md5Hash(password),
      name: account,
      gmail: email.value + email.suffix,
      confirmPassword: md5Hash(againPassword),
      gmailCode: emailCode
    })
  }

  const handleSendEmailCode = () => {
    if (secounds || emailMutating) {
      return
    }
    triggerEmail({
      address: email.value + email.suffix,
      cate: '1',
      sendName: account,
      type: '1',
      version: process.env.REACT_API_VERSION
    })
      .then(() => {
        start()
      })
      .catch((error) => {
        Toast.show(error?.message)
      })
  }

  /**验证账号 */
  const validateAccount = (value: any): boolean => {
    if (!value) {
      return false
    }
    const reg = /[^0-9A-Za-z]/
    if (
      !value ||
      value.length < 4 ||
      value.length > 11 ||
      !isLetter(value[0]) ||
      !containsTwoLetters(value, 2) ||
      reg.test(value)
    ) {
      return true
    } else {
      return false
    }
  }
  /**验证密码 */
  const validatePassword = (value: any): boolean => {
    if (!value) {
      return false
    }
    const reg = /[^0-9A-Za-z]/
    console.log(reg.test(value))
    if (
      !value ||
      value?.length < 8 ||
      value?.length > 12 ||
      !containsTwoLetters(value, 1) ||
      reg.test(value)
    ) {
      return true
    } else {
      return false
    }
  }
  /**再次验证密码 */
  const validateAgainPassword = (value: any): boolean => {
    if (!value) {
      return false
    }
    if (!value || value !== password) {
      return true
    } else {
      return false
    }
  }

  return (
    <div className={styles.siginContiner}>
      <div className={styles.normalContent}>
        <div>
          <div className={styles.normalLoginWrap}>
            {/** 账号 */}
            <div>
              <div
                className={
                  styles.inputGroup +
                  ' ' +
                  (inputState.accountFocus ? styles.inputGroupFocus : '') +
                  ' ' +
                  (inputState.accountError ? styles.inputGroupError : '')
                }
              >
                <div className={styles.accountIcon}></div>
                <div className={styles.inputMain}>
                  <input
                    ref={accountRef}
                    onFocus={handleAccountFocus}
                    onBlur={handleAccountBlur}
                    value={account}
                    onChange={handleOnChangeAccount}
                    autoComplete="off"
                    type="text"
                    className={styles.loginInput}
                    maxLength={30}
                    spellCheck={false}
                    disabled={isMutating}
                    placeholder={'用户名'}
                  />
                </div>
                <div
                  onClick={() => {
                    setAccount('')
                    accountRef.current?.focus()
                  }}
                  className={
                    account.length && inputState.accountFocus
                      ? styles.loginDeleteBtn
                      : ''
                  }
                ></div>
              </div>
              {(inputState.accountFocus || inputState.accountError) && (
                <div
                  className={
                    styles.tips +
                    ' ' +
                    (inputState.accountError ? styles.tipsError : '')
                  }
                >
                  4-11位，最少2个字母＋数字组合，首位为字母
                </div>
              )}
            </div>

            {/** 密码 */}
            <div className={styles.inputPwdContent}>
              <div
                className={
                  styles.inputGroup +
                  ' ' +
                  (inputState.passwordFocus ? styles.inputGroupFocus : '') +
                  ' ' +
                  (inputState.passwordError ? styles.inputGroupError : '')
                }
              >
                <div className={styles.passwordIcon}></div>
                <div className={styles.inputMain}>
                  <input
                    ref={passwordRef}
                    value={password}
                    onFocus={handlePasswordFocus}
                    onBlur={handlePasswordBlur}
                    onChange={handleOnChangePassword}
                    autoComplete="off"
                    type={inputState.eyeSate ? 'text' : 'password'}
                    className={styles.loginInput}
                    maxLength={30}
                    spellCheck={false}
                    placeholder={'密码'}
                    disabled={isMutating}
                  />
                </div>
                <div
                  onClick={() => {
                    setPassword('')
                    passwordRef.current?.focus()
                  }}
                  className={
                    password.length && inputState.passwordFocus
                      ? styles.loginDeleteBtn
                      : ''
                  }
                ></div>
                <div
                  onClick={async () => {
                    await nextTick()
                    setInputState({
                      ...inputState,
                      eyeSate: !inputState.eyeSate,
                      passwordFocus: true
                    })
                    await nextTick()
                    passwordRef.current?.focus()
                  }}
                  className={
                    styles.operateBtn +
                    ' ' +
                    (inputState.eyeSate ? styles.openPwdBtn : styles.hidePwdBtn)
                  }
                  style={{
                    opacity: inputState.passwordFocus && password.length ? 1 : 0
                  }}
                ></div>
              </div>
              {(inputState.passwordFocus || inputState.passwordError) && (
                <div
                  className={
                    styles.tips +
                    ' ' +
                    (inputState.passwordError ? styles.tipsError : '')
                  }
                >
                  密码长度为8-12位，字母+数字的组合，不含特殊字符
                </div>
              )}
            </div>

            {/** 确认密码 */}
            <div className={styles.inputPwdContent}>
              <div
                className={
                  styles.inputGroup +
                  ' ' +
                  (inputState.againPasswordFocus
                    ? styles.inputGroupFocus
                    : '') +
                  ' ' +
                  (inputState.againPasswordError ? styles.inputGroupError : '')
                }
              >
                <div className={styles.passwordIcon}></div>
                <div className={styles.inputMain}>
                  <input
                    ref={againPasswordRef}
                    value={againPassword}
                    onFocus={handleAgainPasswordFocus}
                    onBlur={handleAgainPasswordBlur}
                    onChange={handleAgainOnChangePassword}
                    autoComplete="off"
                    type={inputState.eyeSate ? 'text' : 'password'}
                    className={styles.loginInput}
                    maxLength={30}
                    spellCheck={false}
                    placeholder={'确认密码'}
                    disabled={isMutating}
                  />
                </div>
                <div
                  onClick={() => {
                    setAgainPassword('')
                    againPasswordRef.current?.focus()
                  }}
                  className={
                    againPassword.length && inputState.againPasswordFocus
                      ? styles.loginDeleteBtn
                      : ''
                  }
                ></div>
                <div
                  onClick={async () => {
                    await nextTick()
                    setInputState({
                      ...inputState,
                      eyeSate: !inputState.eyeSate,
                      againPasswordFocus: true
                    })
                    await nextTick()
                    againPasswordRef.current?.focus()
                  }}
                  className={
                    styles.operateBtn +
                    ' ' +
                    (inputState.eyeSate ? styles.openPwdBtn : styles.hidePwdBtn)
                  }
                  style={{
                    opacity:
                      inputState.againPasswordFocus && password.length ? 1 : 0
                  }}
                ></div>
              </div>
              {inputState.againPasswordFocus &&
                inputState.againPasswordError &&
                !!againPassword.length && (
                  <div
                    className={
                      styles.tips +
                      ' ' +
                      (inputState.againPasswordError ? styles.tipsError : '')
                    }
                  >
                    两次密码输入不一致，请重新输入
                  </div>
                )}
            </div>

            {/** 邮箱 */}
            <div className={styles.inputPwdContent}>
              <div
                className={
                  styles.inputGroup +
                  ' ' +
                  (inputState.emailFocus ? styles.inputGroupFocus : '')
                }
              >
                <div className={styles.accountIcon}></div>
                <div className={styles.inputMain}>
                  <input
                    ref={emailRef}
                    value={email.value}
                    onFocus={handleEmailFocus}
                    onBlur={handleEmailBlur}
                    onChange={handleOnChangeEmail}
                    autoComplete="off"
                    type={'text'}
                    className={styles.loginInput}
                    maxLength={30}
                    spellCheck={false}
                    placeholder={'邮箱'}
                    disabled={isMutating}
                  />
                </div>
                <div
                  onClick={() => {
                    setEmail({
                      ...email,
                      value: ''
                    })
                    emailRef.current?.focus()
                  }}
                  className={
                    !!email.value?.length && inputState.emailFocus
                      ? styles.loginDeleteBtn
                      : ''
                  }
                ></div>
                <div
                  onClick={async () => {
                    setShowPop(true)
                  }}
                  className={''}
                >
                  <span>
                    {email.suffix}
                    <em className={styles.emailArrow}>▼</em>
                  </span>
                </div>
              </div>
            </div>

            {/** 验证码 */}
            <div className={styles.inputPwdContent}>
              <div
                className={
                  styles.inputGroup +
                  ' ' +
                  (inputState.emailCodeFocus ? styles.inputGroupFocus : '')
                }
              >
                <div className={styles.passwordIcon}></div>
                <div className={styles.inputMain}>
                  <input
                    ref={emailCodeRef}
                    value={emailCode}
                    onFocus={handleEmailCodeFocus}
                    onBlur={handleEmailCodeBlur}
                    onChange={handleOnChangeEmailCode}
                    autoComplete="off"
                    type={'text'}
                    className={styles.loginInput}
                    maxLength={30}
                    spellCheck={false}
                    placeholder={'验证码'}
                    disabled={isMutating}
                  />
                </div>
                <div
                  onClick={() => {
                    setEmailCode('')
                    emailCodeRef.current?.focus()
                  }}
                  className={
                    !!emailCode?.length && inputState.emailCodeFocus
                      ? styles.loginDeleteBtn
                      : ''
                  }
                ></div>
                <div
                  onClick={handleSendEmailCode}
                  className={styles.btnSendCode}
                >
                  {emailMutating && <span className={styles.loader}></span>}
                  <span
                    className={
                      styles.codeText +
                      ' ' +
                      (!email?.value?.length ||
                      !account?.length ||
                      isMutating ||
                      inputState.accountError ||
                      secounds
                        ? styles.disabledText
                        : '')
                    }
                  >
                    {!!secounds ? `${secounds}s 后获取验证码` : '获取验证码'}
                  </span>
                </div>
              </div>
            </div>

            <div
              className={
                styles.loginBtnGroup +
                ' ' +
                (buttonState ? styles.btnBgActivity : styles.btnBgDefault)
              }
            >
              {!isMutating && (
                <button
                  className={styles.btnBG}
                  onClick={handleSubmit}
                  disabled={isMutating}
                >
                  注册
                </button>
              )}
              {isMutating && (
                <div className={styles.btnBG}>
                  <DotLoading className={styles.dotLoading} />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <EmailSelect
        onClose={() => setShowPop(false)}
        visible={showPop}
        emails={emailOptions}
        value={email.suffix}
        onChange={(v) => {
          setEmail({
            ...email,
            suffix: v
          })
        }}
      />
    </div>
  )
}

export default SiginUp
