import { useAuth } from '@/compoments/AuthProvider'
import React, { useEffect, useRef, useState } from 'react'
import { CheckList, Divider, Popup } from 'antd-mobile'
import styles from './index.module.scss'

interface EmailSelectProps {
  visible: boolean
  emails: any[]
  value: string
  onChange: (value: string) => void
  onClose?: ()=> void
}

const EmailSelect = (props: EmailSelectProps) => {
  const [visible, setVisible] = useState(false)
  useEffect(() => {
    setVisible(props.visible)
  }, [props.visible])

  useEffect(()=>{
    if(!visible) {
        props?.onClose?.()
    }
  },[visible])

  return (
    <>
      <Popup
        visible={visible}
        onMaskClick={() => {
          setVisible(false)
        }}
        bodyStyle={{
          borderTopLeftRadius: '8px',
          borderTopRightRadius: '8px',
          minHeight: '180px'
        }}
      >
        <div>
            <div className={styles.top}>
                <div onClick={()=>setVisible(false)} className={styles.left +' ' + styles.text}>取消</div>
                <div onClick={(()=>setVisible(false))} className={styles.right + ' ' + styles.text}>确定</div>
            </div>
        <CheckList
          defaultValue={[props.value]}
          onChange={(val: any) => {
            setVisible(false)
            props.onChange(val[0])
          }}
        >
          {props.emails.map((v, index) => {
            return (
              <CheckList.Item key={index?.toString()} value={v}>
                {v}
              </CheckList.Item>
            )
          })}
        </CheckList>
        </div>

      </Popup>
    </>
  )
}

export default EmailSelect
