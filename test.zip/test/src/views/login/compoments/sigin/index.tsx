import React from 'react'
import { useAuth } from '@/compoments/AuthProvider'
import { useEffect, useRef, useState } from 'react'
import { nextTick } from '@/commonHooks/nextTick'
import {
  useApiCaptcha,
  useApiLogin,
  useGetKaptchcate,
  useValidateGeeCheck
} from '../../api'
import { DotLoading, Toast } from 'antd-mobile'
import { md5Hash } from '@/utils/md5'
import { useNavigate } from 'react-router'
import styles from '../styles/index.module.scss'
import { useGeeSdk } from '@/sdk/gee/GeeSdk'
import MaskContentPop from '@/compoments/maskContentPop'

const configs = ['系统检测到当前登录异常，为了您的账号安全请先进行安全验证！']

const Sigin = () => {
  const [account, setAccount] = useState('')
  const [password, setPassword] = useState('')
  const [imageCode, setImageCode] = useState('')
  const accountRef = useRef<HTMLInputElement>(null)
  const passwordRef = useRef<HTMLInputElement>(null)
  const imageRef = useRef<HTMLInputElement>(null)
  const { login } = useAuth()
  const [visible, setVisible] = useState(false)
  const [inputState, setInputState] = useState({
    accountFocus: false,

    passwordFocus: false,
    imageFocus: false,

    eyeSate: false,
    buttonState: false
  })
  const { trigger, data, isMutating, error } = useApiLogin()
  const { data: ImageData, mutate } = useApiCaptcha()
  const { trigger: validateGee, isMutating: geeMutating } =
    useValidateGeeCheck()

  const navigate = useNavigate()
  useEffect(() => {
    if (account?.length && password?.length) {
      setInputState({
        ...inputState,
        buttonState: true
      })
    } else {
      setInputState({
        ...inputState,
        buttonState: false
      })
    }
  }, [account, password])

  // useEffect(() => {
  //   if (error) {
  //     Toast.show(error?.message || JSON.stringify(error))
  //   }
  // }, [error])

  useEffect(() => {
    if (data) {
      login(data)
      nextTick().then(() => {
        navigate('/main')
      })
    }
  }, [data])

  const handleOnChangeAccount = (e: any) => {
    const { target } = e
    setAccount(target.value)
  }

  const handleOnChangePassword = (e: any) => {
    const { target } = e
    setPassword(target.value)
  }

  const handleOnChangeImageCode = (e: any) => {
    const { target } = e
    setImageCode(target.value)
  }

  const handleAccountFocus = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      accountFocus: true,
      passwordFocus: false,
      imageFocus: false
    })
  }
  const handleAccountBlur = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      accountFocus: false
    })
  }

  const handlePasswordFocus = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      passwordFocus: true,
      accountFocus: false,
      imageFocus: false
    })
  }

  const handlePasswordBlur = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      passwordFocus: false
    })
  }

  const handleImageFocus = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      imageFocus: true,
      accountFocus: false,
      passwordFocus: false
    })
  }

  const handleImageBlur = async () => {
    await nextTick()
    setInputState({
      ...inputState,
      imageFocus: false
    })
  }

  const { error: loginConfig } = useGetKaptchcate()
  //-1 没有 0 极速 1 图形
  const waysIdent = loginConfig ? (loginConfig.status_code === 6022 ? 0 : 1) : -1

  const handleSubmit = () => {
    if (!inputState.buttonState || isMutating || geeMutating) {
      return
    }
    if (waysIdent === 0) {
      handleShowCode()
    }else {
      finallyLogin()
    }
  }

  const captcha = useGeeSdk({
    config: {
      captchaId: '770ff67331e82e6a3af65e203d70c84f',
      product: 'bind',
      protocol: 'https://'
    }
  })

  const handleShowCode = () => {
    captcha?.showCaptcha()
  }

  const finallyLogin = async (params?: { lot_number: '' }) => {
    try {
      await trigger({
        password: md5Hash(password),
        username: account,
        isValidate: waysIdent === -1 ? 1 : waysIdent,
        gmailSuffix: '@outlook.com',
        captchaId: '',
        imgCode: imageCode,
        CodeId: params?.lot_number,
        oldPassword: md5Hash('')
      })
    } catch (error: any) {
      refreshImageCode()
      captcha.reset()
     
      console.log('err',error)
      if(error.status_code === 6025) {
        //异地登陆
        setVisible(true)
      }else {
        Toast.show(error?.message || JSON.stringify(error))
      }

    }
  }

  const refreshImageCode = () => {
    if (waysIdent === 1) {
      mutate()
    }
  }

  useEffect(() => {
    if (captcha.state === 'success') {
      validateGee({
        ...captcha?.getValidate()
      })
        .then((res) => {
          finallyLogin({
            lot_number: res.captcha_args.lot_number
          })
        })
        .catch((error) => {
          refreshImageCode()
          captcha.reset()
        
          if(error.status_code === 6025) {
            //异地登陆
            setVisible(true)
          }else{
            Toast.show(error?.message || JSON.stringify(error))
          }
        })
    }
  }, [captcha.state])

  return (
    <div className={styles.siginContiner}>
      <div className={styles.normalContent}>
        <div>
          <div className={styles.normalLoginWrap}>
            <div>
              <div
                className={
                  styles.inputGroup +
                  ' ' +
                  (inputState.accountFocus ? styles.inputGroupFocus : '')
                }
              >
                <div className={styles.accountIcon}></div>
                <div className={styles.inputMain}>
                  <input
                    ref={accountRef}
                    onFocus={handleAccountFocus}
                    onBlur={handleAccountBlur}
                    value={account}
                    onChange={handleOnChangeAccount}
                    autoComplete="off"
                    type="text"
                    className={styles.loginInput}
                    maxLength={30}
                    spellCheck={false}
                    disabled={isMutating}
                    placeholder={'请输入账号'}
                  />
                </div>
                <div
                  onClick={() => {
                    setAccount('')
                    accountRef.current?.focus()
                  }}
                  className={
                    account.length && inputState.accountFocus
                      ? styles.loginDeleteBtn
                      : ''
                  }
                ></div>
              </div>
            </div>

            <div className={styles.inputPwdContent}>
              <div
                className={
                  styles.inputGroup +
                  ' ' +
                  (inputState.passwordFocus ? styles.inputGroupFocus : '')
                }
              >
                <div className={styles.passwordIcon}></div>
                <div className={styles.inputMain}>
                  <input
                    ref={passwordRef}
                    value={password}
                    onFocus={handlePasswordFocus}
                    onBlur={handlePasswordBlur}
                    onChange={handleOnChangePassword}
                    autoComplete="off"
                    type={inputState.eyeSate ? 'text' : 'password'}
                    className={styles.loginInput}
                    maxLength={30}
                    spellCheck={false}
                    placeholder={'请输入密码'}
                    disabled={isMutating}
                  />
                </div>
                <div
                  onClick={() => {
                    setPassword('')
                    passwordRef.current?.focus()
                  }}
                  className={
                    password.length && inputState.passwordFocus
                      ? styles.loginDeleteBtn
                      : ''
                  }
                ></div>
                <div
                  onClick={async () => {
                    await nextTick()
                    setInputState({
                      ...inputState,
                      eyeSate: !inputState.eyeSate,
                      passwordFocus: true
                    })
                    await nextTick()
                    passwordRef.current?.focus()
                  }}
                  className={
                    styles.operateBtn +
                    ' ' +
                    (inputState.eyeSate ? styles.openPwdBtn : styles.hidePwdBtn)
                  }
                  style={{
                    opacity: inputState.passwordFocus && password.length ? 1 : 0
                  }}
                ></div>
              </div>
            </div>

            {waysIdent === 1 && (
              <div className={styles.inputImageContent}>
                <div
                  className={
                    styles.inputGroup +
                    ' ' +
                    (inputState.imageFocus ? styles.inputGroupFocus : '')
                  }
                >
                  <div className={styles.inputMain}>
                    <input
                      ref={imageRef}
                      value={imageCode}
                      onFocus={handleImageFocus}
                      onBlur={handleImageBlur}
                      onChange={handleOnChangeImageCode}
                      autoComplete="off"
                      type={'text'}
                      className={styles.loginInput}
                      maxLength={6}
                      spellCheck={false}
                      placeholder={'请输图形验证码'}
                      disabled={isMutating}
                    />
                  </div>
                </div>
                <div>
                  <img
                    onClick={() => mutate()}
                    src={ImageData?.url}
                    alt="codeImage"
                    className={styles.imageCode}
                  />
                </div>
              </div>
            )}

            <div
              className={
                styles.loginBtnGroup +
                ' ' +
                (inputState.buttonState
                  ? styles.btnBgActivity
                  : styles.btnBgDefault)
              }
            >
              {!isMutating && !geeMutating && (
                <button
                  className={styles.btnBG}
                  onClick={handleSubmit}
                  disabled={isMutating || geeMutating}
                >
                  登录
                </button>
              )}
              {(isMutating || geeMutating) && (
                <div className={styles.btnBG}>
                  <DotLoading className={styles.dotLoading} />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <MaskContentPop
        visible={visible}
        onMaskClick={() => setVisible(false)}
        title={'温馨提示'}
        onClickConfirm={() => setVisible(false)}
        configs={configs}
        showIndex={false}
        textCenter={true}
      />
    </div>
  )
}

export default Sigin
