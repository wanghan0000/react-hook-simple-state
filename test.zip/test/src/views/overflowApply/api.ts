import { apiFetcher } from "@/api/api"
import { usePagePlus } from "@/commonHooks/usePagePlus"
import useSWRMutation from 'swr/mutation'

//存款列表
export function useGetPersonCenter(formData) {
    return usePagePlus({
        formData: formData,
        apiPath: '/personCenter/agentOverflowApply',
        catchKey: 'useGetPersonCenter'
    })
  }