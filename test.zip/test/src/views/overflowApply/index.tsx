import HeaderUI from '@/compoments/HeaderUI'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import { getCurrentDateString } from '@/utils/date'
import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import FormFilter from '@/compoments/formFilter'
import LoadMoreList from '@/compoments/loadMoreList'
import { useGetPersonCenter } from './api'
import DescriptionCard from '@/compoments/descriptionCard'
import { Toast } from 'antd-mobile'
import styles from './index.module.scss'
const dictOverflowStatus = [
  { label: '全部', value: '-1' },
  { label: '无法申请', value: '0' },
  { label: '可以申请', value: '1' },
  { label: '待审核', value: '2' },
  { label: '审核通过', value: '3' },
  { label: '审核拒绝', value: '4' },
  { label: '系统驳回', value: '5' }
]

const OverflowApplyItem = (props) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [{ title: '新增时间', text: props.createAt }]
      },
      {
        group: [{ title: '审核时间', text: props.applyTime }]
      },
      {
        group: [{ title: '验证链接', text: props.promoteUrl || '--' }]
      },
      {
        group: [{ title: '备注', text: props?.remark || '--' }]
      }
    ],
    [props]
  )
  const statusLabel = useMemo(() => {
    return dictOverflowStatus.find((item) => Number(item.value) === props.applyStatus)
      ?.label
  }, [props])
  return (
    <DescriptionCard
      topNode={
        <div className={styles.itemTop}>
          <span className={styles.itemAccount}>
            <span>会员账户：</span>
            <span>{props.memberName}</span>
          </span>
          <div className={styles.itemStatus}>
            <i></i>
            <div>{statusLabel}</div>
          </div>
        </div>
      }
      bodyColumns={bodyColumns}
    />
  )
}

const OverflowApply = () => {
  const navigate = useNavigate()

  const [formData, setFormData] = useState({
    memberName: '',
    applyStatus: '-1',
    createStartDate: getCurrentDateString(-31, true, 'YYYY-MM-DD'),
    createEndDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
    applyTimeStart: '',
    applyTimeEnd: ''
  })

  const { filter, pager, nextPage, reset , error } = useGetPersonCenter({
    ...formData,
    applyStatus: formData.applyStatus === '-1' ? '' : formData.applyStatus
  })

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.dateRange,
        prop: ['createStartDate', 'createEndDate'],
        placeHolder: ['开始时间', '结束时间'],
        label: '新增时间'
      },
      {
        domType: FormDomTypes.dateRange,
        prop: ['applyTimeStart', 'applyTimeEnd'],
        placeHolder: ['开始时间', '结束时间'],
        label: '审核时间'
      },
      {
        domType: FormDomTypes.search,
        prop: 'memberName',
        placeHolder: '会员账号',
        width: '150px'
      },
      {
        domType: FormDomTypes.select,
        prop: 'applyStatus',
        width: '150px',
        options: dictOverflowStatus
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            memberName: '',
            applyStatus: '-1',
            createStartDate: getCurrentDateString(-31, true, 'YYYY-MM-DD'),
            createEndDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
            applyTimeStart: '',
            applyTimeEnd: ''
          }
          setFormData(params)
          filter({
            ...params,
            applyStatus: params.applyStatus === '-1' ? '' : params.applyStatus
          })
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({
            ...formData,
            applyStatus:
              formData.applyStatus === '-1' ? '' : formData.applyStatus
          })
        }
      }
    ],
    [formData, filter]
  )


  async function loadMore() {
    await nextPage({
      ...formData,
      applyStatus: formData.applyStatus === '-1' ? '' : formData.applyStatus
    })
  }

  useEffect(() => {
    if (error) {
      setFormData({
        ...formData,
        createStartDate: getCurrentDateString(-31, true, 'YYYY-MM-DD'),
        createEndDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
        applyTimeStart: '',
        applyTimeEnd: ''
      })
      Toast.show(error?.message)
    }
  }, [error])

  return (
    <div>
      <HeaderUI
        title="溢出申请"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.overflowApply}>
        <div className={styles.formBox}>
          <FormFilter
            value={formData}
            onChange={(v) => {
              setFormData({
                ...v
              })
            }}
            columns={columns}
          />
        </div>

        <div className={styles.list}>
          <LoadMoreList
            datas={pager.list}
            loadMore={loadMore}
            hasMore={pager.hasMore}
            firstLoading={pager.isFirstLoading}
            render={(item, index) => {
              return <OverflowApplyItem {...item} />
            }}
            itemClassName={styles.overflowApplyItem}
          />
        </div>
      </div>
    </div>
  )
}

export default OverflowApply
