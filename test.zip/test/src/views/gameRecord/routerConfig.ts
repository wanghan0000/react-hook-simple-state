export default {
    name: "gameRecord",
    author: true
};
  