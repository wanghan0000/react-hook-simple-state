import React, { useEffect, useMemo, useState } from 'react'
import HeaderUI from '@/compoments/HeaderUI'
import { useNavigate } from 'react-router'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import FormFilter from '@/compoments/formFilter'
import { getCurrentDateString } from '@/utils/date'
import { useAgentInfo, useGetAllGameVenue } from '@/commonApi'
import LoadMoreList from '@/compoments/loadMoreList'
import { Toast } from 'antd-mobile'
import DescriptionCard from '@/compoments/descriptionCard'
import { useGetGameInfoList } from './api'
import styles from './index.module.scss'

const dictGameRecordStatus = [
  { label: '全部', value: -1 },
  { label: '未结算', value: 0 },
  { label: '已结算', value: 1 },
  { label: '取消', value: 2 },
  { label: '无效', value: 3 }
]

export const GameRecordItem = (props: any) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [
          { title: '上级代理', text: props.vTopAgentName },
          { title: '投注金额', text: `${props.vAmount}` }
        ]
      },
      {
        group: [
            { title: '下级账号', text: props.vAccount },
            { title: '有效投注', text: props.vAmount },
        ]
      },
      {
        group: [
          { 
            title: '游戏输赢', text: props.vNetAmount,
            valueColor: props.vNetAmount > 0 ? 'green' : 'red'
          }
        ]
      },
      {
        group: [{ title: '投注时间', text: props?.vTime }]
      }
    ],
    [props]
  )
  return (
    <DescriptionCard
      topNode={
        <div className={styles.recordTop}>
          <span className={styles.recordItemLeft}>
            <p>{props.vGameName}</p>
            <div className={styles.divider}/>
            <p>{props.vVenueName}</p>
        </span>
          <div className={styles.recordStatus3}>
            <i></i>
            <div>{props.vStateText}</div>
          </div>
        </div>
      }
      bodyColumns={bodyColumns}
    />
  )
}

const GameRecord = () => {
  const navigate = useNavigate()
  
  const { data: userInfo } = useAgentInfo()
  const { data: options = [] } = useGetAllGameVenue()
  const [formData, setFormData] = useState({
    startDate: getCurrentDateString(0, true, 'YYYY-MM-DD'),
    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
    flag: '',
    memberName: '',
    venueId: ''
  })

  const { filter, pager, nextPage, reset , error } = useGetGameInfoList({
    ...formData,
    flag: -1,
    venueId: -1
  })



  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.dateRange,
        prop: ['startDate', 'endDate'],
        placeHolder: ['开始时间', '结束时间'],
        maxDate: new Date()
      },
      {
        domType: FormDomTypes.search,
        placeHolder: '下级账号',
        prop: 'memberName',
        width: '120px'
      },
      {
        domType: FormDomTypes.select,
        placeHolder: '选择游戏场馆',
        prop: 'venueId',
        width: '150px',
        options: options
      },
      {
        domType: FormDomTypes.select,
        placeHolder: '选择结算状态',
        prop: 'flag',
        width: '150px',
        options: dictGameRecordStatus
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            startDate: getCurrentDateString(0, true, 'YYYY-MM-DD'),
            endDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
            flag: '',
            memberName: '',
            venueId: ''
          }
          setFormData(params)
          reset({
            ...params,
            flag: params.flag === '' ? -1 : params.flag,
            venueId: params.venueId === '' ? -1 : params.venueId
          })
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({
            ...formData,
            flag: formData.flag === '' ? -1 : formData.flag,
            venueId: formData.venueId === '' ? -1 : formData.venueId
          })
        }
      }
    ],
    [options, formData]
  )

  async function loadMore() {
    await nextPage({
      ...formData,
      flag: formData.flag === '' ? -1 : formData.flag,
      venueId: formData.venueId === '' ? -1 : formData.venueId
    })
  }


  useEffect(() => {
    if (error) {
      Toast.show({
        content: error?.message,
      })
      setFormData({
        ...formData,
        startDate: getCurrentDateString(0, true, 'YYYY-MM-DD'),
        endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
      })
    }
  }, [error])

  return (
    <div>
      <HeaderUI
        title="游戏记录"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />
      <div className={styles.gameRecordBox}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>

      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <GameRecordItem {...item} vTopAgentName={userInfo?.name ?? '--'}/>
          }}
          itemClassName={styles.gameRecordItem}
        />
      </div>
    </div>
  )
}

export default GameRecord
