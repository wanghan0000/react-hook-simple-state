import { usePagePlus } from '@/commonHooks/usePagePlus'

const dictFlag = [
  { code: 1, dictValue: '已结算' },
  { code: 0, dictValue: '未结算' },
  { code: 2, dictValue: '订单取消' }
]
/**获取游戏数据 缓存30秒*/
export function useGetGameInfoList(params) {
  function transformData(data: any) {
    return data.map((v) => {
      return {
        ...v,
        vAccount: v.memberName ?? '--',
        vTime: v.betTime ?? '--',
        vAmount: Number(v.validBetAmount)?.toFixed?.(2),

        vStateText:
          dictFlag.find((item) => item.code === v.flag)?.dictValue ?? '--',
        vGameName: v.gameName ?? '--',
        vVenueName: v.venueName ?? '--',
        vNetAmount: Number(v.netAmount)?.toFixed?.(2)
      }
    })
  }

  return usePagePlus({
    catchKey: 'useGetGameInfoList',
    apiPath: '/game/queryGameInfo',
    formData: params,
    transformData: transformData
  })
}
