export default {
    name: "create",
    author: true,
   /**是否是根路由 */
   isRootRouter: true
};
  