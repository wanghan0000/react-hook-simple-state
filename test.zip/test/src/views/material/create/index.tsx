import HeaderUI from '@/compoments/HeaderUI'
import React, { useEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import Draggable from 'react-draggable'
import QRCode from 'qrcode.react'
import { Button, Loading, Slider, TextArea, Toast } from 'antd-mobile'
import domtoimage from 'dom-to-image'
import styles from './index.module.scss'

const dictPoints = [
  { code: 1, dictValue: '左上角' },
  { code: 2, dictValue: '右上角' },
  { code: 3, dictValue: '居中' },
  { code: 4, dictValue: '左下角' },
  { code: 5, dictValue: '右下角' }
]
const dictColors = [
  { code: 1, dictValue: '#FF2133', class: 'colorActivityWhite' },
  { code: 2, dictValue: '#FF5B00', class: 'colorActivityWhite' },
  { code: 3, dictValue: '#FF9C00', class: 'colorActivityWhite' },
  { code: 4, dictValue: '#00B73F', class: 'colorActivityWhite' },
  { code: 5, dictValue: '#009AB0', class: 'colorActivityWhite' },
  { code: 6, dictValue: '#007CDE', class: 'colorActivityWhite' },
  { code: 7, dictValue: '#7B3BF0', class: 'colorActivityWhite' },
  { code: 8, dictValue: '#000000', class: 'colorActivityWhite' },
  { code: 9, dictValue: '#FFFFFF', class: 'colorActivityBlack' },
  { code: 10, dictValue: '#F5F5F5', class: 'colorActivityBlack' }
]

interface CreateOptionsProps {
  //是否展示输入框
  showInput: boolean
  options: {
    size: number
    pointCode: number
    color: number
    input?: string
  }
  title?: string
  sliderText?: string
  pointText?: string
  colorText?: string
  inputText?: string
  onChange?: (value?: any) => void
  className?: string
  sliderMin: number
  sliderMax: number
  sliderStart: number
}

// const fetchImageWithCors = (imageUrl) => {
//   return new Promise((resolve, reject) => {
//     const xhr = new XMLHttpRequest();
//    // xhr.setRequestHeader('Access-Control-Request-Method','GET')
//     xhr.open('GET', imageUrl, true);
//     xhr.responseType = 'arraybuffer';

//     xhr.onload = function() {
//       if (this.status === 200) {
//         const reader = new FileReader();
//         reader.onload = function(e:any) {
//           resolve(e.target.result);
//         };
//         reader.readAsDataURL(this.response);
//       } else {
//         reject(new Error('Failed to load image through proxy'));
//       }
//     };

//     xhr.onerror = function() {
//       reject(new Error('Network error'));
//     };

//     xhr.send();
//   });
// };

const CreateOptions = (props: CreateOptionsProps) => {
  const getPointItem = useMemo(() => {
    return dictPoints.find((item) => item.code === props.options?.pointCode)
  }, [props])

  const getColorItem = useMemo(() => {
    return dictColors.find((item) => item.code === props.options?.color)
  }, [props])

  return (
    <div className={styles.createOptions + ' ' + props.className}>
      <div className={styles.titleWrap}>
        <div className={styles.opTextUp}>图片标题</div>
        <div className={styles.opTextDown}>{props.title}</div>
      </div>
      <div className={styles.createModule}>
        <div className={styles.sliderWrapper}>
          <div className={styles.sliderLable}>
            {props.sliderText}
            <span>{props.options.size + 'px'}</span>
          </div>
          <Slider
            onChange={(v: any) => {
              if (v <= props.sliderMin) {
                v = props.sliderMin
              }
              props.onChange?.({
                ...props.options,
                size: v
              })
            }}
            value={props.options.size}
            min={props.sliderStart}
            max={props.sliderMax}
            step={1}
          />
          <p className={styles.sliderCallout}>
            <span>小</span>
            <span>大</span>
          </p>
        </div>

        <div className={styles.positionWrapper}>
          <div className={styles.sliderLable}>
            {props.pointText}
            <span>{getPointItem?.dictValue || '自定义'}</span>
          </div>
          <div className={styles.pointsButton}>
            {dictPoints.map((v, index) => {
              return (
                <Button
                  onClick={() => {
                    props.onChange?.({
                      ...props.options,
                      pointCode: v.code
                    })
                  }}
                  fill={'outline'}
                  color={getPointItem?.code === v.code ? 'primary' : 'default'}
                  key={index}
                >
                  {v.dictValue}
                </Button>
              )
            })}
          </div>
        </div>

        <div className={styles.colorWrapper}>
          <div className={styles.sliderLable}>
            {props.colorText}
            <span>{getColorItem?.dictValue}</span>
          </div>
          <div className={styles.colorOptions}>
            {dictColors.map((v, index) => {
              return (
                <i
                  onClick={() => {
                    props.onChange?.({
                      ...props.options,
                      color: v.code
                    })
                  }}
                  className={
                    v.code === props.options.color
                      ? styles[`${getColorItem?.class}`]
                      : ''
                  }
                  key={index}
                  style={{ background: v.dictValue }}
                ></i>
              )
            })}
          </div>
        </div>

        {props.showInput && (
          <div className={styles.moduleItem}>
            <div className={styles.sliderLable}>推广链接</div>
            <TextArea
              placeholder="请输入推广链接"
              autoSize={{ minRows: 1, maxRows: 5 }}
              value={props.options.input}
              onChange={(v) => {
                props.onChange?.({
                  ...props.options,
                  input: v
                })
              }}
            />
          </div>
        )}
      </div>
    </div>
  )
}

const Create = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const { imagePath , id} = location.state || {}

  const [contentHeight, setContentHeight] = useState(0)
  const [tableIndex, setTableIndex] = useState(1)
  const [positionCode, setPositionCode] = useState({ x: 0, y: 0 })
  const [positionLink, setPositionLink] = useState({ x: 0, y: 0 })
  const [positionTips, setPositionTips] = useState({ x: 0, y: 0 })

  const [options1, setOptions1] = useState({
    size: 46,
    pointCode: 0,
    color: 8
  })
  const [options2, setOptions2] = useState({
    size: 14,
    pointCode: 0,
    color: 1,
    input: 'https://www.xordjdt.vip:9093/register?i_code=' + id
  })
  const [options3, setOptions3] = useState({
    size: 14,
    pointCode: 0,
    color: 1,
    input: ''
  })

  const [saveLoading,setSaveLoading] = useState(false)

  const contentRef = useRef<any>(null)
  const linkRef = useRef<any>(null)
  const tipsRef = useRef<any>(null)

  const tabsRef = useRef([
    {
      value: 1,
      label: '二维码'
    },
    {
      value: 2,
      label: '推广链接'
    },
    {
      value: 3,
      label: '提示文案'
    }
  ])

  useEffect(() => {
    if (options1.pointCode !== 0) {
      calculatePoint(
        options1.pointCode,
        setPositionCode,
        options1.size,
        options1.size,
        contentRef.current?.offsetWidth,
        contentHeight
      )
    }
  }, [options1, contentHeight, setPositionCode])
  useEffect(() => {
    if (options2.pointCode !== 0) {
      calculatePoint(
        options2.pointCode,
        setPositionLink,
        linkRef.current.offsetWidth,
        linkRef.current.offsetHeight,
        contentRef.current?.offsetWidth,
        contentHeight
      )
    }
  }, [options2, contentHeight, setPositionLink])
  useEffect(() => {
    if (options3.pointCode !== 0) {
      calculatePoint(
        options3.pointCode,
        setPositionTips,
        tipsRef.current.offsetWidth,
        tipsRef.current.offsetHeight,
        contentRef.current?.offsetWidth,
        contentHeight
      )
    }
  }, [options3, contentHeight, setPositionTips])

  const calculatePoint = (
    type: number,
    setFunc: any,
    selfW,
    selfH,
    allW,
    allH
  ) => {
    if (type === 1) {
      setFunc({ x: 0, y: 0 })
    } else if (type === 2) {
      setFunc({
        x: allW - selfW,
        y: 0
      })
    } else if (type === 3) {
      setFunc({
        x: allW / 2 - selfW / 2,
        y: allH / 2 - selfH / 2
      })
    } else if (type === 4) {
      setFunc({ x: 0, y: allH - selfH })
    } else if (type === 5) {
      setFunc({
        x: allW - selfW,
        y: allH - selfH
      })
    }
  }

  const trackCodePos = (data) => {
    setPositionCode({ x: data.x, y: data.y })
    if (options1.pointCode !== 0) {
      setOptions1({
        ...options1,
        pointCode: 0
      })
    }
  }
  const trackLinkPos = (data) => {
    setPositionLink({ x: data.x, y: data.y })
    if (options2.pointCode !== 0) {
      setOptions2({
        ...options2,
        pointCode: 0
      })
    }
  }
  const trackTipsPos = (data) => {
    setPositionTips({ x: data.x, y: data.y })
    if (options3.pointCode !== 0) {
      setOptions3({
        ...options3,
        pointCode: 0
      })
    }
  }

  const oWRef = useRef({ w: 0, h: 0 })
  const handleOnload = (e) => {
    const naturalWidth = e.target.naturalWidth
    const naturalHeight = e.target.naturalHeight
    const contentW = contentRef.current?.offsetWidth
    const ratio = naturalWidth / contentW
    const contentH = naturalHeight / ratio
    oWRef.current.w = naturalWidth
    oWRef.current.h = naturalHeight
    setContentHeight(contentH)
  }

  const getColor = (code: number) => {
    return dictColors.find((item) => item.code === code)?.dictValue
  }

  const saveImage = () => {
    if(saveLoading) {
      return
    }
    setSaveLoading(true)
    //通过
    //fetchImageWithCors('https://s3.ap-northeast-1.amazonaws.com/source.s3/resource/images/public/bg/default/cnq1ijmdeh62vkk8dl80_136583.png')
    const options = {
      width: oWRef.current.w,
      height: oWRef.current.h,
      style: {
        transform:
          'scale(' +
          oWRef.current.w / contentRef.current.offsetWidth +
          ', ' +
          oWRef.current.h / contentRef.current.offsetHeight +
          ')',
        transformOrigin: 'top left',
        width: contentRef.current.offsetWidth + 'px',
        height: contentRef.current.offsetHeight + 'px'
      }
    }

    domtoimage.toPng(contentRef.current, options).then(function (dataUrl) {
      const link = document.createElement('a')
      link.download = 'my-image-name.png'
      link.href = dataUrl
      link.click()

      setTimeout(() => {
        setSaveLoading(false)
      }, 200);
    }).catch((error)=>{
      setSaveLoading(false)
      Toast.show(JSON.stringify(error))
    })
  }

  return (
    <div>
      <HeaderUI
        title="生成二维码"
        showBack={true}
        onClickBack={() => navigate(-1)}
        rightNode={
          <div className={styles.save} onClick={saveImage}>
            {saveLoading ? <Loading /> : '保存'}
          </div>
        }
      />
      <div className={styles.createScroll}>
        <div className={styles.optionsText}>温馨提示：手指拖动可以调整位置</div>

        <div className={styles.createImageBox}>
          <div
            ref={contentRef}
            className={styles.createImageContent}
            style={{ width: '100%', height: `${contentHeight}px` }}
          >
            <img src={imagePath} alt="" onLoad={handleOnload} />
            <Draggable
              scale={1}
              bounds={'parent'}
              position={positionCode}
              onDrag={(e, data) => trackCodePos(data)}
              onStop={(e, data) => trackCodePos(data)}
            >
              <div className={styles.crateQrcode}>
                <QRCode
                  value={options2.input}
                  size={options1.size}
                  fgColor={
                    dictColors.find((item) => item.code === options1.color)
                      ?.dictValue
                  }
                />
              </div>
            </Draggable>

            {contentHeight && (
              <Draggable
                scale={1}
                bounds={'parent'}
                position={positionLink}
                onDrag={(e, data) => trackLinkPos(data)}
                onStop={(e, data) => trackLinkPos(data)}
              >
                <div
                  ref={linkRef}
                  className={styles.linkUrl}
                  style={{
                    fontSize: `${options2.size}px`,
                    color: getColor(options2.color)
                  }}
                >
                  {options2.input}
                </div>
              </Draggable>
            )}

            <Draggable
              scale={1}
              bounds={'parent'}
              position={positionTips}
              onDrag={(e, data) => trackTipsPos(data)}
              onStop={(e, data) => trackTipsPos(data)}
            >
              <div
                ref={tipsRef}
                className={styles.tips}
                style={{
                  fontSize: `${options3.size}px`,
                  color: getColor(options3.color)
                }}
              >
                {options3.input}
              </div>
            </Draggable>
          </div>
        </div>

        <div className={styles.buttonGroup}>
          {tabsRef.current?.map((v, index) => {
            return (
              <div
                onClick={() => setTableIndex(v.value)}
                className={
                  styles.createItem +
                  ' ' +
                  (tableIndex === v.value ? styles.createActivityItem : '')
                }
                key={index}
              >
                {v.label}
                <div className={styles.line}></div>
              </div>
            )
          })}
        </div>

        <CreateOptions
          className={tableIndex === 1 ? '' : styles.hiden}
          showInput={false}
          options={options1}
          title={'4月28日21点托特纳姆热刺vs阿森纳'}
          sliderText={'二维码大小'}
          pointText={'二维码位置'}
          colorText={'二维码颜色'}
          onChange={(v) => setOptions1(v)}
          sliderMin={46}
          sliderMax={267}
          sliderStart={36}
        />
        <CreateOptions
          className={tableIndex === 2 ? '' : styles.hiden}
          showInput={true}
          options={options2}
          title={'4月28日21点托特纳姆热刺vs阿森纳'}
          sliderText={'推广链接字体大小'}
          pointText={'推广链接位置'}
          colorText={'推广链接文字颜色'}
          inputText={'推广链接'}
          onChange={(v) => setOptions2(v)}
          sliderMin={12}
          sliderMax={32}
          sliderStart={11.5}
        />
        <CreateOptions
          className={tableIndex === 3 ? '' : styles.hiden}
          showInput={true}
          options={options3}
          title={'4月28日21点托特纳姆热刺vs阿森纳'}
          sliderText={'提示文案字体大小'}
          pointText={'提示文案位置'}
          colorText={'提示文案颜色'}
          inputText={'提示文案'}
          onChange={(v) => setOptions3(v)}
          sliderMin={12}
          sliderMax={32}
          sliderStart={11.5}
        />
      </div>
    </div>
  )
}

export default Create
