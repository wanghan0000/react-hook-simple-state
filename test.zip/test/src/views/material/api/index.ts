import { apiFetcher, useSWRExpand } from '@/api/api'
import { usePagePlus } from '@/commonHooks/usePagePlus'
import useSWRMutation from 'swr/mutation'

//缓存30分钟 图片尺寸列表
export const useGetMaterialSizeList = () => {
  const fetchFunction = () => {
    return apiFetcher(
      {
        path: '/promoteCenter/selectMaterialSizeList',
        type: 'post'
      },
      {}
    ).then((value: any) => {
      const datas = value?.data?.map?.((v) => {
        return {
          value: v,
          label: v
        }
      })
      return datas
    })
  }
  return useSWRExpand('getMaterialSizeList', fetchFunction, {
    dedupingInterval: 30 * 60 * 1000
  })
}

export interface IFMaterialList {
  imageSize: string | undefined
  imageTitle: string | undefined
  imageType: string | undefined
  pageNum: number
  pageSize: number
}
//https://api.u1s1.biz/agent/api/v1/agent/api/v1/promoteCenter/selectMaterialList
//https://api.u1s1.biz/agent/api/v1/promoteCenter/selectMaterialList
// export const useFilterMaterialList = () => {
//     const params = {
//         path: "/promoteCenter/selectMaterialList",
//         type: "post",
//     }
//     return useSWRMutation(params, (params, arg: { arg: IFMaterialList }) => {
//         return apiFetcher<IFMaterialList>(params, {...arg});
//     })
// }

export const useFilterMaterialList = (params) => {
  return usePagePlus({
    apiPath: '/promoteCenter/selectMaterialList',
    catchKey: 'useFilterMaterialList',
    formData: params,
    pageProps: 'pageNumber'
  })
}
