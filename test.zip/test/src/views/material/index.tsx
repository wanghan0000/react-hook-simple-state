import HeaderUI from '@/compoments/HeaderUI'
import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import QuestionMark from '@/assets/main/questionMark.png'
import { Button, List, Modal, SpinLoading } from 'antd-mobile'
import { useFilterMaterialList, useGetMaterialSizeList } from './api'
import FormFilter from '@/compoments/formFilter'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import IconImage from '@/compoments/IconImage'
import LoadMoreFooter from '@/compoments/loadMoreFooter'
import styles from './index.module.scss'

const dictImageTypes = [
  { value: '1', label: '综合推广图' },
  { value: '2', label: 'app推广图' },
  { value: '3', label: '赞助推广图' },
  { value: '4', label: '赠送推广图' }
]

const modleConfigs = [
  '什么是推广素材？',
  '1. 通过推广素材功能，代理可以利用系统提供的图片素材自定义推广图片。',
  '2. 推广图片可添加二维码、提示文字等，位置、颜色和大小都可进行自定义。'
]

interface MaterialItemProps {
  src: string | undefined
  imageTitle?: string
  imageType?: string
  imageSize?: string
  downloadTimes?: string
  id: number
}
const MaterialItem = (props: MaterialItemProps) => {
  const navigate = useNavigate()
  return (
    <div className={styles.materialItem}>
      <div className={styles.itemImg}>
        <IconImage imagePath={props.src} className={styles.itemIconImage}/>
      </div>
      <div className={styles.itemConent}>
        <h5>{props.imageTitle}</h5>
        <div className={styles.contentText}>
          <p>
            <span className={styles.grayText}>图片类型：</span>
            <span className={styles.dataText}>
              {
                dictImageTypes.find(
                  (item: any) => item.value === props.imageType
                )?.label
              }
            </span>
          </p>
        </div>
        <div className={styles.contentText}>
          <p>
            <span className={styles.grayText}>图片尺寸：</span>
            <span className={styles.dataText}>{props.imageSize}</span>
          </p>
        </div>
        <div className={styles.contentText}>
          <p>
            <span className={styles.grayText}>下载次数：</span>
            <span className={styles.dataText}>{props.downloadTimes}</span>
          </p>
        </div>
        <Button onClick={()=> navigate('/material/create',{
          state: {
            imagePath: props.src,
            id: props?.id
          }
        })} className={styles.button}>生成二维码</Button>
      </div>
    </div>
  )
}

const Material = () => {
  const navigate = useNavigate()
  const [visible, setVisible] = useState(false)

  const { data: sizeList } = useGetMaterialSizeList()
  //const [materialList, setMaterialList] = useState<any[]>([])
  //const { trigger, isMutating } = useFilterMaterialList()

  const [formData, setFormData] = useState({
    imageSize: '',
    imageTitle: '',
    imageType: ''
  })
  const [showPopup, setShowPopup] = useState({
    show: false,
    current: ''
  })
  const { filter, pager, nextPage , reset  } = useFilterMaterialList({
    ...formData
  })
  //当数据更新时重新计算
  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.select,
        prop: 'imageType',
        placeHolder: '选择图片类型',
        options: dictImageTypes,
        width: '150px'
      },
      {
        domType: FormDomTypes.select,
        prop: 'imageSize',
        placeHolder: '选择图片尺寸',
        options: sizeList || [],
        width: '150px'
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.search,
        placeHolder: '输入标题关键字',
        prop: 'imageTitle',
        width: '140px'
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            imageSize: '',
            imageTitle: '',
            imageType: ''
          }
          setFormData(params)
          reset(params)
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({
            ...formData
          })
        }
      }
    ],
    [sizeList, formData, showPopup]
  )

 

  //const [hasMore, setHasMore] = useState(true)
  async function loadMore() {
    await nextPage({ ...formData })
  }


  return (
    <div>
      <HeaderUI
        title="推广素材"
        showBack={true}
        onClickBack={() => navigate(-1)}
        rightNode={
          <img
            onClick={() => setVisible(true)}
            className={styles.questionMark}
            src={QuestionMark}
            alt="QuestionMark"
          />
        }
      />
      <div className={styles.materialBox}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>
      <div className={styles.list}>
        <List>
          {pager.list?.map?.((item, index) => (
            <MaterialItem
              src={item?.imageUrl}
              key={index}
              imageTitle={item.imageTitle}
              imageType={item.imageType}
              imageSize={item.imageSize}
              downloadTimes={item.downloadTimes}
              id={item.id}
            />
          ))}
        </List>
        <LoadMoreFooter loadMore={loadMore} hasMore={pager.hasMore} />
        {pager.isFirstLoading && (
          <div className={styles.loadingUI} >
            <SpinLoading color="primary" />
          </div>
        )}
      </div>

      <Modal
        visible={visible}
        title="温馨提示"
        closeOnMaskClick={false}
        bodyClassName={styles.materialModal}
        content={
          <>
            <h5>{modleConfigs[0]}</h5>
            <p>{modleConfigs[1]}</p>
            <p>{modleConfigs[2]}</p>
          </>
        }
        closeOnAction
        onClose={() => {
          setVisible(false)
        }}
        actions={[
          {
            key: 'confirm',
            text: '我知道了'
          }
        ]}
      />
    </div>
  )
}

export default Material
