export default {
    name: "material",
    author: true
};
  