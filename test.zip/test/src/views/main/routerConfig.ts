export default {
  name: "main",
  /**默认子路由 */
  defaultRoute: "/main/home",
  /**是否需要登录授权 */
  author: true
};
