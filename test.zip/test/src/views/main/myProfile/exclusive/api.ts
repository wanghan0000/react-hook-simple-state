import { apiFetcher, useSWRExpand } from '@/api/api'

//vip专享
export const useGetVipExclusive = () => {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/personCenter/getVipExclusive',
        type: 'post'
      },
      {}
    ).then((res: any) => {
      console.log('res', res)
      const list = res.list?.map((v) => {
        return {
          ...v,
          level: v.levelName,
          members: v.activeCount,
          activity: v.newActiveCount,
          tips1: v.extraCommission,
          amount: v.gameWinning
        }
      })
      return list
    })
  }
  return useSWRExpand('useGetVipExclusive', fetcherFuc, {
    dedupingInterval: 20 * 60 * 1000
  })
}
