import HeaderUI from '@/compoments/HeaderUI'
import React from 'react'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'
import { useGetVipExclusive } from './api'
import SkeletonUI from '@/compoments/SkeletonUI'

const Exclusive = () => {
  const navigate = useNavigate()
  const { data: datas, isLoading, error } = useGetVipExclusive()
  return (
    <div>
      <HeaderUI
        title="VIP专享"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <SkeletonUI isLoading={isLoading} error={error} data={datas}>
        <div className={styles.exclusive}>
          <div className={styles.tableView}>
            <div className={styles.title}>等级规则表</div>
            <div className={styles.tips}>
              <div>
                <p>
                  默认按高等级VIP发放佣金，高等级VIP如果未达到本等级增长要求，可按对应等级的增长标准与奖励制度执行，只可享受一个等级奖励；
                </p>
                <p>
                  额外佣金和游戏彩金的奖励不会同时发放，游戏彩金会在达到等级的代理当月佣金为0（无盈利或亏损）的时候发放；
                </p>
              </div>
            </div>

            <div className={styles.tableHeader}>
              <span style={{ width: '30px' }}>级别</span>
              <span style={{ width: '60px' }}>活跃会员</span>
              <span style={{ width: '60px' }}>新增活跃</span>
              <span style={{ width: '90px' }}>额外返佣</span>
              <span style={{ width: '75px' }}>游戏彩金</span>
            </div>

            <div className={styles.tableBody}>
              {datas?.map?.((v, index) => {
                return (
                  <div key={index} className={styles.tr}>
                    <span style={{ width: '21px' }}>{v.level}</span>
                    <span style={{ width: '60px' }}>{v.members}</span>
                    <span style={{ width: '60px' }}>{v.activity}</span>
                    <span style={{ width: '95px' }}>{v.tips1}</span>
                    <span style={{ width: '80px' }}>{v.amount}</span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </SkeletonUI>
    </div>
  )
}

export default Exclusive
