import React, { useEffect, useState } from 'react'
import IconImage from '@/compoments/IconImage'
import settingsPng from '@/assets/main/settings.png'
import serverPng from '@/assets/main/server.png'
import HideEyePng from '@/assets/common/hideEye.png'
import RefreshPng from '@/assets/common/refresh.png'
import WalletDeposit from '@/assets/common/walletDeposit.png'
import WalletWithdraw from '@/assets/common/walletWithdraw.png'
import { List, Toast } from 'antd-mobile'
import TopicPng from '@/assets/common/topic.png'
import IconMessage from './assets/iconMessage.png'
import IconSafety from './assets/iconSafety.png'
import IconVip from './assets/iconVip.png'
import { useNavigate } from 'react-router'
import SecurityCheck from '@/compoments/securityCheck'
import { useGetDrawCacheMoney } from '../members/api'
import { useAgentInfo } from '@/commonApi'
import { useAuth } from '@/compoments/AuthProvider'
import Flygram from './components/Flygram'
import SkeletonUI from '@/compoments/SkeletonUI'
import styles from './index.module.scss'
import { useGetUnreadForType } from './api'

const MyProfile = () => {
  const navigate = useNavigate()
  const moneyIcons = [
    {
      imagePath: WalletDeposit,
      title: '额度充值',
      onClick: () => {
        navigate('/recharge')
      }
    },
    {
      imagePath: WalletWithdraw,
      title: '佣金提款',
      onClick: () => {
        navigate('/withdrawal')
      }
    }
  ]

  const [showSecurity, setShowSecurity] = useState(false)
  const [showFlygram, setShowFlygram] = useState(false)

  //const { trigger, isMutating } = useGetDrawMoney()
  const { mutate, data: initMoney, isValidating } = useGetDrawCacheMoney()
  const { customConfig, setCustomConfig } = useAuth()
  const [amount, setAmount] = useState(
    customConfig?.myProfileEye ? '0.00' : '****'
  )
  const { data, isLoading, error, mutate: mutateAgentInfo } = useAgentInfo()

  const { data: notice } = useGetUnreadForType()

  const handleConfigChange = async () => {
    if (customConfig.myProfileEye) {
      try {
        await mutate()
        setShowSecurity(false)
      } catch (error: any) {
        Toast.show(error?.message || JSON.stringify(error))
      }
    }
  }
  useEffect(() => {
    if (initMoney) {
      setAmount(initMoney?.agentMoney)
    }
  }, [initMoney])

  useEffect(() => {
    handleConfigChange()
  }, [customConfig, setShowSecurity])

  return (
    <SkeletonUI block={3} isLoading={isLoading} error={error} data={data}>
      <div className={styles.mine}>
        <div className={styles.headerWarp}>
          <div className={styles.userInfoBox}>
            <div className={styles.userWarp}>
              <div className={styles.userPortrait}>{data?.name?.[0]}</div>
              <div className={styles.userRight}>
                <div className={styles.userName}>
                  <span>{data?.name ?? '--'}</span>
                </div>
                <p>合营代码：{data?.memberId}</p>
              </div>
            </div>

            <div className={styles.noun}>
              <img
                src={settingsPng}
                alt="settings"
                onClick={() => navigate('/setup')}
              />
              <img
                src={serverPng}
                alt="server"
                onClick={() => {
                  navigate('/online')
                }}
              />
            </div>
          </div>
        </div>

        <div className={styles.commissionWarp}>
          <div className={styles.moneyWarpLeft}>
            <div className={styles.moneyWarpTitle}>
              <h6>我的佣金</h6>
              {amount === '****' && (
                <img
                  src={HideEyePng}
                  alt="eye"
                  onClick={() => setShowSecurity(true)}
                />
              )}
            </div>

            <div className={styles.moneyNumber}>
              <div className={styles.moneyText}>
                <span>{amount}</span>
                {amount !== '****' && (
                  <img
                    onClick={async () => {
                      try {
                        await mutate()
                      } catch (error: any) {
                        Toast.show(error?.message || JSON.stringify(error))
                      }
                    }}
                    src={RefreshPng}
                    alt="refresh"
                    className={isValidating ? styles.iconLoading : ''}
                  />
                )}
              </div>
            </div>
          </div>

          <ul className={styles.moneyWarpRight}>
            {moneyIcons.map((v, index) => {
              return (
                <li key={index}>
                  <IconImage
                    imagePath={v.imagePath}
                    className={styles.iconImage}
                    onClick={v.onClick}
                  />
                  <p>{v.title}</p>
                </li>
              )
            })}
          </ul>
        </div>

        <div className={styles.listWarp}>
          <List>
            <List.Item
              prefix={
                <img
                  className={styles.listIconImage}
                  src={TopicPng}
                  alt="TopicPng"
                ></img>
              }
              clickable
              onClick={() => navigate('/main/myProfile/notice')}
            >
              消息中心
              {(!!notice?.noticeCount ||
                !!notice?.activityCount ||
                !!notice?.bulletinCount) && (
                <i className={styles.messageIcon}></i>
              )}
            </List.Item>
          </List>

          <List>
            <List.Item
              prefix={
                <img
                  className={styles.listIconImage}
                  src={IconMessage}
                  alt="TopicPng"
                ></img>
              }
              extra={
                <div className={styles.mineRightText}>
                  <span>{!!data?.flygram ? data?.flygram : '未绑定'}</span>
                </div>
              }
              clickable
              onClick={() => setShowFlygram(true)}
            >
              优信
            </List.Item>
          </List>
          <List>
            {/* <List.Item
              prefix={
                <img
                  className={styles.listIconImage}
                  src={IconCalculator}
                  alt="TopicPng"
                ></img>
              }
              clickable
            >
              佣金模拟器
            </List.Item> */}
            <List.Item
              prefix={
                <img
                  className={styles.listIconImage}
                  src={IconSafety}
                  alt="TopicPng"
                ></img>
              }
              clickable
              onClick={() => navigate('/main/myProfile/securityCenter')}
            >
              安全中心
            </List.Item>
            <List.Item
              prefix={
                <img
                  className={styles.listIconImage}
                  src={IconVip}
                  alt="TopicPng"
                ></img>
              }
              clickable
              onClick={() => navigate('/main/myProfile/exclusive')}
            >
              VIP专享
            </List.Item>
          </List>
        </div>
        <SecurityCheck
          eyesType={2}
          onSussess={async () => {
            //请求数据
            setCustomConfig({
              ...customConfig,
              myProfileEye: true
            })
          }}
          visible={showSecurity}
          onClose={() => setShowSecurity(false)}
        />
        <Flygram
          visible={showFlygram}
          onClose={() => setShowFlygram(false)}
          onSussess={async (v) => {
            await mutateAgentInfo()
            setShowFlygram(false)
          }}
          model={!!data?.flygram ? 1 : 0}
        />
      </div>
    </SkeletonUI>
  )
}
//
export default MyProfile
