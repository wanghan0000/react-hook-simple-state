import { Popup } from 'antd-mobile'
import React from 'react'
import styles from './index.module.scss'

interface MessagePopProps {
  visible: boolean
  onClose: () => void
  onSussess: (v: any) => void
  options: any[]
}

const MessagePop = (props: MessagePopProps) => {
  return (
    <Popup
      visible={props.visible}
      onMaskClick={() => {
        props.onClose?.()
      }}
      bodyStyle={{
        borderTopLeftRadius: '8px',
        borderTopRightRadius: '8px',
      }}
    >
      <div className={styles.messagePopContent}>
        {props.options?.map((v, index) => {
          return (
            <div
              key={index}
              onClick={() => {
                props.onSussess?.(index)
              }}
            >
              {v}
            </div>
          )
        })}
        {/* <div
          onClick={() => {
            props.onSussess?.(0)
          }}
        >
          编辑消息
        </div>
        <div
          onClick={() => {
            props.onSussess?.(1)
          }}
        >
          全部已读
        </div>
       */}
        <div
          onClick={() => {
            props.onSussess?.(2)
          }}
        >
          取消
        </div>
      </div>
    </Popup>
  )
}

export default MessagePop
