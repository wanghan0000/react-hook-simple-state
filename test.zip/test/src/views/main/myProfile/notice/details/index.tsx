import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import { useBatchDelete, useGetUnreadForType, useReadDetails } from '../../api'
import HeaderUI from '@/compoments/HeaderUI'
import styles from './index.module.scss'
import IconImage from '@/compoments/IconImage'
import NoticeIcon from '@/assets/common/noticeIcon.png'
import MoreImage from '@/assets/common/more.png'
import MessagePop from '../messagePop'
import { SpinLoading, Toast } from 'antd-mobile'

const Details = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const data = location.state || {}
  const { trigger } = useReadDetails()
  const { trigger: triggerDelete, isMutating } = useBatchDelete()

  const { mutate } = useGetUnreadForType()

  useEffect(() => {
    if (data?.isRead === 0) {
      trigger({
        id: data.id,
        userSystem: data.userSystem
      }).then(() => {
        mutate()
      })
    }
  }, [data])

  const [showMessagePop, setShowMessagePop] = useState(false)

  const handleDelete = async () => {
    try {
      await triggerDelete({
        id: data.id,
        userSystem: data.userSystem
      })
      navigate(-1)
    } catch (error: any) {
      Toast.show(error.message || JSON.stringify(error))
    }
  }

  return (
    <div>
      <HeaderUI
        title="消息详情"
        showBack={true}
        onClickBack={() => {
          if (!isMutating) {
            navigate(-1)
          }
        }}
        rightNode={
          <>
            {typeof data?.isRead !== 'undefined' && (
              <IconImage
                onClick={() => {
                  setShowMessagePop(true)
                }}
                imagePath={MoreImage}
                className={styles.imageNode}
              />
            )}
          </>
        }
      />

      <div className={styles.messageListItem}>
        <IconImage imagePath={NoticeIcon} className={styles.itemIcon} />
        <div className={styles.itemContent}>
          <div className={styles.contentTitle}>
            <h5>{data.title}</h5>
          </div>
          <div>{data.vShowTime}</div>
        </div>
      </div>
      <div className={styles.messageContent}>
        <div>{data?.content}</div>
      </div>

      {isMutating && (
        <div className={styles.loadingUI}>
          <SpinLoading color="primary" />
        </div>
      )}

      <MessagePop
        options={['删除']}
        visible={showMessagePop}
        onClose={() => {
          setShowMessagePop(false)
        }}
        onSussess={(v: any) => {
          setShowMessagePop(false)
          if (v === 0) {
            console.log('删除')
            handleDelete()
          }
        }}
      />
    </div>
  )
}

export default Details
