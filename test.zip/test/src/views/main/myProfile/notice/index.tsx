import HeaderUI from '@/compoments/HeaderUI'
import { Badge, Tabs, Toast } from 'antd-mobile'
import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState
} from 'react'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'
import {
  useBatchDelete,
  useGetBulletinCount,
  useGetMsgList,
  useGetUnreadForType,
  useReadDetails
} from '../api'
import LoadMoreList from '@/compoments/loadMoreList'
import NoticeIcon from '@/assets/common/noticeIcon.png'
import IconImage from '@/compoments/IconImage'
import MoreImage from '@/assets/common/more.png'
import MessagePop from './messagePop'
import UnSelectCircle from '@/assets/common/unSelectCircle.png'
import SelectCircle from '@/assets/common/selectCircle.png'

const NoticeItem = (props: any) => {
  const navigate = useNavigate()

  const handleNavgate = () => {
    navigate('/main/myProfile/notice/details', {
      state: {
        ...props,
        onChange: undefined,
        isSelect: undefined,
        vShowTime: props.sendTime
      }
    })
  }
  return (
    <div
      onClick={props.pageMode !== '0' ? handleNavgate : undefined}
      className={
        styles.messageListItem +
        ' ' +
        (props.isRead === 0 ? styles.messageActivity : '')
      }
    >
      {props.pageMode === '0' && (
        <IconImage
          imagePath={props.isSelect ? SelectCircle : UnSelectCircle}
          className={styles.itemIcon2}
          onClick={() => {
            props.onChange?.(props.isSelect ? '0' : '1')
          }}
        />
      )}
      <IconImage imagePath={NoticeIcon} className={styles.itemIcon} />
      <div className={styles.itemContent}>
        <div className={styles.contentTitle}>
          <h5>{props.title}</h5>
          <p>{props.sendTime}</p>
        </div>
        <div className={styles.contentInfo}>{props.content}</div>
      </div>
    </div>
  )
}

const AnnouncementItem = (props: any) => {
  const navigate = useNavigate()
  return (
    <div
      onClick={() =>
        navigate('/main/myProfile/notice/details', {
          state: {
            ...props,
            vShowTime: props.createdAt
          }
        })
      }
      className={
        styles.messageListItem +
        ' ' +
        (props.isRead === 0 ? styles.messageActivity : '')
      }
    >
      <IconImage imagePath={NoticeIcon} className={styles.itemIcon} />
      <div className={styles.itemContent}>
        <div className={styles.contentTitle}>
          <h5>{props.title}</h5>
          <p>{props.createdAt}</p>
        </div>
        <div className={styles.contentInfo}>{props.content}</div>
      </div>
    </div>
  )
}

const AnnouncementList = () => {
  const { pager, nextPage } = useGetBulletinCount({
    clients: '1'
  })

  async function loadMore() {
    await nextPage({
      clients: '2'
    })
  }

  return (
    <div className={styles.list}>
      <LoadMoreList
        datas={pager.list}
        loadMore={loadMore}
        hasMore={pager.hasMore}
        firstLoading={pager.isFirstLoading}
        render={(item, index) => {
          return <AnnouncementItem {...item} />
        }}
        itemClassName={styles.gameRecordItem}
      />
    </div>
  )
}

const NotifyMessageList = forwardRef((props: any, ref) => {
  const { pager, nextPage, resetMutate } = useGetMsgList({
    msgType: props.msgType,
    userSystem: '2'
  })

  async function loadMore() {
    await nextPage({
      msgType: props.msgType,
      userSystem: '2'
    })
  }

  const getList = () => {
    return pager.list
  }

  const refresh = () => {
    resetMutate({
      msgType: props.msgType,
      userSystem: '2'
    })
  }

  useImperativeHandle(ref, () => ({
    getList,
    refresh
  }))

  return (
    <div className={styles.list}>
      <LoadMoreList
        datas={pager.list}
        loadMore={loadMore}
        hasMore={pager.hasMore}
        firstLoading={pager.isFirstLoading}
        render={(item, index) => {
          return (
            <NoticeItem
              isSelect={!!props?.selects?.find?.((v) => item === v)}
              onChange={(operator) => {
                props.onChange?.(item, operator)
              }}
              {...item}
              pageMode={props.pageMode}
            />
          )
        }}
        itemClassName={styles.gameRecordItem}
      />
    </div>
  )
})

const Notice = () => {
  const navigate = useNavigate()

  const [status, setStatus] = useState('0')
  const { data: notice, mutate } = useGetUnreadForType()

  const [showMessagePop, setShowMessagePop] = useState(false)

  // 0 编辑
  const [pageMode, setPageMode] = useState('2')
  const [selects1, setSelects1] = useState<any[]>([])
  const [selects2, setSelects2] = useState<any[]>([])

  const { trigger, isMutating } = useReadDetails()
  const { trigger: triggerDelete, isMutating: deleteMutating } =
    useBatchDelete()

  const messageRef1 = useRef<any>(null)
  const messageRef2 = useRef<any>(null)

  const handleSelect = (v, operator) => {
    let select: any
    let setSelect: any
    if (status === '0') {
      select = selects1
      setSelect = setSelects1
    } else {
      select = selects2
      setSelect = setSelects2
    }
    if (operator === '0') {
      //取消
      const arr = select.filter((item) => {
        return item !== v
      })
      setSelect([...arr])
    } else {
      // 选中
      select.push(v)
      setSelect([...select])
    }
  }

  useEffect(() => {
    let select: any
    if (status === '0') {
      select = selects1
    } else {
      select = selects2
    }
  }, [status])

  const isAll = useMemo(() => {
    let select: any
    let ref: any
    if (status === '0') {
      select = selects1
      ref = messageRef1.current
    } else {
      select = selects2
      ref = messageRef2.current
    }
    if (select.length === ref?.getList?.().length) {
      return true
    }
    return false
  }, [selects1, selects2, status])

  const hasList = useMemo(() => {
    let select: any
    if (status === '0') {
      select = selects1
    } else {
      select = selects2
    }
    return select
  }, [selects1, selects2, status])

  const readList = useMemo(() => {
    let select: any
    if (status === '0') {
      select = selects1
    } else {
      select = selects2
    }
    return select.map((v) => {
      if (v.isRead === 0) {
        return {
          ...v
        }
      }
    })
  }, [selects1, selects2, status])

  const handleReadAll = async () => {
    setPageMode('2')
    if (isMutating || deleteMutating) {
      return
    }
    let list: any[]
    let refresh: any
    if (status === '0') {
      list = messageRef1.current.getList()
      refresh = messageRef1.current.refresh
    } else {
      list = messageRef2.current.getList()
      refresh = messageRef2.current.refresh
    }
    list = list.filter((v)=> v.isRead === 0)
    list = list.map((v) => {
      return v.id
    })
    const str = list.toString()
    if (!str) {
      Toast.show('没有可读信息')
      return
    } else {
      try {
        await trigger({
          id: str,
          userSystem: '2'
        })
        mutate()
        refresh()
      } catch (error: any) {
        Toast.show(error?.message || JSON.stringify(error))
      }
    }
  }

  const handleReadSelect = async () => {
    setPageMode('2')
    if (isMutating || deleteMutating) {
      return
    }
    let refresh: any
    if (status === '0') {
      refresh = messageRef1.current.refresh
    } else {
      refresh = messageRef2.current.refresh
    }
    const list = readList.map((v) => {
      return v.id
    })
    const str = list.toString()
    if (!str) {
      return
    } else {
      try {
        await trigger({
          id: str,
          userSystem: '2'
        })
        mutate()
        refresh()
      } catch (error: any) {
        Toast.show(error?.message || JSON.stringify(error))
      }
    }
  }

  const handleDelete = async () => {
    setPageMode('2')
    if (isMutating || deleteMutating) {
      return
    }
    let refresh: any
    if (status === '0') {
      refresh = messageRef1.current.refresh
    } else {
      refresh = messageRef2.current.refresh
    }
    const list = hasList.map((v) => {
      return v.id
    })
    const str = list.toString()
    if (!str) {
      return
    } else {
      try {
        await triggerDelete({
          id: str,
          userSystem: '2'
        })
        mutate()
        refresh()
      } catch (error: any) {
        Toast.show(error?.message || JSON.stringify(error))
      }
    }
  }

  return (
    <div>
      <HeaderUI
        title="消息中心"
        showBack={true}
        onClickBack={() => {
          if (pageMode === '0') {
            setPageMode('2')
          } else {
            navigate(-1)
          }
        }}
        rightNode={
          status !== '2' &&
          pageMode !== '0' && (
            <IconImage
              onClick={() => {
                setShowMessagePop(true)
              }}
              imagePath={MoreImage}
              className={styles.imageNode}
            />
          )
        }
      />

      <Tabs
        className={
          styles.tabs + ' ' + (pageMode === '0' ? styles.editTabs : '')
        }
        activeLineMode="fixed"
        onChange={(v) => {
          setStatus(v)
        }}
        style={{
          '--fixed-active-line-width': '90px',
          '--title-font-size': '14px'
        }}
      >
        <Tabs.Tab
          title={
            <span
              className={
                styles.tabsTitle +
                ' ' +
                (status === '0' ? styles.activityTile : '')
              }
            >
              通知
              {!!notice?.noticeCount && <i>{notice?.noticeCount}</i>}
            </span>
          }
          key="0"
        />
        <Tabs.Tab
          title={
            <span
              className={
                styles.tabsTitle +
                ' ' +
                (status === '1' ? styles.activityTile : '')
              }
            >
              活动
              {!!notice?.activityCount && <i>{notice?.activityCount}</i>}
            </span>
          }
          key="1"
        />
        <Tabs.Tab
          title={
            <span
              className={
                styles.tabsTitle +
                ' ' +
                (status === '2' ? styles.activityTile : '')
              }
            >
              公告
              {!!notice?.bulletinCount && <i>{notice?.bulletinCount}</i>}
            </span>
          }
          key="2"
        />
      </Tabs>
      {status === '0' && (
        <NotifyMessageList
          selects={selects1}
          onChange={handleSelect}
          msgType={1}
          ref={messageRef1}
          pageMode={pageMode}
        />
      )}
      {status === '1' && (
        <NotifyMessageList
          selects={selects2}
          onChange={handleSelect}
          msgType={2}
          ref={messageRef2}
          pageMode={pageMode}
        />
      )}
      {status === '2' && <AnnouncementList />}

      {pageMode === '0' && (
        <div className={styles.messageFooter}>
          <ul>
            <li
              onClick={() => {
                if (status === '0') {
                  if (isAll) {
                    setSelects1([])
                  } else {
                    setSelects1([...messageRef1.current.getList()])
                  }
                } else {
                  if (isAll) {
                    setSelects2([])
                  } else {
                    setSelects2([...messageRef2.current.getList()])
                  }
                }
              }}
            >
              <IconImage
                imagePath={isAll ? SelectCircle : UnSelectCircle}
                className={styles.itemIcon2}
              />
              <p>全选</p>
            </li>
            <li>
              <span
                onClick={() => {
                  if (readList.length) {
                    handleReadSelect()
                  }
                }}
                className={readList.length ? styles.activityRead : ''}
              >
                标记已读
              </span>
            </li>
            <li>
              <span
                onClick={() => {
                  if (hasList.length) {
                    handleDelete()
                  }
                }}
                className={hasList.length ? styles.deleteActivity : ''}
              >
                删除
              </span>
            </li>
          </ul>
        </div>
      )}

      <MessagePop
        options={['编辑消息', '全部已读']}
        visible={showMessagePop}
        onClose={() => {
          setShowMessagePop(false)
        }}
        onSussess={(v: any) => {
          setShowMessagePop(false)
          setPageMode(`${v}`)
          setSelects1([])
          setSelects2([])

          if (v === 1) {
            //全部已读
            handleReadAll()
          }
        }}
      />
    </div>
  )
}

export default Notice
