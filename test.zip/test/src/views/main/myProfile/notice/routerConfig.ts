export default {
  name: 'notice',
  author: true,
  /**是否是根路由 */
  isRootRouter: true
}
