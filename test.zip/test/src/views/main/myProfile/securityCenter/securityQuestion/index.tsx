import HeaderUI from '@/compoments/HeaderUI'
import { Button, Steps, Toast } from 'antd-mobile'
import { Step } from 'antd-mobile/es/components/steps/step'
import React, { useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import StepIconActivity from '../assets/stepIconActivity.png'
import SetpIcon from '../assets/stepIcon.png'
import styles from './index.module.scss'
import IconImage from '@/compoments/IconImage'
import FormList, { FormListItemType } from '@/compoments/formList'
import { useApiSecurityCheck } from '@/compoments/securityCheck/api'
import { md5Hash } from '@/utils/md5'
import {
  useBindSecurityQuestion,
  useCheckAgentSecurity,
  useCheckSecurity,
  useGetBindSecurityQuestion
} from '../api'
import SkeletonUI from '@/compoments/SkeletonUI'

const Step2 = (props: any) => {
  const navigate = useNavigate()

  const { trigger, isMutating } = useBindSecurityQuestion()
  const { mutate, isValidating } = useCheckSecurity()
  const [formData, setFormData] = useState({
    question1: props.params?.question1 || '',
    answer1: props.params?.answer1 || '',
    question2: props.params?.question2 || '',
    answer2: props.params?.answer2 || '',
    question3: props.params?.question3 || '',
    answer3: props.params?.answer3 || ''
  })

  const answerRef = useRef({
    answer1: props.params?.pAnswer1,
    answer2: props.params?.pAnswer2,
    answer3: props.params?.pAnswer3
  })
  const columns = [
    {
      domType: FormListItemType.input,
      prefix: '问题一',
      prop: 'question1',
      placeHolder: '请输入密保问题(例如：芝麻开门的暗号？)',
      readonly: props.readonly
    },
    {
      domType: FormListItemType.input,
      prefix: '答 案',
      prop: 'answer1',
      placeHolder: '请输入密保答案'
    },
    {
      domType: FormListItemType.input,
      prefix: '问题二',
      prop: 'question2',
      placeHolder: '请输入密保问题',
      readonly: props.readonly
    },
    {
      domType: FormListItemType.input,
      prefix: '答 案',
      prop: 'answer2',
      placeHolder: '请输入密保答案'
    },
    {
      domType: FormListItemType.input,
      prefix: '问题三',
      prop: 'question3',
      placeHolder: '请输入密保问题',
      readonly: props.readonly
    },
    {
      domType: FormListItemType.input,
      prefix: '答 案',
      prop: 'answer3',
      placeHolder: '请输入密保答案'
    }
  ]

  const btnButtonState = useMemo(() => {
    const questions = [
      formData.question1,
      formData.question2,
      formData.question3
    ]
    const answers = [formData.answer1, formData.answer2, formData.answer3]
    for (const item of questions) {
      if (item.length < 4 || item.length > 20) {
        return true
      }
    }
    for (const item of answers) {
      if (item.length < 6 || item.length > 20) {
        return true
      }
    }
    return false
  }, [formData])

  const tipsText = useMemo(() => {
    const questions = [
      formData.question1,
      formData.question2,
      formData.question3
    ]
    for (const item of questions) {
      if (item.length < 4 || item.length > 20) {
        return '问题长度为4至20位，仅支持设置英文、中文或数字'
      }
    }
    return '答案长度为6至20位，包含英文、中文和数字任意类型'
  }, [formData])

  const handleSubmit = async () => {
    if (props.readonly) {
      if (
        answerRef.current.answer1 !== formData.answer1 ||
        answerRef.current.answer2 !== formData.answer2 ||
        answerRef.current.answer3 !== formData.answer3
      ) {
         Toast.show('确认密保和设置的密保答案不一致，请检查')
         return
      }
      try {
        await trigger({
          answer: {
            '1': formData.answer1,
            '2': formData.answer2,
            '3': formData.answer3
          },
          question: {
            '1': formData.question1,
            '2': formData.question2,
            '3': formData.question3
          },
          secretType: props.secretType,
          twoStepCode: props.twoStepCode
        })
        await mutate()
        props?.onSuccess?.()
        Toast.show('绑定成功')
        navigate('/main/myProfile/securityCenter', {
          replace: true
        })
      } catch (error: any) {
        Toast.show(error?.message || JSON.stringify(error))
      }
    } else {
      props?.onSuccess?.(formData)
    }
  }

  const handlePrevious = () => {
    props.onPrevious?.()
  }

  return (
    <>
      <FormList
        className={styles.formList + ' ' + styles.formStep2}
        columns={columns}
        values={formData}
        onChange={(v) => {
          setFormData(v)
        }}
      />
      {btnButtonState && <div className={styles.errTip}>{tipsText}</div>}
      <div className={styles.questiontips}>
        密保问题作为核实您身份的重要依据，请尽量设置隐晦不易猜出
      </div>

      <div className={styles.addFooter}>
        {props.readonly && (
          <Button
            onClick={handlePrevious}
            loading={isMutating || isValidating}
            className={styles.previous}
          >
            {' '}
            上一步
          </Button>
        )}
        <Button
          disabled={btnButtonState}
          onClick={handleSubmit}
          loading={isMutating || isValidating}
          className={styles.addBtn}
          style={{ '--text-color': 'var(--adm-color-white)' }}
        >
          {props.readonly ? '确认密保' : '下一步'}
        </Button>
      </div>
    </>
  )
}

const ModifyStep1 = (props: any) => {
  const { trigger, isMutating } = useCheckAgentSecurity()
  const [formData, setFormData] = useState({
    question1: props.params['1'],
    question2: props.params['2'],
    question3: props.params['3'],
    answer1: '',
    answer2: '',
    answer3: ''
  })
  const columns = [
    {
      domType: FormListItemType.input,
      prefix: '问题一',
      prop: 'question1',
      readonly: true
    },
    {
      domType: FormListItemType.input,
      prefix: '答 案',
      prop: 'answer1',
      placeHolder: '请输入密保答案'
    },
    {
      domType: FormListItemType.input,
      prefix: '问题二',
      prop: 'question2',
      readonly: true
    },
    {
      domType: FormListItemType.input,
      prefix: '答 案',
      prop: 'answer2',
      placeHolder: '请输入密保答案'
    },
    {
      domType: FormListItemType.input,
      prefix: '问题三',
      prop: 'question3',
      readonly: true
    },
    {
      domType: FormListItemType.input,
      prefix: '答 案',
      prop: 'answer3',
      placeHolder: '请输入密保答案'
    }
  ]

  const btnButtonState = useMemo(() => {
    const questions = [
      formData.question1,
      formData.question2,
      formData.question3
    ]
    const answers = [formData.answer1, formData.answer2, formData.answer3]
    for (const item of questions) {
      if (item.length < 4 || item.length > 20) {
        return true
      }
    }
    for (const item of answers) {
      if (item.length < 6 || item.length > 20) {
        return true
      }
    }
    return false
  }, [formData])

  const tipsText = useMemo(() => {
    const questions = [
      formData.question1,
      formData.question2,
      formData.question3
    ]
    for (const item of questions) {
      if (item.length < 4 || item.length > 20) {
        return '问题长度为4至20位，仅支持设置英文、中文或数字'
      }
    }
    return '答案长度为6至20位，包含英文、中文和数字任意类型'
  }, [formData])

  const handleSubmit = async () => {
    try {
      const data = await trigger({
        answer: {
          '1': formData.answer1,
          '2': formData.answer2,
          '3': formData.answer3
        },
        question: {
          '1': formData.question1,
          '2': formData.question2,
          '3': formData.question3
        }
      })
      props?.onSuccess?.(data?.twoStepCode)
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }

  return (
    <>
      <FormList
        className={styles.formList + ' ' + styles.formStep2}
        columns={columns}
        values={formData}
        onChange={(v) => {
          setFormData(v)
        }}
      />
      {btnButtonState && <div className={styles.errTip}>{tipsText}</div>}
      <div className={styles.questiontips}>
        密保问题作为核实您身份的重要依据，请尽量设置隐晦不易猜出
      </div>

      <div className={styles.addFooter}>
        <Button
          disabled={btnButtonState}
          onClick={handleSubmit}
          loading={isMutating}
          className={styles.addBtn}
          style={{ '--text-color': 'var(--adm-color-white)' }}
        >
          下一步
        </Button>
      </div>
    </>
  )
}

const Step1 = (props: any) => {
  const [formData, setFormData] = useState({
    payPassword: ''
  })
  const columns = [
    {
      domType: FormListItemType.password,
      prefix: '支付密码',
      prop: 'payPassword',
      placeHolder: '请输入6位支付密码'
    }
  ]

  const { trigger, isMutating } = useApiSecurityCheck()
  const btnButtonState = formData.payPassword.length !== 6

  const handleSubmit = async () => {
    try {
      await trigger({
        eyesType: 1,
        payPassword: md5Hash(formData.payPassword)
      })
      props?.onSuccess?.()
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }
  return (
    <>
      <FormList
        className={styles.formList}
        columns={columns}
        values={formData}
        onChange={(v) => {
          setFormData(v)
        }}
      />
      <div className={styles.addFooter}>
        <Button
          disabled={btnButtonState}
          loading={isMutating}
          onClick={handleSubmit}
          className={styles.addBtn}
          style={{ '--text-color': 'var(--adm-color-white)' }}
        >
          下一步
        </Button>
      </div>
    </>
  )
}

const SecurityQuestion = () => {
  const navigate = useNavigate()

  const [current, setCurrent] = useState(0)
  const [params, setParams] = useState<any>({})

  const location = useLocation()
  const { model, twoStepCode } = location.state || {}

  const [code, setCode] = useState(twoStepCode)

  const {
    data: config,
    randomKey,
    isValidating,
    error
  } = useGetBindSecurityQuestion(model === 1)

  return (
    <div>
      <HeaderUI
        title="设置安全密保"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <SkeletonUI isLoading={isValidating} error={error} data={[1]}>
        <div className={styles.stepsContent}>
          <Steps current={current}>
            <Step
              title="安全校验"
              className={current >= 0 ? styles.activityStep : ''}
              icon={
                <IconImage
                  className={styles.imageIcon}
                  imagePath={current >= 0 ? StepIconActivity : SetpIcon}
                />
              }
            />
            <Step
              title="设置新密保"
              className={current >= 1 ? styles.activityStep : ''}
              icon={
                <IconImage
                  className={styles.imageIcon}
                  imagePath={current >= 1 ? StepIconActivity : SetpIcon}
                />
              }
            />
            <Step
              title="确认密保"
              className={current >= 2 ? styles.activityStep : ''}
              icon={
                <IconImage
                  className={styles.imageIcon}
                  imagePath={current >= 2 ? StepIconActivity : SetpIcon}
                />
              }
            />
          </Steps>
        </div>

        <div className={styles.content}>
          {current === 0 && (
            <>
              {model === 1 ? (
                <ModifyStep1
                  params={config}
                  onSuccess={(v) => {
                    setCode(v)
                    setCurrent(1)
                  }}
                />
              ) : (
                <Step1 onSuccess={() => setCurrent(1)} />
              )}
            </>
          )}
          {current === 1 && (
            <Step2
              params={params}
              onSuccess={(v) => {
                setParams({ ...v })
                setCurrent(2)
              }}
            />
          )}
          {current === 2 && (
            <Step2
              onPrevious={() => setCurrent(1)}
              onSuccess={() => {
                randomKey()
              }}
              twoStepCode={code}
              secretType={model === 1 ? '1' : '0'}
              params={{
                question1: params.question1,
                question2: params.question2,
                question3: params.question3,

                pAnswer1: params.answer1,
                pAnswer2: params.answer2,
                pAnswer3: params.answer3
              }}
              readonly={true}
            />
          )}
        </div>
      </SkeletonUI>
    </div>
  )
}

export default SecurityQuestion
