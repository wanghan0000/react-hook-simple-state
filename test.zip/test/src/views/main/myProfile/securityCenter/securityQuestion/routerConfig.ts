export default {
    name: "securityQuestion",
    author: true,
    /**是否是根路由 */
    isRootRouter: true
};
  