import HeaderUI from '@/compoments/HeaderUI'
import IconImage from '@/compoments/IconImage'
import { Button, Input, List, Toast } from 'antd-mobile'
import React, { useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'
import OpenEyePng from '@/assets/common/openEye.png'
import HideEyePng from '@/assets/common/hideEye.png'
import { useUpdatePayPassword } from '../../api'
import { md5Hash } from '@/utils/md5'

const Modify = () => {
  const navigate = useNavigate()
  const [eyeSate, setEyeState] = useState({
    oldPassword: false,
    password: false,
    confirmPassword: false
  })

  const { trigger, isMutating } = useUpdatePayPassword()
  const [formData, setFormData] = useState({
    oldPassword: '',
    password: '',
    confirmPassword: ''
  })
  const clomuns = useMemo(
    () => [
      {
        title: '原密码',
        placeHolder: '请输入原密码',
        prop: 'oldPassword'
      },
      {
        title: '新密码',
        placeHolder: '请设置新密码',
        prop: 'password'
      },
      {
        title: '确认密码',
        placeHolder: '请再次输入密码',
        prop: 'confirmPassword'
      }
    ],
    []
  )

  const btnDisabled = useMemo(() => {
    if (
      !formData.oldPassword.length ||
      !formData.password.length ||
      !formData.confirmPassword.length
    ) {
      return true
    }
    return false
  }, [formData])

  const handleSubmit = async () => {
    if (formData.oldPassword.length !== 6) {
       Toast.show('原密码为6位数字或字母')
       return
    }
    if (formData.password.length !== 6) {
       Toast.show('新密码为6位数字或字母')
       return
    }
    if (formData.password !== formData.confirmPassword) {
       Toast.show('两次密码不一致')
       return
    }
    try {
      await trigger({
        password: md5Hash(formData.password),
        oldPassword: md5Hash(formData.oldPassword),
        confirmPassword: md5Hash(formData.confirmPassword)
      })
      Toast.show('操作成功')
      navigate(-1)
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }

  return (
    <div>
      <HeaderUI
        title="修改支付密码"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.main}>
        <List>
          {clomuns.map((v, index) => {
            return (
              <List.Item key={index} prefix={<div>{v.title}</div>}>
                <div className={styles.inputWarp}>
                  <Input
                    type={eyeSate[v.prop] ? 'text' : 'password'}
                    placeholder={v.placeHolder}
                    clearable
                    max={6}
                    maxLength={6}
                    value={formData[v.prop]}
                    onChange={(value) => {
                      setFormData({
                        ...formData,
                        [v.prop]: value
                      })
                    }}
                  />
                  <IconImage
                    onClick={() =>
                      setEyeState({
                        ...eyeSate,
                        [v.prop]: !eyeSate[v.prop]
                      })
                    }
                    imagePath={eyeSate[v.prop] ? OpenEyePng : HideEyePng}
                    className={styles.eyeImage}
                  />
                </div>
              </List.Item>
            )
          })}
        </List>

        <div className={styles.submitContent}>
          <Button
            onClick={handleSubmit}
            disabled={btnDisabled}
            loading={isMutating}
            className={styles.button}
          >
            确定
          </Button>
        </div>
      </div>
    </div>
  )
}

export default Modify
