export default {
    name: "modifyPayPass",
    author: true,
    path: '/main/myProfile/securityCenter/modifyPayPass/:type?',
    /**是否是根路由 */
    isRootRouter: true
};
  