import HeaderUI from '@/compoments/HeaderUI'
import IconImage from '@/compoments/IconImage'
import { Button, Input, List, Toast } from 'antd-mobile'
import React, { useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'
import OpenEyePng from '@/assets/common/openEye.png'
import HideEyePng from '@/assets/common/hideEye.png'
import {
  useCheckSecurity,
  useRechargePassword,
  useSetPassword
} from '../../api'
import { md5Hash } from '@/utils/md5'

const Set = (props: any) => {
  const { title = '设置支付密码', twoStepCode, model = '1' } = props || {}
  const navigate = useNavigate()
  const { isValidating, mutate } = useCheckSecurity()
  const [eyeSate, setEyeState] = useState({
    confirmPassword: false,
    password: false
  })
  const [formData, setFormData] = useState({
    confirmPassword: '',
    password: ''
  })
  const { trigger, isMutating } = useSetPassword()
  const { trigger: updateTrigger, isMutating: updateIsMutating } =
    useRechargePassword()

  const datas = [
    {
      title: '支付密码',
      placeHolder: '请输入支付密码(6位字母或数字)',
      prop: 'password'
    },
    {
      title: '确认密码',
      placeHolder: '请再次输入密码',
      prop: 'confirmPassword'
    }
  ]

  const btnDisabled = useMemo(() => {
    if (!formData.password.length || !formData.confirmPassword.length) {
      return true
    }
    return false
  }, [formData])

  const handleSubmit = async () => {
    const passwordLength = formData.password.length
    if (passwordLength !== 6) {
       Toast.show('支付密码，请输入6位字母或数字')
       return
    }
    if (formData.password !== formData.confirmPassword) {
       Toast.show('两次密码输入不一致')
       return
    }
    try {
      if (model === '1') {
        await trigger({
          confirmPassword: md5Hash(formData.confirmPassword),
          password: md5Hash(formData.password),
          twoStepCode: twoStepCode
        })
        await mutate()
      } else {
        await updateTrigger({
          confirmPassword: md5Hash(formData.confirmPassword),
          password: md5Hash(formData.password),
          twoStepCode: twoStepCode
        })
      }
      Toast.show('操作成功')
      navigate('/main/myProfile/securityCenter', {
        replace: true
      })
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }

  return (
    <div>
      <HeaderUI
        title={title}
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.main}>
        <List>
          {datas.map((v, index) => {
            return (
              <List.Item key={index} prefix={<div>{v.title}</div>}>
                <div className={styles.inputWarp}>
                  <Input
                    type={eyeSate[v.prop] ? 'text' : 'password'}
                    placeholder={v.placeHolder}
                    clearable
                    value={formData[v.prop]}
                    max={6}
                    onChange={(value) => {
                      setFormData({
                        ...formData,
                        [v.prop]: value
                      })
                    }}
                  />
                  <IconImage
                    onClick={() =>
                      setEyeState({
                        ...eyeSate,
                        [v.prop]: !eyeSate[v.prop]
                      })
                    }
                    imagePath={eyeSate[v.prop] ? OpenEyePng : HideEyePng}
                    className={styles.eyeImage}
                  />
                </div>
              </List.Item>
            )
          })}
        </List>

        <div className={styles.submitContent}>
          <Button
            onClick={handleSubmit}
            disabled={btnDisabled}
            loading={isMutating || isValidating}
            className={styles.button}
          >
            确定
          </Button>
        </div>
      </div>
    </div>
  )
}

export default Set
