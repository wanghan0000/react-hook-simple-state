import React from 'react'
import { useLocation, useParams } from 'react-router'
import Entry from './entry'
import Modify from './modify'
import Reset from './reset'
import Set from './set'

export const ModifyPayPass = () => {
  const { type } = useParams()
  const location = useLocation()
  const { payPassword , twoStepCode} = location.state || {}
  return (
    <>
      {payPassword === 1 ? (
        <div>
          {!type && <Entry />}
          {type === '1' && <Modify />}
          {type === '2' && <Reset />}
        </div>
      ) : (
        <div>
          <Set twoStepCode={twoStepCode}/>
        </div>
      )}
    </>
  )
}

export default ModifyPayPass
