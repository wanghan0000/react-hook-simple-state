import React, { useState } from 'react'
import { useNavigate } from 'react-router'
import Icon01 from '../../assets/icon01.png'
import serverPng from '@/assets/main/server.png'
import HeaderUI from '@/compoments/HeaderUI'
import { List } from 'antd-mobile'
import styles from './index.module.scss'
import EmailVerification from '@/compoments/emailVerification'
import { useCheckSecurity } from '../../api'

const Entry = () => {
  const navigate = useNavigate()
  const { data, isLoading, error } = useCheckSecurity()
  const [showPop, setShowPop] = useState({
    show: false,
    cate: '',
    type: '',
    tips: ''
  })
  const datas = [
    {
      imagePath: Icon01,
      title: '修改支付密码',
      onClick: () => {
        if (data?.emailWhite === 1) {
          navigate('/main/myProfile/securityCenter/modifyPayPass/1', {
            state: {
              payPassword: data?.payPassword
            }
          })
        } else {
          setShowPop({
            show: true,
            cate: '1',
            type: '1',
            tips: '修改支付密码需要先校验邮箱验证码'
          })
        }
      }
    },
    {
      imagePath: Icon01,
      title: '重置支付密码',
      onClick: () => {
        if (data?.emailWhite === 1) {
          navigate('/main/myProfile/securityCenter/modifyPayPass/2')
        } else {
          setShowPop({
            show: true,
            cate: '1',
            type: '1',
            tips: '重置支付密码需要先校验邮箱验证码'
          })
        }
      }
    }
  ]

  return (
    <div>
      <HeaderUI
        title="支付密码"
        showBack={true}
        onClickBack={() => navigate(-1)}
        rightNode={
          <img className={styles.server} src={serverPng} alt="server" />
        }
      />

      <div className={styles.main}>
        <List>
          {datas.map((v, index) => {
            return (
              <List.Item
                key={index}
                onClick={v?.onClick}
                prefix={
                  <img src={v.imagePath} className={styles.listIconImage}></img>
                }
                clickable
              >
                {v.title}
              </List.Item>
            )
          })}
        </List>
      </div>

      <EmailVerification
        visible={showPop.show}
        onClose={() => {
          setShowPop({
            ...showPop,
            show: false
          })
        }}
        onSussess={(twoStepCode: string) => {
          setShowPop({
            ...showPop,
            show: false
          })
          navigate('/main/myProfile/securityCenter/modifyPayPass/2', {
            state: {
              payPassword: data?.payPassword,
              twoStepCode: twoStepCode
            }
          })
        }}
        cate={showPop.cate}
        type={showPop.type}
        tips={showPop.tips}
      />
    </div>
  )
}

export default Entry
