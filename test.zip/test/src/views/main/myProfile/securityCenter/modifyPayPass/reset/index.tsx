import HeaderUI from '@/compoments/HeaderUI'
import React, { useEffect, useMemo, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import styles from './index.module.scss'
import { Button, Input, List, Toast } from 'antd-mobile'
import RefreshPng from '@/assets/common/refresh.png'
import {
  useCheckSecurity,
  useGetSecurityQuestion,
  useVerifySecurityLogin
} from '../../api'
import IconImage from '@/compoments/IconImage'
import SkeletonUI from '@/compoments/SkeletonUI'
import Set from '../set/index'
const Step1 = (props: any) => {
  const navigate = useNavigate()

  const { trigger, data, isMutating, error } = useGetSecurityQuestion()
  const { data: config } = useCheckSecurity()
  const { trigger: triggerSubmit, isMutating: submitMutating } =
    useVerifySecurityLogin()
  const [isLoading, setIsLoading] = useState(true)

  const [formData, setFormData] = useState({
    answer: '',
    googleCode: '',
    payPwd: ''
  })

  useEffect(() => {
    trigger({}).then(() => {
      setIsLoading(false)
    })
  }, [])

  const btnButtonState = useMemo(() => {
    if (!formData.answer.length) {
      return true
    }
    if (formData.googleCode.length !== 6 && config?.googleWhite !== 1) {
      return true
    }
    if (formData.payPwd.length !== 6 && config?.googleWhite === 1) {
      return true
    }
    return false
  }, [formData, config])

  const handleSubmit = async () => {
    try {
      await triggerSubmit({
        ...formData,
        question: data?.question
      })
      props.onSuccess?.()
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }

  return (
    <div>
      <HeaderUI
        title="安全校验"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <SkeletonUI block={3} data={data} isLoading={isLoading} error={error}>
        <div className={styles.main}>
          <List>
            <List.Item>
              <>
                <div className={styles.title}>
                  <div className={styles.titleText}>{data?.question}</div>
                  <div
                    className={styles.right}
                    onClick={() => {
                      if (isMutating) {
                        return
                      }
                      trigger({})
                    }}
                  >
                    <IconImage
                      imagePath={RefreshPng}
                      className={
                        styles.iamge +
                        ' ' +
                        (isMutating ? styles.loadingImage : '')
                      }
                    />
                    换一题
                  </div>
                </div>
                <div className={styles.input}>
                  <Input
                    placeholder="请输入密保答案"
                    value={formData.answer}
                    onChange={(v) => {
                      setFormData({
                        ...formData,
                        answer: v
                      })
                    }}
                  />
                </div>
              </>
            </List.Item>
            {config?.googleWhite !== 1 && (
              <List.Item>
                <>
                  <div className={styles.title}>
                    <div className={styles.titleText}>身份验证码</div>
                  </div>
                  <div className={styles.input}>
                    <Input
                      placeholder="请输入身份验证码"
                      value={formData.googleCode}
                      maxLength={6}
                      onChange={(v) => {
                        setFormData({
                          ...formData,
                          googleCode: v
                        })
                      }}
                    />
                  </div>
                </>
              </List.Item>
            )}
            {config?.googleWhite === 1 && (
              <List.Item>
                <>
                  <div className={styles.title}>
                    <div className={styles.titleText}>支付密码</div>
                  </div>
                  <div className={styles.input}>
                    <Input
                      placeholder="请输入支付密码"
                      value={formData.payPwd}
                      maxLength={6}
                      onChange={(v) => {
                        setFormData({
                          ...formData,
                          payPwd: v
                        })
                      }}
                    />
                  </div>
                </>
              </List.Item>
            )}
          </List>
        </div>

        <div className={styles.addFooter}>
          <Button
            disabled={btnButtonState}
            onClick={handleSubmit}
            loading={submitMutating}
            className={styles.addBtn}
            style={{ '--text-color': 'var(--adm-color-white)' }}
          >
            下一步，设置新支付密码
          </Button>
        </div>
      </SkeletonUI>
    </div>
  )
}
const Step2 = () => {
  const navigate = useNavigate()
  return (
    <div>
      <HeaderUI
        title="重置支付密码"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />
    </div>
  )
}

const Reset = () => {
  const [steps, setSteps] = useState(0)
  const location = useLocation()
  const { twoStepCode } = location.state || {}
  return (
    <div>
      {steps === 0 && (
        <Step1
          onSuccess={() => {
            setSteps(1)
          }}
        />
      )}
      {steps === 1 && <Set title={'重置支付密码'} twoStepCode={twoStepCode} />}
    </div>
  )
}

export default Reset
