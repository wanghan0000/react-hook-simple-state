import HeaderUI from '@/compoments/HeaderUI'
import IconImage from '@/compoments/IconImage'
import MaskContentPop from '@/compoments/maskContentPop'
import { Button, ImageViewer, Steps, Toast } from 'antd-mobile'
import { Step } from 'antd-mobile/es/components/steps/step'
import React, { useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import StepIconActivity from '../assets/stepIconActivity.png'
import SetpIcon from '../assets/stepIcon.png'
import AndroidIcon from '@/assets/common/androidIcon.png'
import IosIcon from '@/assets/common/iosIcon.png'
import QRCode from 'qrcode.react'
import AndroidBlackIcon from '@/assets/common/androidBlackIcon.png'
import IosBlackIcon from '@/assets/common/iosBlackIcon.png'
import CopyPng from '@/assets/common/copy.png'
import copy from 'copy-to-clipboard'
import ExampleImage from '@/assets/common/img_example.jpg'
import styles from './index.module.scss'
import { useBindGoogleAuth, useCheckSecurity, useGetGoogleAuth } from '../api'
import FormList, { FormListItemType } from '@/compoments/formList'

const configs = [
  '身份验证器是谷歌的一款动态口令工具，每隔30秒自动更新。在代理后台进行转账、提现、安全设置等敏感操作需要进行校验身份时，输入这6位身份验证码即可。',
  '身份验证器必须与代理账户配合使用。'
]

const iosAppLink =
  'https://apps.apple.com/cn/app/google-authenticator/id388497605'
const andriodAppLink =
  'https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2'

const Step3 = (props: any) => {
  const [formData, setFormData] = useState({
    code: ''
  })
  const { mutate } = useCheckSecurity()
  const { trigger, isMutating } = useBindGoogleAuth()
  const handlePrevious = () => {
    props.onPrevious?.()
  }

  const handleSubmit = async () => {
    try {
      await trigger({
        ...props.data,
        code: formData.code
      })
      Toast.show('操作成功')
      await mutate()
      props.onSuccess?.()
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }
  const columns = [
    {
      domType: FormListItemType.input,
      prefix: '身份验证码',
      prop: 'code',
      placeHolder: '请输入身份验证码'
    }
  ]

  const btnDisabled = useMemo(() => {
    if (formData.code.length !== 6) {
      return true
    }
    return false
  }, [formData])

  return (
    <div>
      <FormList
        className={styles.formList}
        columns={columns}
        values={formData}
        onChange={(v) => {
          setFormData(v)
        }}
      />
      <div className={styles.subFooterText}>
        <span>提示</span>
        <p>
          手机丢失或卸载身份验证后，密钥能够帮助您找回身份验证器，请妥善保管；
        </p>
        <p>为了您的账户安全，绑定时请勿标注代理账户及代理后台地址。</p>
      </div>

      <div className={styles.addFooter}>
        <Button
          loading={isMutating}
          onClick={handlePrevious}
          className={styles.previous}
        >
          {' '}
          上一步
        </Button>

        <Button
          onClick={handleSubmit}
          className={styles.addBtn}
          disabled={btnDisabled}
          loading={isMutating}
          style={{ '--text-color': 'var(--adm-color-white)' }}
        >
          立即绑定
        </Button>
      </div>
    </div>
  )
}

const Step2 = (props: any) => {
  const [visible, setVisible] = useState(false)

  const handlePrevious = () => {
    props.onPrevious?.()
  }

  const handleSubmit = () => {
    props.onSuccess?.()
  }
  return (
    <div>
      <div className={styles.subText}>
        <p> 1.扫描二维码，自动添加密钥</p>
      </div>
      <div className={styles.qrcodeCode}>
        <QRCode
          value={props?.data?.url}
          size={100}
          bgColor="#f0f0f0"
          fgColor="#333"
          level="H"
          includeMargin={false}
        />
      </div>
      <div className={styles.subText}>
        <p> 2.复制密钥，手动添加密钥</p>
      </div>
      <div className={styles.secretDiv}>
        <div>{props?.data?.secret}</div>
        <IconImage
          onClick={() => {
            copy(props?.data?.secret)
            Toast.show('复制成功')
          }}
          className={styles.imageIconCopy}
          imagePath={CopyPng}
        />
      </div>

      <div className={styles.subText}>
        <p> 3. 添加步骤</p>
      </div>

      <div className={styles.googleVerifTips}>
        <p>
          打开谷歌身份验证器，点击右上角（安卓为右下角）的 “+” ，选择
          “手动输入密钥”，填入任意账户和上述密钥绑定（扫描二维码可以自动添加）
        </p>
        <div className={styles.perviewImage} onClick={() => setVisible(true)}>
          查看示例图
        </div>
        <ImageViewer
          classNames={{
            mask: styles.maskImageView,
            body: styles.bodyImageView
          }}
          image={ExampleImage}
          visible={visible}
          onClose={() => {
            setVisible(false)
          }}
        />
        <div className={styles.subFooterText}>
          <span>提示</span>
          <p>
            手机丢失或卸载身份验证后，密钥能够帮助您找回身份验证器，请妥善保管；
          </p>
          <p>为了您的账户安全，绑定时请勿标注代理账户及代理后台地址。</p>
        </div>
      </div>

      <div className={styles.addFooter}>
        <Button onClick={handlePrevious} className={styles.previous}>
          {' '}
          上一步
        </Button>

        <Button
          onClick={handleSubmit}
          className={styles.addBtn}
          style={{ '--text-color': 'var(--adm-color-white)' }}
        >
          下一步
        </Button>
      </div>
    </div>
  )
}

const Step1 = (props: any) => {
  const { trigger, isMutating } = useGetGoogleAuth()

  const handleSubmit = async () => {
    try {
      const data = await trigger({})
      props.onSuccess?.(data)
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }
  return (
    <div>
      <div className={styles.subText}>
        <p> 1. 通过下述地址下载</p>
      </div>
      <div className={styles.downloadBtns}>
        <Button
          className={styles.downloadBtn}
          onClick={() => {
            window.open(iosAppLink, '_blank')
          }}
        >
          <IconImage className={styles.imageIcons} imagePath={IosIcon} />
          iOS下载
        </Button>
        <Button
          className={styles.downloadBtn}
          onClick={() => {
            window.open(andriodAppLink, '_blank')
          }}
        >
          <IconImage className={styles.imageIcons} imagePath={AndroidIcon} />
          Android下载
        </Button>
      </div>
      <div className={styles.subText}>
        <p> 1. 通过扫描二维码进行下载</p>
      </div>
      <div className={styles.qrcodes}>
        <div>
          <QRCode
            value={iosAppLink}
            size={120}
            bgColor="#f0f0f0"
            fgColor="#333"
            level="H"
            includeMargin={false}
          />
          <div className={styles.qrcodeDesc}>
            <IconImage className={styles.imageIcons} imagePath={IosBlackIcon} />
            iOS下载
          </div>
        </div>
        <div>
          <QRCode
            value={andriodAppLink}
            size={120}
            bgColor="#f0f0f0"
            fgColor="#333"
            level="H"
            includeMargin={false}
          />
          <div className={styles.qrcodeDesc}>
            <IconImage
              className={styles.imageIcons}
              imagePath={AndroidBlackIcon}
            />
            Android下载
          </div>
        </div>
      </div>
      <div className={styles.subFooterText}>
        <span>提示</span>
        <p>
          若无法下载，您可以在苹果商店搜索“Google
          Authenticator”，或安卓应用商店搜索“Google 身份验证器”下载安装；
        </p>
        <p>若已下载安装，点击“下一步”继续即可。</p>
      </div>

      <div className={styles.addFooter}>
        <Button
          onClick={handleSubmit}
          className={styles.addBtn}
          loading={isMutating}
          style={{ '--text-color': 'var(--adm-color-white)' }}
        >
          下一步
        </Button>
      </div>
    </div>
  )
}

const GoogleVerifyCode = () => {
  const navigate = useNavigate()
  const [visible, setVisible] = useState(true)
  const [current, setCurrent] = useState(0)
  const [data, setData] = useState<any>({})
  return (
    <div>
      <HeaderUI
        title="绑定谷歌验证"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.stepsContent}>
        <Steps current={current}>
          <Step
            title="下载安装"
            className={current >= 0 ? styles.activityStep : ''}
            icon={
              <IconImage
                className={styles.imageIcon}
                imagePath={current >= 0 ? StepIconActivity : SetpIcon}
              />
            }
          />
          <Step
            title="添加密钥"
            className={current >= 1 ? styles.activityStep : ''}
            icon={
              <IconImage
                className={styles.imageIcon}
                imagePath={current >= 1 ? StepIconActivity : SetpIcon}
              />
            }
          />
          <Step
            title="绑定验证"
            className={current >= 2 ? styles.activityStep : ''}
            icon={
              <IconImage
                className={styles.imageIcon}
                imagePath={current >= 2 ? StepIconActivity : SetpIcon}
              />
            }
          />
        </Steps>
      </div>

      <div className={styles.content}>
        {current === 0 && (
          <Step1
            onSuccess={(data: any) => {
              setData(data)
              setCurrent(1)
            }}
          />
        )}
        {current === 1 && (
          <Step2
            onSuccess={() => setCurrent(2)}
            onPrevious={() => setCurrent(0)}
            data={data}
          />
        )}
        {current === 2 && (
          <Step3
            onPrevious={() => setCurrent(1)}
            data={data}
            onSuccess={() => {
              navigate('/main/myProfile/securityCenter', {
                replace: true
              })
            }}
          />
        )}
      </div>

      <MaskContentPop
        visible={visible}
        onMaskClick={() => setVisible(false)}
        title={'身份验证器'}
        onClickConfirm={() => setVisible(false)}
        configs={configs}
        showIndex={false}
      />
    </div>
  )
}

export default GoogleVerifyCode
