import HeaderUI from '@/compoments/HeaderUI'
import IconImage from '@/compoments/IconImage'
import SkeletonUI from '@/compoments/SkeletonUI'
import RefreshPng from '@/assets/common/refresh.png'
import { Button, Input, List, Toast } from 'antd-mobile'
import React, { useEffect, useMemo, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import styles from './index.module.scss'
import { useGetSecurityQuestion, useVerifySecurityLogin } from '../api'
import { md5Hash } from '@/utils/md5'

const GoogleVerify = () => {
  const navigate = useNavigate()
  const { trigger, data, isMutating, error } = useGetSecurityQuestion()

  const location = useLocation()

  const { trigger: triggerSubmit, isMutating: submitMutating } =
    useVerifySecurityLogin()

  const [isLoading, setIsLoading] = useState(true)

  const [formData, setFormData] = useState({
    answer: '',
    payPwd: ''
  })

  useEffect(() => {
    trigger({}).then(() => {
      setIsLoading(false)
    })
  }, [])

  const btnButtonState = useMemo(() => {
    if (!formData.answer.length || !formData.payPwd.length) {
        return true
    }
    return false
  }, [formData])

  const handleSubmit = async () => {
    try {
      await triggerSubmit({
        answer: formData.answer,
        payPwd: md5Hash(formData.payPwd),
        question: data.question,
        twoStepCode: location.state?.twoStepCode
      })
      navigate('/main/myProfile/securityCenter/googleVerifyCode')
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }

  return (
    <div>
      <HeaderUI
        title="安全校验"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <SkeletonUI block={3} data={data} isLoading={isLoading} error={error}>
        <div className={styles.main}>
          <List>
            <List.Item>
              <>
                <div className={styles.title}>
                  <div className={styles.titleText}>{data?.question}</div>
                  <div
                    className={styles.right}
                    onClick={() => {
                      if (isMutating) {
                        return
                      }
                      trigger({})
                    }}
                  >
                    <IconImage
                      imagePath={RefreshPng}
                      className={
                        styles.iamge +
                        ' ' +
                        (isMutating ? styles.loadingImage : '')
                      }
                    />
                    换一题
                  </div>
                </div>
                <div className={styles.input}>
                  <Input
                    onChange={(v) => {
                      setFormData({
                        ...formData,
                        answer: v
                      })
                    }}
                    value={formData.answer}
                    placeholder="请输入密保答案"
                  />
                </div>
              </>
            </List.Item>
            <List.Item>
              <>
                <div className={styles.title}>
                  <div className={styles.titleText}>支付密码</div>
                </div>
                <div className={styles.input}>
                  <Input
                    onChange={(v) => {
                      setFormData({
                        ...formData,
                        payPwd: v
                      })
                    }}
                    value={formData.payPwd}
                    type="password"
                    placeholder="请输入支付密码"
                  />
                </div>
              </>
            </List.Item>
          </List>
        </div>

        <div className={styles.addFooter}>
          <Button
            disabled={btnButtonState}
            onClick={handleSubmit}
            loading={submitMutating}
            className={styles.addBtn}
            style={{ '--text-color': 'var(--adm-color-white)' }}
          >
            验证
          </Button>
        </div>
      </SkeletonUI>
    </div>
  )
}

export default GoogleVerify
