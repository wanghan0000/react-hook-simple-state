export default {
    name: "googleVerify",
    author: true,
    /**是否是根路由 */
    isRootRouter: true
};
  