import HeaderUI from '@/compoments/HeaderUI'
import FormList, { FormListItemType } from '@/compoments/formList'
import React, { useMemo, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import styles from './index.module.scss'
import { Button, Toast } from 'antd-mobile'
import { useEmailModify } from '../api'
import EmailSelect from '@/views/login/compoments/emailSelect'
import { useApiSendCode } from '@/compoments/emailVerification/api'
import useSmsCountDown from '@/commonHooks/useSmsCountDown'
import { useAgentInfo } from '@/commonApi'

const ModifyEmail = () => {
  const location = useLocation()
  const navigate = useNavigate()
  const { data } = useAgentInfo()
  const { isMutating: emailMutating, trigger: triggerEmail } = useApiSendCode()
  const { isMutating, trigger } = useEmailModify()
  const emailOptions = ['@gmail.com', '@outlook.com']
  const [showPop, setShowPop] = useState(false)
  const { secounds, start } = useSmsCountDown('emailVerification')
  const [formData, setFormData] = useState({
    code: '',
    email: '',
    suffix: emailOptions[1]
  })

  const handleSendEmailCode = () => {
    if (secounds || emailMutating) {
      return
    }
    triggerEmail({
      address: formData.email + formData.suffix,
      cate: '1',
      sendName: data.name,
      type: '1',
      version: process.env.REACT_API_VERSION
    })
      .then(() => {
        start()
      })
      .catch((error) => {
        Toast.show(error?.message || JSON.stringify(error))
      })
  }

  const columns = useMemo(() => {
    return [
      {
        domType: FormListItemType.input,
        prefix: '新邮箱地址',
        prop: 'email',
        placeHolder: '请输入邮箱',
        inputSuffix: (
          <div
            onClick={async () => {
              setShowPop(true)
            }}
            className={styles.inputSuffix}
          >
            <span>
              {formData.suffix}
              <em className={styles.emailArrow}>▼</em>
            </span>
          </div>
        )
      },
      {
        domType: FormListItemType.input,
        prefix: '验证码',
        prop: 'code',
        placeHolder: '请输入验证码',
        inputSuffix: (
          <div onClick={handleSendEmailCode} className={styles.btnSendCode}>
            {emailMutating && <span className={styles.loader}></span>}
            <span
              className={
                styles.codeText +
                ' ' +
                (!formData?.email?.length || isMutating || secounds
                  ? styles.disabledText
                  : '')
              }
            >
              {!!secounds ? `${secounds}s 后获取验证码` : '获取验证码'}
            </span>
          </div>
        )
      }
    ]
  }, [formData,secounds,isMutating,emailMutating])

  const handleSubmit = () => {
    try {
      trigger({
        code: formData.code,
        email: formData.email + formData.suffix,
        twoStepCode: location?.state?.twoStepCode
      })
      Toast.show('修改成功')
      navigate('/main/myProfile/securityCenter', {
        replace: true
      })
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }

  const btnDisabled = useMemo(() => {
    if (!formData.email.length || !formData.code.length) {
      return true
    }
    return false
  }, [formData])

  return (
    <div>
      <HeaderUI
        title="修改邮箱"
        showBack={true}
        onClickBack={() => {
          navigate(-1)
        }}
      ></HeaderUI>

      <FormList
        className={styles.formList}
        columns={columns}
        values={formData}
        onChange={(v) => {
          setFormData(v)
        }}
      />

      <div className={styles.submitContent}>
        <Button
          onClick={handleSubmit}
          disabled={btnDisabled}
          loading={isMutating}
          className={styles.button}
        >
          确定
        </Button>
      </div>

      <EmailSelect
        onClose={() => setShowPop(false)}
        visible={showPop}
        emails={emailOptions}
        value={formData.suffix}
        onChange={(v) => {
          setFormData({
            ...formData,
            suffix: v
          })
        }}
      />
    </div>
  )
}

export default ModifyEmail
