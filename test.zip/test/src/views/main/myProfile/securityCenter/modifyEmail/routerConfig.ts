export default {
    name: "modifyEmail",
    author: true,
    /**是否是根路由 */
    isRootRouter: true
};
  