import HeaderUI from '@/compoments/HeaderUI'
import { Button, Input, List, Toast } from 'antd-mobile'
import React, { useMemo, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import IconImage from '@/compoments/IconImage'
import OpenEyePng from '@/assets/common/openEye.png'
import HideEyePng from '@/assets/common/hideEye.png'
import { useUpdateLoginPassword } from '../api'
import { md5Hash } from '@/utils/md5'
import { useAuth } from '@/compoments/AuthProvider'
import styles from './index.module.scss'

export const ModifyLoginPass = () => {
  const navigate = useNavigate()
  const [eyeSate, setEyeState] = useState(false)
  const { logout } = useAuth()
  const { trigger, isMutating } = useUpdateLoginPassword()
  const location = useLocation()
  const [formData, setFormData] = useState({
    confirmPassword: '',
    oldPassword: '',
    secondPassword: ''
  })

  const datas = useMemo(
    () => [
      {
        title: '原密码',
        placeHolder: '请输入原密码',
        prop: 'oldPassword'
      },
      {
        title: '新密码',
        placeHolder: '请设置新密码',
        prop: 'secondPassword'
      },
      {
        title: '确认密码',
        placeHolder: '请再次输入密码',
        prop: 'confirmPassword'
      }
    ],
    []
  )

  const btnDisabled = useMemo(() => {
    if (
      !formData.oldPassword.length ||
      !formData.secondPassword.length ||
      !formData.confirmPassword.length
    ) {
      return true
    }
    return false
  }, [formData])
  function containsTwoLetters(str: any, count: any) {
    // 使用正则表达式匹配字母，并计算匹配到的数量
    const letterCount = (str.match(/[a-zA-Z]/g) || []).length
    // 如果字母数量大于等于2，则返回 true，否则返回 false
    return letterCount >= count
  }
  const handleSubmit = async () => {
    const oldLenght = formData.oldPassword.length
    const secondLength = formData.secondPassword.length
    if (oldLenght < 8) {
      Toast.show('原密码长度为8-12位')
      return
    }
    if (secondLength < 8 || !containsTwoLetters(formData.secondPassword, 1)) {
      Toast.show('代理密码长度为8-12位, 字母+数字的组合')
      return
    }
    if (formData.secondPassword !== formData.confirmPassword) {
      Toast.show('两次密码输入不一致')
      return
    }
    try {
      await trigger({
        confirmPassword: md5Hash(formData.confirmPassword),
        oldPassword: md5Hash(formData.oldPassword),
        secondPassword: md5Hash(formData.secondPassword),
        twoStepCode: location?.state?.twoStepCode
      })
      Toast.show('修改成功，请重新登录')
      logout()
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }

  return (
    <div>
      <HeaderUI
        title="修改登录密码"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.main}>
        <List>
          {datas.map((v, index) => {
            return (
              <List.Item key={index} prefix={<div>{v.title}</div>}>
                <div className={styles.inputWarp}>
                  <Input
                    type={eyeSate ? 'text' : 'password'}
                    placeholder={v.placeHolder}
                    clearable
                    value={formData[v.prop]}
                    maxLength={12}
                    max={12}
                    onChange={(value) => {
                      setFormData({
                        ...formData,
                        [v.prop]: value
                      })
                    }}
                  />
                  <IconImage
                    onClick={() => setEyeState(!eyeSate)}
                    imagePath={eyeSate ? OpenEyePng : HideEyePng}
                    className={styles.eyeImage}
                  />
                </div>
              </List.Item>
            )
          })}
        </List>

        <div className={styles.submitContent}>
          <Button
            onClick={handleSubmit}
            disabled={btnDisabled}
            loading={isMutating}
            className={styles.button}
          >
            确定
          </Button>
        </div>
      </div>
    </div>
  )
}

export default ModifyLoginPass
