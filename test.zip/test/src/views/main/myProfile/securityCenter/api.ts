import { apiFetcher, useSWRExpand } from '@/api/api'
import useSWRMutation from 'swr/mutation'

//更新密码
export const useUpdateLoginPassword = () => {
  const params = {
    path: '/member/modifyUserPass',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//设置密码
export const useSetPassword = () => {
  const params = {
    path: '/member/setPassword',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//更新支付密码
export const useUpdatePayPassword = () => {
  const params = {
    path: '/member/updatePassword',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//获取安全密保问题
export const useGetSecurityQuestion = () => {
  const params = {
    path: '/securityCenter/GetSecurityQuestionLogin',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//获取安全密保
export const useCheckSecurity = () => {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/securityCenter/CheckSecurity',
        type: 'post'
      },
      {}
    )
  }
  return useSWRExpand('useCheckSecurity', fetcherFuc, {
    dedupingInterval: 20 * 60 * 1000
  })
}

//绑定安全密保
export const useBindSecurityQuestion = () => {
  const params = {
    path: '/member/saveSecurityQuestion',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//校验密保
export const useCheckAgentSecurity = () => {
  const params = {
    path: '/member/checkAgentSecurity',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//获取密保问题
export const useGetBindSecurityQuestion = (revalidateOnMount: boolean) => {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/member/GetBindSecurityQuestion',
        type: 'post'
      },
      {}
    )
  }
  return useSWRExpand('useGetBindSecurityQuestion', fetcherFuc, {
    dedupingInterval: 20 * 60 * 1000,
    revalidateOnMount: revalidateOnMount
  })
}

//绑定邮箱安全校验
export const useVerifySecurityLogin = () => {
  const params = {
    path: '/securityCenter/verifySecurityLogin',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//获取Google验证码
export const useGetGoogleAuth = () => {
  const params = {
    path: '/securityCenter/GetGoogleAuth',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//绑定google验证器
export const useBindGoogleAuth = () => {
  const params = {
    path: '/securityCenter/bindGoogleAuth',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//修改支付密码
export const useRechargePassword = () => {
  const params = {
    path: '/member/rechargePassword',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//修改邮箱
export const useEmailModify = () => {
  const params = {
    path: '/member/modifyGMail',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}