export default {
    name: "securityCenter",
    author: true,
    /**是否是根路由 */
    isRootRouter: true
};
  