import HeaderUI from '@/compoments/HeaderUI'
import React, { useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import serverPng from '@/assets/main/server.png'
import { List, Toast } from 'antd-mobile'
import Icon01 from './assets/icon01.png'
import Icon02 from './assets/icon02.png'
import Icon03 from './assets/icon03.png'
import styles from './index.module.scss'
import SkeletonUI from '@/compoments/SkeletonUI'
import EmailVerification from '@/compoments/emailVerification'
import { useCheckSecurity } from './api'
const SecurityCenter = () => {
  const navigate = useNavigate()
  const { data: config, isLoading, error } = useCheckSecurity()
  const [showPop, setShowPop] = useState({
    show: false,
    cate: '',
    type: '',
    tips: '',
    prop: ''
  })
  const clomuns = useMemo(
    () => [
      {
        imagePath: Icon01,
        title: '登陆密码',
        text: '修改',
        onClick: () => {
          if (config.emailWhite === 1) {
            navigate('/main/myProfile/securityCenter/modifyLoginPass')
          } else {
            setShowPop({
              show: true,
              cate: '1',
              type: '1',
              tips: '修改支付密码需要先校验邮箱验证码',
              prop: 'modifyLoginPass'
            })
          }
        }
      },
      {
        imagePath: Icon01,
        title: '支付密码',
        text: config?.payPassword === 1 ? '已设置' : '未设置',
        onClick: () => {
          if (config?.payPassword === 1) {
            if (config?.secretSecurity === 0) {
              Toast.show('请先绑定密保')
              return
            }
            if (config?.googleAuth === 0) {
              Toast.show('请先绑定谷歌验证器')
              return
            }
          }
          if (config.emailWhite === 1) {
            navigate('/main/myProfile/securityCenter/modifyPayPass', {
              state: {
                payPassword: config?.payPassword
              }
            })
          } else {
            if (config?.payPassword !== 1) {
              setShowPop({
                show: true,
                cate: '1',
                type: '1',
                tips: '设置支付密码需要先校验邮箱验证码',
                prop: 'payPassword'
              })
            } else {
              navigate('/main/myProfile/securityCenter/modifyPayPass', {
                state: {
                  payPassword: config?.payPassword
                }
              })
            }
          }
        }
      },
      {
        imagePath: Icon02,
        title: '安全密保',
        text: config?.secretSecurity === 0 ? '未绑定' : '修改',
        onClick: () => {
          if (config?.payPassword === 0) {
            Toast.show('请先设置支付密码')
            return
          }
          if (config?.emailWhite === 1) {
            navigate('/main/myProfile/securityCenter/securityQuestion', {
              state: {
                model: config?.secretSecurity === 0 ? 0 : 1
              }
            })
          } else {
            setShowPop({
              show: true,
              cate: '1',
              type: '1',
              tips: '绑定安全密保需要先校验邮箱验证码',
              prop: 'secretSecurity'
            })
          }
        }
      },
      {
        imagePath: Icon03,
        title: '身份验证器',
        text: config?.googleAuth === 0 ? '未绑定' : '修改',
        show: config?.googleWhite !== 1,
        onClick: () => {
          if (config?.payPassword === 0) {
            return Toast.show('请先设置支付密码')
          }
          if (config?.secretSecurity === 0) {
            return Toast.show('请先设置安全密保')
          }
          if (config?.emailWhite === 1) {
            navigate('/main/myProfile/securityCenter/googleVerify')
          } else {
            setShowPop({
              show: true,
              cate: '1',
              type: '1',
              tips: '绑定安全密保需要先校验邮箱验证码',
              prop: 'googleAuth'
            })
          }
        }
      },
      {
        imagePath: Icon03,
        title: '代理邮箱',
        text: '修改',
        show: config?.emailWhite !== 1,
        onClick: () => {
          if (config?.emailWhite === 1) {
            navigate('/main/myProfile/securityCenter/modifyEmail')
          } else {
            setShowPop({
              show: true,
              cate: '1',
              type: '1',
              tips: '修改邮箱需要先校验原邮箱验证码',
              prop: 'modifyEmail'
            })
          }
        }
      }
    ],
    [config]
  )

  return (
    <div>
      <HeaderUI
        title="安全中心"
        showBack={true}
        onClickBack={() => navigate('/main/myProfile')}
        rightNode={
          <img
            onClick={() => navigate('/online')}
            className={styles.server}
            src={serverPng}
            alt="server"
          />
        }
      />

      <SkeletonUI isLoading={isLoading} error={error} data={config} block={3}>
        <div className={styles.main}>
          <List>
            {clomuns.map((v, index) => {
              const { show = true } = v
              return show ? (
                <List.Item
                  key={index}
                  onClick={v.onClick}
                  prefix={
                    <img
                      src={v.imagePath}
                      className={styles.listIconImage}
                    ></img>
                  }
                  clickable
                  extra={<div>{v.text}</div>}
                >
                  {v.title}
                </List.Item>
              ) : (
                <></>
              )
            })}
          </List>
        </div>

        <p className={styles.tips}>
          为了您的账户安全，完善以上安全信息才可以提取资金
        </p>
      </SkeletonUI>

      <EmailVerification
        visible={showPop.show}
        onClose={() => {
          setShowPop({
            ...showPop,
            show: false
          })
        }}
        onSussess={(twoStepCode: any) => {
          setShowPop({
            ...showPop,
            show: false
          })
          if (showPop.prop === 'modifyLoginPass') {
            navigate('/main/myProfile/securityCenter/modifyLoginPass', {
              state: {
                twoStepCode: twoStepCode
              }
            })
          } else if (showPop.prop === 'payPassword') {
            navigate('/main/myProfile/securityCenter/modifyPayPass', {
              state: {
                payPassword: config?.payPassword,
                twoStepCode: twoStepCode
              }
            })
          } else if (showPop.prop === 'secretSecurity') {
            navigate('/main/myProfile/securityCenter/securityQuestion', {
              state: {
                twoStepCode: twoStepCode,
                model: config?.secretSecurity === 0 ? 0 : 1
              }
            })
          } else if (showPop.prop === 'googleAuth') {
            navigate('/main/myProfile/securityCenter/googleVerify', {
              state: {
                twoStepCode: twoStepCode
              }
            })
          } else if (showPop.prop === 'modifyEmail') {
            navigate('/main/myProfile/securityCenter/modifyEmail', {
              state: {
                twoStepCode: twoStepCode
              }
            })
          }
        }}
        cate={showPop.cate}
        type={showPop.type}
        tips={showPop.tips}
      />
    </div>
  )
}

export default SecurityCenter
