import { apiFetcher, useSWRExpand } from '@/api/api'
import { usePagePlus } from '@/commonHooks/usePagePlus'
import useSWRMutation from 'swr/mutation'

//获取通知数量
export const useGetUnreadForType = () => {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/front/msg/getUnreadForType',
        type: 'post'
      },
      {
        arg: { userSystem: '2' }
      }
    )
  }
  return useSWRExpand('useGetUnreadForType', fetcherFuc, {
    dedupingInterval: 10 * 1000
  })
}

//获取消息数量
export const useGetMsgList = (params) => {
  return usePagePlus({
    catchKey: 'useGetMsgList',
    apiPath: '/front/msg/msgList',
    formData: params,
    dedupingInterval: 1000
  })
}

//获取公告数量
export const useGetBulletinCount = (params) => {
  return usePagePlus({
    catchKey: 'useGetBulletList',
    apiPath: '/front/msg/querySystemNoticeList',
    formData: params
  })
}

//阅读
export const useReadDetails = () => {
  const params = {
    path: '/front/msg/read',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//批量删除
export const useBatchDelete = () => {
  const params = {
    path: '/front/msg/delete',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}