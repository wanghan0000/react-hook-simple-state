export default {
    name: "myProfile",
    author: true
};
  