import { Dialog, Input, Toast } from 'antd-mobile'
import React, { useState } from 'react'
import styles from './index.module.scss'
import { useUpdateAgentConfig } from './api'

interface FlygramProps {
  visible: boolean
  onClose: () => void
  onSussess: (v:any) => void
  model: number
}

const Flygram = (props: FlygramProps) => {
  const { trigger } = useUpdateAgentConfig()
  const [value, setValue] = useState('')
  return (
    <Dialog
      visible={props.visible}
      onClose={() => {
        props?.onClose?.()
      }}
      closeOnAction={true}
      closeOnMaskClick={false}
      bodyClassName={styles.flygramDialog}
      title={props.model === 0 ? '绑定优信' : '编辑优信'}
      actions={[
        [
          {
            key: 'cancel',
            text: '取消',
            onClick: () => {}
          },
          {
            key: 'confirm',
            text: '确定',
            onClick: async () => {
              try {
                await trigger({
                  flygram: value,
                  flygramDisplay: 0,
                  updateType: 3
                })
                await props.onSussess?.(value)
              } catch (error: any) {
                Toast.show(error?.message)
              }
            }
          }
        ]
      ]}
      content={
        <div className={styles.checkModalForm}>
          <div className={styles.modalInput}>
            <div className={styles.customInputWarp}>
              <Input
                className={styles.inputLeft}
                placeholder="请输入优信"
                clearable
                type={'text'}
                value={value}
                onChange={(v) => setValue(v)}
              />
            </div>
          </div>
        </div>
      }
    />
  )
}

export default Flygram
