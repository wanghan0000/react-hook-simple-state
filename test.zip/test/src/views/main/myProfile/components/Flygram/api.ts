import { apiFetcher } from '@/api/api'
import useSWRMutation from 'swr/mutation'

//代理代存
export const useUpdateAgentConfig = () => {
    const params = {
      path: '/member/updateAgentConfig',
      type: 'post'
    }
    return useSWRMutation(params, (params, arg: { arg: any }) => {
      return apiFetcher<any>(params, { ...arg })
    })
  }