import { FormDomTypes } from '@/compoments/formFilter/interface'
import { getMonth } from '@/utils/date'
import React, { useMemo, useState } from 'react'
import { useApiGetAllGroup, useTeamCommission } from '../api'
import FormFilter from '@/compoments/formFilter'
import LoadMoreList from '@/compoments/loadMoreList'
import DescriptionCard from '@/compoments/descriptionCard'
import { useGetAgentDepositConfig } from '../../members/api'
import styles from './index.module.scss'

const TeamItem = (props) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [
          { title: '首存人数', text: `${props.firstPayCount}` },
          {
            title: '活跃人数',
            text: `${props.active}`,
            titleWidth: '50px',
            textWidth: '60px'
          }
        ]
      },
      {
        group: [
          { title: '补单输赢', text: `${props.repairNetProfit}` },
          {
            title: '净输赢',
            text: `${props.netProfit}`,
            titleWidth: '40px',
            textWidth: '62px'
          }
        ]
      },
      {
        group: [
          { title: '新注册', text: `${props.registerCount}` },
          {
            title: '上月结余',
            text: `${props.lastBalance}`,
            titleWidth: '40px',
            textWidth: '64px'
          }
        ]
      },
      {
        group: [{ title: '冲正后净输赢', text: `${props.czProfit}` }]
      }
    ],
    [props]
  )
  return (
    <DescriptionCard
      topNode={
        <div className={styles.descriptionCardTop}>
          <span className={styles.cardItemLeft}>
            <p>代理账号：</p>
            <p>{props.agentName}</p>
            {props.isCaptain === 1 && (
              <svg
                className={styles.firstIcon}
                viewBox="64 64 896 896"
                focusable="false"
                data-icon="flag"
                width="1em"
                height="1em"
                fill="rgba(156,165,255,1)"
                aria-hidden="true"
              >
                <path d="M880 305H624V192c0-17.7-14.3-32-32-32H184v-40c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8 8v784c0 4.4 3.6 8 8 8h56c4.4 0 8-3.6 8-8V640h248v113c0 17.7 14.3 32 32 32h416c17.7 0 32-14.3 32-32V337c0-17.7-14.3-32-32-32z"></path>
              </svg>
            )}
          </span>
          <div className={styles.cardRight}>
            <p>下级人数：</p>
            <div>{props.subordinateUserCount}</div>
          </div>
        </div>
      }
      bodyColumns={bodyColumns}
    />
  )
}

const TeamOrGroup = () => {
  const [formData, setFormData] = useState<any>({
    groupName: -1,
    agentName: '',
    commissionDate: getMonth(-1).startOfMonth
  })
  const { data, isLoading } = useGetAgentDepositConfig()
  const { filter, pager, nextPage, reset, error } = useTeamCommission({
    ...formData,
    groupName: formData.groupName === -1 ? '' : formData.groupName
  })

  const { data: options } = useApiGetAllGroup()

  const optionsGroup = useMemo(() => {
    if (options) {
      const arr = [...options]
      arr.unshift({ value: -1, label: '全部' })
      return arr
    } else {
      return [{ value: -1, label: '全部' }]
    }
  }, [options])

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.search,
        placeHolder: '代理账号',
        prop: 'agentName',
        width: '130px'
      },
      {
        domType: FormDomTypes.select,
        placeHolder: '代理小组',
        prop: 'groupName',
        width: '130px',
        options: optionsGroup,
        isShow: data?.isTeamLeader === 1
      },

      {
        domType: FormDomTypes.date,
        prop: 'commissionDate',
        dateFormat: 'month'
      },
      {
        domType: FormDomTypes.none,
        isShow: data?.isTeamLeader === 0
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            groupName: -1,
            agentName: '',
            commissionDate: getMonth(-1).startOfMonth
          }
          setFormData({
            ...params
          })
          reset({
            ...params,
            groupName: params.groupName === -1 ? '' : params.groupName
          })
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({
            ...formData,
            groupName: formData.groupName === -1 ? '' : formData.groupName
          })
        }
      }
    ],
    [formData, optionsGroup, data]
  )

  async function loadMore() {
    await nextPage({
      ...formData
    })
  }

  return (
    <div>
      <div className={styles.formFilter}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>
      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <TeamItem {...item} />
          }}
          itemClassName={styles.teamInfoItem}
        />
      </div>
    </div>
  )
}

export default TeamOrGroup
