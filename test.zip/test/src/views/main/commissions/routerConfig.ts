export default {
    name: "commissions",
    author: true
};
  