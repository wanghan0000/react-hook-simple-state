import React, { useState } from 'react'
import HeaderUI from '@/compoments/HeaderUI'
import {  Modal } from 'antd-mobile'
import QuestionMark from '@/assets/main/questionMark.png'
import Report from './report'
import { useGetAgentDepositConfig } from '../members/api'
import TopTabs from './topTabs'
import TeamOrGroup from './teamOrGroup'
import styles from './index.module.scss'
import { useLocation } from 'react-router'
const Commissions = () => {
  const configs = [
    '1.系统每日凌晨更新一次报表数据',
    '2.报表中数据，总输赢、净输赢中正数表示代理方盈利，负数表示代理方亏损；',
    '3.佣金数据每天会进行更新，仅供参考，并不做实际佣金派发标准；团队合作模式下，佣金将由主线队长统一管理。'
  ]

  const location = useLocation()
  const [visible, setVisible] = useState(false)
  const [index, setIndex] = useState(location?.state?.tableIndex || '0')
  const { data, isLoading } = useGetAgentDepositConfig()

  return (
    <div>
      <Modal
        visible={visible}
        title="温馨提示"
        bodyClassName={styles.commissionsModal}
        content={
          <>
            <p>{configs[0]}</p>
            <p>{configs[1]}</p>
            <p>{configs[2]}</p>
          </>
        }
        closeOnAction
        onClose={() => {
          setVisible(false)
        }}
        actions={[
          {
            key: 'confirm',
            text: '我知道了'
          }
        ]}
      />

      <HeaderUI
        title="佣金"
        rightNode={
          <>
            <img
              onClick={() => setVisible(true)}
              className={styles.questionMark}
              src={QuestionMark}
              alt="question mark"
            />
          </>
        }
      />

      {(!!data?.isTeamLeader || !!data?.isGroupLeader) && (
        <TopTabs index={index} onChange={(v) => setIndex(v)} />
      )}

      {index === '0' && <Report />}
      {index === '1' && <TeamOrGroup />}
    </div>
  )
}
//
export default Commissions
