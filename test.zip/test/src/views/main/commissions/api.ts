import { apiFetcher, useSWRExpand } from '@/api/api'
import { usePagePlus } from '@/commonHooks/usePagePlus'

//获取月度佣金数据
export function useApiGetMonthData(commissionDate) {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/finance/excel/get',
        type: 'post'
      },
      {
        arg: {
          commissionDate: commissionDate
        }
      }
    )
  }
  return useSWRExpand('useApiGetMonthData' + commissionDate, fetcherFuc, {
    dedupingInterval: 1 * 60 * 1000
  })
}

/**获取团队佣金数据*/
export function useTeamCommission(params) {
  return usePagePlus({
    catchKey: 'useTeamCommission',
    apiPath: '/team/teamCommission',
    formData: params
  })
}

//获取小组数据 team/getAllGroup
export function useApiGetAllGroup() {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/team/getAllGroup',
        type: 'post'
      },
      {}
    ).then((data:any)=>{
       console.log('da',data)
       return data?.data?.map((v)=>{
        return {
          ...v,
          value: v.groupName,
          label: v.groupName
        }
       })
    })
  }
  return useSWRExpand('useApiGetAllGroup', fetcherFuc, {
    dedupingInterval: 1 * 60 * 1000
  })
}
