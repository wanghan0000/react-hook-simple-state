/*
 * @Author: Mark
 * @Date: 2024-05-25 20:37:16
 * @LastEditTime: 2024-05-29 13:56:05
 * @LastEditors: MarkMark
 * @Description: 佛祖保佑无bug
 * @FilePath: /agent_h5/src/views/main/commissions/report/details/api.ts
 */

import { apiFetcher, useSWRExpand } from "@/api/api"

/** 佣金报表-财务报表 统计 */
export function useFinanceExcelGet(params) {
    const fetcherFuc = () => {
      return apiFetcher(
        {
          path: '/finance/excel/get',
          type: 'post'
        },
        {
          arg: params
        }
      )
    }
    return useSWRExpand('useFinanceExcelGet' + JSON.stringify(params), fetcherFuc, {
      dedupingInterval: 30 * 1000
    })
  }

/**佣金报表，总输赢详情 缓存10秒*/
export function useFinanceExcelProfit(params) {
    const fetcherFuc = () => {
      return apiFetcher(
        {
          path: '/finance/excel/profit',
          type: 'post'
        },
        {
          arg: params
        }
      )
    }
    return useSWRExpand('useFinanceExcelProfit' + JSON.stringify(params), fetcherFuc, {
      dedupingInterval: 30 * 1000
    })
  }
  /**佣金报表，场馆费详情 缓存10秒*/
export function useFinanceExcelVenue(params) {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/finance/excel/venue',
        type: 'post'
      },
      {
        arg: params
      }
    )
  }
  return useSWRExpand('useFinanceExcelVenue' + JSON.stringify(params), fetcherFuc, {
    dedupingInterval: 30 * 1000
  })
}
  
/**佣金报表，红利情 缓存10秒*/
export function useFinanceExcelPromo(params) {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/finance/excel/promo',
        type: 'post'
      },
      {
        arg: params
      }
    )
  }
  return useSWRExpand('useFinanceExcelPromo' + JSON.stringify(params), fetcherFuc, {
    dedupingInterval: 30 * 1000
  })
}
  /**佣金报表，存款详情 缓存10秒*/
export function useFinanceExcelDeposit(params) {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/finance/excel/deposit',
        type: 'post'
      },
      {
        arg: params
      }
    )
  }
  return useSWRExpand('useFinanceExcelDeposit' + JSON.stringify(params), fetcherFuc, {
    dedupingInterval: 30 * 1000
  })
}