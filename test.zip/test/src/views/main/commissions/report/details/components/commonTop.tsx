import React from "react"
import { useFinanceExcelGet } from "../api"
import { getMonth } from "@/utils/date"
import Styles from './index.module.scss'
import { formatNumberWithCommas } from "@/utils"
import { useLocation } from "react-router-dom"
/*
 * @Author: Mark
 * @Date: 2024-05-25 21:15:58
 * @LastEditTime: 2024-05-28 19:51:46
 * @LastEditors: MarkMark
 * @Description: 佛祖保佑无bug
 * @FilePath: /agent_h5/src/views/main/commissions/report/details/components/commonTop.tsx
 */
const CommonTop =({titleName})=>{

    const {
        data: resData,
        mutate,
        isLoading,
        isValidating,
        error,
        randomKey
      } = useFinanceExcelGet({
        commissionDate:getMonth(-1).startOfMonth
      })
      let iValue=0
      if(titleName=='存款'){
        iValue=resData?.deposit
      }else  if(titleName=='场馆费'){
        iValue= resData?.thirdPartySpend
      }
    return(
        <div className={Styles.commonTopWrap }>
              <div className={Styles.commonTopWrap_left }>
                <p className={Styles.commonTopWrap_left_text }>{titleName}</p>
                <p className={Styles.commonTopWrap_left_value }>¥{formatNumberWithCommas(iValue)}</p>
              </div>
              <div className={Styles.commonTopWrap_right }>
                <p className={Styles.commonTopWrap_right_text }>查询月份</p>
                <p className={Styles.commonTopWrap_right_value }>{resData?.commissionDate}</p>
              </div>
        </div>
    )
}
export default CommonTop