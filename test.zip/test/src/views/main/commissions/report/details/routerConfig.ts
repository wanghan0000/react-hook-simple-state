/*
 * @Author: Mark
 * @Date: 2024-05-25 21:11:57
 * @LastEditTime: 2024-05-25 21:11:59
 * @LastEditors: MarkMark
 * @Description: 佛祖保佑无bug
 * @FilePath: /agent_h5/src/views/main/commissions/report/details/routerConfig.ts
 */
export default {
    name: "details",
    author: true
};
  