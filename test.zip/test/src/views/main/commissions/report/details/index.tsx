import React, { useEffect } from "react"
import { useFinanceExcelDeposit, useFinanceExcelProfit, useFinanceExcelPromo, useFinanceExcelVenue } from "./api"
import { getMonth, getStartAndEndOfMonth} from "@/utils/date"
import HeaderUI from "@/compoments/HeaderUI"
import { useLocation, useNavigate } from 'react-router'
import Styles from './index.module.scss'
import CommonTop from "./components/commonTop"
import CommonDetails from "./components/commonDetails"
/*
 * @Author: Mark
 * @Date: 2024-05-25 20:34:57
 * @LastEditTime: 2024-05-29 14:04:21
 * @LastEditors: MarkMark
 * @Description: 佛祖保佑无bug
 * @FilePath: /agent_h5/src/views/main/commissions/report/details/index.tsx
 */
const ReportsDetails=()=>{
    const navigate = useNavigate()
    const location = useLocation() 
    const {titleName}=location.state
console.log('details page=location==',location)
   //useFinanceExcelDeposit:useFinanceExcelProfit
   const columnsDeposit = [
    { id: 0, title: '支付方式' },
    { id: 1, title: '金额' }
  ]
  const columnsVenueProfit = [
    { id: 0, title: '场馆' },
    { id: 1, title: '总输赢' },
    { id: 2, title: '场馆费率' },
    { id: 3, title: '场馆费' },
    { id: 4, title: '流水' }
  ]
  const columnsVenueFee = [
    { id: 0, title: '场馆' },
    { id: 1, title: '总输赢' },
    { id: 2, title: '场馆费率' },
    { id: 3, title: '场馆费' }
  ]
  const columnsPromo = [
    { id: 0, title: '红利类型' },
    { id: 1, title: '金额' }
  ]
  
    let apiFetch,columns,params
    if( titleName=='总输赢'){
        columns=columnsVenueProfit
        apiFetch=useFinanceExcelProfit
        params={
            startDate: getStartAndEndOfMonth(-1).startOfMonth,
            endDate: getStartAndEndOfMonth(-1).endOfMonth
          }
      }else  if(titleName=='场馆费' ){
        columns=columnsVenueFee
        apiFetch=useFinanceExcelVenue
        params={
            startDate: getStartAndEndOfMonth(-1).startOfMonth,
            endDate: getStartAndEndOfMonth(-1).endOfMonth
          }
      }else  if(titleName=='红利'){
        columns=columnsPromo
        apiFetch=useFinanceExcelPromo
        params={
            startDate: getStartAndEndOfMonth(-1).startOfMonth,
            endDate: getStartAndEndOfMonth(-1).endOfMonth
          }
      }else if(titleName=='存款'){
        columns=columnsDeposit
        apiFetch=useFinanceExcelDeposit
        params={
            startDate: getMonth(-1).startOfMonth,
            endData: getMonth(-1).endOfMonth
          }
      } 
    return (
        <div className={Styles.reportDetailsWrap}>
        <HeaderUI
                title={titleName+'详情'}
                showBack={true}
                onClickBack={() => navigate(-1)}
            />
            <div className={Styles.reportDetailsWrap_main}>
            <CommonTop titleName={titleName}/>
            <CommonDetails titleName={titleName} columns={columns} apiFetch={apiFetch} params={params}/>
            </div>
        </div>
    )
}

export default ReportsDetails