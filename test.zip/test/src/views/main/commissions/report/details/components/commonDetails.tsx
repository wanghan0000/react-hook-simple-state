/*
 * @Author: Mark
 * @Date: 2024-05-25 21:33:05
 * @LastEditTime: 2024-05-29 15:17:12
 * @LastEditors: MarkMark
 * @Description: 佛祖保佑无bug
 * @FilePath: /agent_h5/src/views/main/commissions/report/details/components/commonDetails.tsx
 */
import React, { useEffect } from 'react'
import { useFinanceExcelDeposit } from '../api'
import { getMonth } from '@/utils/date'
import Styles from './index.module.scss'
import { List, PullToRefresh, SpinLoading } from 'antd-mobile'
import { sleep } from 'antd-mobile/es/utils/sleep'
import { formatNumberWithCommas } from '@/utils'
import { useNavigate } from 'react-router'
import SpinLoadingUI from '@/compoments/SpinLoadingUI'
import HelpUI from '@/compoments/HelpUI'
import NoDataUI from '@/compoments/NoDataUI'

const CommonDetails = ({ titleName, columns, apiFetch, params }) => {
  const {
    data: resData,
    mutate,
    isLoading,
    isValidating,
    error,
    randomKey
  } = apiFetch(params)
  return (
    <div className={Styles.commonDetailsWrap}>
      <header>月度明细</header>
      <div className={Styles.commonDetailsWrap_columnsHeader}>
        {columns?.map((item, index) => (
          <p key={index} style={{ width: item?.width }}>
            {item?.title}
          </p>
        ))}
      </div>
     { !isLoading &&
       <div className={Styles.commonDetailsWrap_content}>
       {resData?.data?.length > 0 ? (
         <PullToRefresh
           onRefresh={async () => {
             await sleep(1000)
             await mutate()
           }}
         >
           {resData?.data?.map((item, index) => (
             <div key={index}>
               {titleName == '存款' ? (
                 <div
                   key={item.category}
                   className={Styles.commonDetailsWrap_content_list}
                 >
                   <span>{item.category}</span>
                   <span>¥{formatNumberWithCommas(item.money)}</span>
                 </div>
               ) : titleName == '场馆费' || titleName == '总输赢' ? (
                 <div
                   key={item.venueId}
                   className={Styles.commonDetailsWrap_content_list}
                 >
                   <span>{item.venueName}</span>

                   <span>¥{formatNumberWithCommas(item.profit)}</span>
                   <span>{item.commissionRate}%</span>
                   <span>¥{formatNumberWithCommas(item.amount)}</span>
                   {titleName == '总输赢' && (
                     <span>{formatNumberWithCommas(item.betAmount)}</span>
                   )}
                 </div>
               ) : titleName == '红利' ? (
                 <div
                   key={item.category}
                   className={Styles.commonDetailsWrap_content_list}
                 >
                   <span>{item.category}</span>
                   <span>¥{formatNumberWithCommas(item.money)}</span>
                 </div>
               ) : (
                 ''
               )}
             </div>
           ))}
         </PullToRefresh>
       ) : (
         <NoDataUI />
       )}
     </div>
     }
      {isLoading ? <SpinLoadingUI /> : <HelpUI />}
    </div>
  )
}
export default CommonDetails
