import React, { useCallback, useState } from 'react'
import { getMonth, timestampToMonth } from '@/utils/date'
import { useApiGetMonthData } from '../api'
import { DatePicker } from 'antd-mobile'
import SkeletonUI from '@/compoments/SkeletonUI'
import questionInfo from '@/assets/main/questionInfo.png'
import calendarIcon from '@/assets/main/calendarIcon.png'
import downArrow from '@/assets/main/downArrow.png'
import commissionIcon from '@/assets/main/commissionIcon.png'
import activeMemberIcon from '@/assets/main/activeMemberIcon.png'
import avalidMemberIcon from '@/assets/main/avalidMemberIcon.png'
import styles from './index.module.scss'
import MaskContentPop from '@/compoments/maskContentPop'
import { RightOutline } from 'antd-mobile-icons'
import { useNavigate } from 'react-router'

interface resDataProps {
  label?: string;
  value?: string;
  linkUrl?:string 
}

const Report = () => {
  const navigate = useNavigate()
  const [commissionDate, setCommissionDate] = useState(
    getMonth(-1).startOfMonth
  )
  const { data, isLoading, error, isValidating } =
    useApiGetMonthData(commissionDate)


//     const configs = [
//   '由于下线会员上线注单存在获取延迟，该部分注单产生的输赢激励在【补单输赢】中，并将计入本月的净输赢中',
//   `统计佣金调整+补调金额的和值，佣金调整：0.00，补调金额：0.00`,
//   `VIP专享包含额外佣金和游戏彩金；额外佣金是满足当月条件的佣金*比例所得；游戏彩金是满足当月条件，且佣金为0时所得。`
// ]
  const [configs, setConfigs] = useState<string[]>([])
  const [showDate, setShowDate] = useState(false)
  const [visible, setVisible] = useState(false)

  const resData: resDataProps[] = [
    { label: '场馆费', value: data?.thirdPartySpend ,linkUrl:'/main/commissions/report/details'},
    { label: '红利', value: data?.promo ,linkUrl:'/main/commissions/report/details'},
    { label: '返水', value: data?.rebate },
    { label: '账户调整', value: data?.riskAdjust },
    { label: '上月结余', value: data?.balance },
    { label: '存提手续费', value: data?.fee },
    { label: '佣金调整', value: data?.correction },
    // { label: 'VIP专享', value: data?.vipSpecialCommission }, //choi说去掉VIP专享
    { label: '存款', value: data?.deposit ,linkUrl:'/main/commissions/report/details'},
    { label: '提款', value: data?.draw }
  ]

  const labelRenderer = useCallback((type: string, data: number) => {
    switch (type) {
      case 'year':
        return data + '年'
      case 'month':
        return data + '月'
      case 'day':
        return data + '日'
      case 'hour':
        return data + '时'
      case 'minute':
        return data + '分'
      case 'second':
        return data + '秒'
      default:
        return data
    }
  }, [])
  return (
    <div>
      <DatePicker
        title="时间选择"
        className={styles.datePicker}
        visible={showDate}
        onClose={() => {
          setShowDate(false)
        }}
        value={new Date(commissionDate)}
        min={new Date(getMonth(-1).startOfMonth)}
        max={new Date()}
        onConfirm={(val: any) => {
          const v = timestampToMonth(val)
          setCommissionDate(v)
        }}
        precision="month"
        renderLabel={labelRenderer}
      />
      <SkeletonUI isLoading={isLoading} error={error} data={data}>
        <div className={styles.commission_wrap}>
          <div className={styles.commission_title}>月度佣金数据</div>
          <div className={styles.commission_search}>
            {/*    commission_date */}
            <div
              className={styles.commission_date}
              onClick={() => {
                setShowDate(true)
              }}
            >
              <div className={styles.divImg}>
                <img src={calendarIcon} alt="" />
              </div>
              <span>{commissionDate}</span>
              <div className={styles.divImg}>
                <img src={downArrow} alt="" />
              </div>
            </div>
          </div>
          {/*    commission_contain */}
          <div className={styles.commission_contain}>
            <div className={styles.commission_contain_cont}>
              <div className={styles.left}>
                <div className={styles.left_top}>
                  <div className={styles.divImg}>
                    <img src={commissionIcon} alt="" />
                  </div>
                  <span>佣金</span>
                  <p> {data?.commissionStatus === 1 ? '已发放' : '未发放'} </p>
                  {/* <RightOutline /> */}
                </div>
                <p className={styles.left_bottom}>{data?.commission}</p>
              </div>
              <div className={styles.right}>
                <span>佣金比例</span>
                <p className={styles.left_bottom}>{data?.rate + '%'}</p>
              </div>
            </div>
            <div className={styles.commission_contain_box}>
              <div className={styles.box_first}>
                <div className={styles.box_first_top}> <span>总输赢</span> <RightOutline onClick={()=>{
                      navigate('/main/commissions/report/details',{state:{titleName:'总输赢'}})
                    }}/></div>
                <p className={styles.left_bottom}>{data?.profit}</p>
               
              </div>
              <div className={styles.box_second}>
                <span>净输赢</span>
                <p className={styles.left_bottom}>{data?.netProfit}</p>
              </div>
              <div className={styles.box_three}>
                <div>
                  <span>补单输赢</span>
                  <div className={styles.divImg} onClick={()=>{
                    setConfigs(['由于下线会员上线注单存在获取延迟，该部分注单产生的输赢激励在【补单输赢】中，并将计入本月的净输赢中'])
                    setVisible(true)
                  }}>
                    <img src={questionInfo} alt="" />
                  </div>
                </div>
                <p className={styles.left_bottom}>{data?.repairNetProfit}</p>
              </div>
            </div>
          </div>
          {/*    commission_member */}
          <div className={styles.commission_member}>
            <div className={styles.left}>
              <div className={styles.left_top}>
                  <div>
                  <div className={styles.divImg}>
                      <img src={activeMemberIcon} alt="" />
                  </div>
                  <span>活跃会员</span>
                  </div>
                  <RightOutline onClick={()=>{
                      navigate('/main/commissions/activeMembers')
                    }}/>
              </div>
              <p className={styles.left_bottom}>{data?.active}</p>
            </div>
            <div className={styles.right}>
              <div className={styles.right_top}>
              <div className={styles.divImg}>
                  <img src={avalidMemberIcon} alt="" />
                </div>
                <span>有效新增</span>
               
              </div>
              <p className={styles.right_bottom}>{data?.newActive}</p>
            </div>
          </div>
          {/*   commission_tabulation */}
          <div className={styles.commission_tabulation}>
            {resData?.map((item: resDataProps,i:number) => {
              return (
                <div
                  className={styles.commission_tabulation_item}
                  key={i}
                >
                  <div  className={styles.descInfo}>
                    <div className={styles.title}> 
                    {item.label}
                    {/* {( i==6 || i==7) &&  
                    <div  onClick={()=>{
                      let str=''
                      if(i ==6 ){ //choi说暂时没有补调金额，故注释
                        str=`统计佣金调整+补调金额的和值，佣金调整：0.00，补调金额：0.00`
                      }
                      if(i ==7 ){
                        str=`VIP专享包含额外佣金和游戏彩金；额外佣金是满足当月条件的佣金*比例所得；游戏彩金是满足当月条件，且佣金为0时所得。`
                      }
                      setConfigs([str])
                      setVisible(true)
                    }}>
                      <img src={questionInfo} alt="" />
                    </div>
                    } */}
                     </div>
                    <p className={styles.icon} onClick={()=>{
                      navigate(String(item?.linkUrl),{state:{titleName:item.label}})
                    }}> { (i <2 || i==7) && <RightOutline />}</p>
                  </div>
               
                  <p className={styles.text}>{item.value}</p>
                </div>
              )
            })}
          </div>
        </div>
      </SkeletonUI>

      <MaskContentPop
        visible={visible}
        onMaskClick={() => setVisible(false)}
        title={'温馨提示'}
        onClickConfirm={() => setVisible(false)}
        configs={configs}
        showIndex={false}
        textCenter={true}
      />
    </div>
  )
}

export default Report
