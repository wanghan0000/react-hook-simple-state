import { usePagePlus } from "@/commonHooks/usePagePlus"


export const useGetActiveList = (formData) => {
    return usePagePlus({
        catchKey: 'useGetActiveList',
        apiPath: '/member/activeList',
        formData: formData
    })
}