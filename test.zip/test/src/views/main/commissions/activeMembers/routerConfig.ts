export default {
    name: "activeMembers",
    author: true,
    isRootRouter: true
};
  