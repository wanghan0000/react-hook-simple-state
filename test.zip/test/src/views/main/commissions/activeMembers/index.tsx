import HeaderUI from '@/compoments/HeaderUI'
import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import QuestionMark from '@/assets/main/questionMark.png'
import MaskContentPop from '@/compoments/maskContentPop'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import { getCurrentDateString, getMonth } from '@/utils/date'
import FormFilter from '@/compoments/formFilter'
import { useGetActiveList } from './api'
import { Toast } from 'antd-mobile'
import LoadMoreList from '@/compoments/loadMoreList'
import DescriptionCard from '@/compoments/descriptionCard'
import styles from './index.module.scss'

const configs = [
  {
    title: '活跃会员',
    content: ['所选时间段内，存款金额>=100或有效投注>=500的下线会员']
  },
  {
    title: '有效新增',
    content: [
      '1）所选时间段内首存，累计存款金额≥500；',
      '2）所选时间段内首存，累计存款金额≥100且有效投注≥1000； 二者满足其一的下线会员'
    ]
  },
  {
    title: '有效活跃',
    content: ['所选时间段内，存款金额 >=500 或有效投注 >=1000 的下线会员']
  }
]
const dictCategory = [
  //{ value: -1, label: '全部' },
  { value: 1, label: '活跃会员' },
  { value: 2, label: '有效新增' },
  { value: 3, label: '首存会员' },
  { value: 4, label: '有效活跃' }
]

const ActiveMembersItem = (props: any) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [{ title: '上级代理', text: props?.topName || '--' }]
      },
      {
        group: [
            { title: '存款金额', text: Number(props.deposit || 0).toFixed(2) },
            { title: '投注金额', text: Number(props.allBets || 0).toFixed(2) }
        ]
      },
      {
        group: [{ title: '首存时间', text: props.firstDepositTime || '--' }]
      },
      {
        group: [{ title: '注册时间', text: props.registerTime || '--' }]
      }
    ],
    [props]
  )

  return (
    <DescriptionCard
      topNode={
        <div className={styles.descriptionCardTop}>
          <span className={styles.cardItemLeft}>
            <p>会员账号：</p>
            <p>{props.memberName}</p>
          </span>
          <div className={styles.cardStatus}>
            <i></i>
            <div>
              {props.activeType || '--'}
            </div>
          </div>
        </div>
      }
      bodyColumns={bodyColumns}
    />
  )
}

const ActiveMembers = () => {
  const navigate = useNavigate()
  const [visible, setVisible] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    date: getMonth(0).startOfMonth,
    activeType: 1,
    registerStartDate: '',
    registerEndDate: ''
  })

  const { filter, pager, nextPage, reset, error } = useGetActiveList({
    ...formData
  })

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.search,
        placeHolder: '会员账号',
        prop: 'name',
        width: '115px'
      },
      {
        domType: FormDomTypes.date,
        placeHolder: '选择时间',
        prop: 'date'
      },
      {
        domType: FormDomTypes.select,
        placeHolder: '请选择',
        options: dictCategory,
        prop: 'activeType',
        width: '114px',
        className: styles.typeSlect
      },
      {
        domType: FormDomTypes.dateRange,
        prop: ['registerStartDate', 'registerEndDate'],
        placeHolder: ['开始时间', '结束时间'],
        label: '注册时间'
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            name: '',
            date: getMonth(0).startOfMonth,
            activeType: 1,
            registerStartDate: '',
            registerEndDate: ''
          }
          setFormData(params)
          reset({
            ...params
          })
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({
            ...formData
          })
        }
      }
    ],
    [formData]
  )

  async function loadMore() {
    await nextPage({
      ...formData
    })
  }

  useEffect(() => {
    if (error) {
      Toast.show({
        content: error?.message
      })
      setFormData({
        ...formData,
        registerEndDate: ''
      })
    }
  }, [error])

  return (
    <div>
      <HeaderUI
        title="活跃会员"
        showBack={true}
        onClickBack={() => navigate(-1)}
        rightNode={
          <>
            <img
              onClick={() => setVisible(true)}
              className={styles.questionMark}
              src={QuestionMark}
              alt="question mark"
            />
          </>
        }
      />

      <div className={styles.formFilter}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>

      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <ActiveMembersItem {...item} />
          }}
          itemClassName={styles.activeMembersItem}
        />
      </div>

      <MaskContentPop
        visible={visible}
        onMaskClick={() => setVisible(false)}
        title={'温馨提示'}
        onClickConfirm={() => setVisible(false)}
        configs={configs}
        showIndex={false}
        textCenter={true}
        model={2}
      />
    </div>
  )
}

export default ActiveMembers
