import React, { useMemo } from 'react'
import styles from './index.module.scss'
import SvgProgress from '@/compoments/SvgProgress'
import { useGetFrontBanner } from '@/views/main/home/api'

const Overview = () => {
  const { data: banner } = useGetFrontBanner()

  const items = useMemo(()=>[
    {
      value: banner?.totalMembers ?? '--',
      label: '下级成员'
    },
    {
      value: banner?.registerMembers ?? '--',
      label: '本月新增'
    },
    {
      value: banner?.activeMembers ?? '--',
      label: '本月活跃成员'
    },
    {
      value: banner?.effectiveNew ?? '--',
      label: '本月有效活跃'
    }
  ],[banner])

  return (
    <div className={styles.overView}>
      <span>下级概览</span>
      <div className={styles.detail}>
        <div className={styles.main}>
          <div className={styles.itemContent}>
            {items?.map((v, index) => {
              return (
                <>
                  <div key={index}>
                    <span>{v.label}</span>
                    <span>{v.value}</span>
                  </div>
                  {index !== items.length - 1 && (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="1"
                      height="20"
                      viewBox="0 0 1 20"
                      fill="none"
                    >
                      <path
                        d="M0.5 0.25L0.499999 19.75"
                        stroke="#E3E4E6"
                        strokeWidth="0.5"
                        strokeLinecap="square"
                      ></path>
                    </svg>
                  )}
                </>
              )
            })}
          </div>

          <div className={styles.progress}>
            <div className={styles.progressDetail}>
              <SvgProgress percent={0} className={styles.svg} />
              <div className={styles.description}>
                <span>
                  00.00
                  <span className={styles.desSpan}>%</span>
                </span>
                <span>本月活跃占比</span>
              </div>
            </div>
            <div className={styles.progressDetail}>
              <SvgProgress percent={0.0} className={styles.svg} />
              <div className={styles.description}>
                <span>
                  0.00
                  <span className={styles.desSpan}>%</span>
                </span>
                <span>今日活跃占比</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
//
export default Overview
