import React, { useEffect, useMemo, useRef, useState } from 'react'
import IconImage from '@/compoments/IconImage'
import circleArrow from '@/assets/main/circleArrow.png'
import { getCurrentDateString, getStartAndEndOfMonth } from '@/utils/date'
import FormFilter from '@/compoments/formFilter'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import LoadMoreList from '@/compoments/loadMoreList'
import { useFilterMemberList } from '../../api'
import styles from './index.module.scss'
import { useNavigate } from 'react-router'
import { Toast } from 'antd-mobile'


const ListItem = (props: any) => {
  const navigate = useNavigate()

  const colorClass = Number(props.profit) > 0 ? styles.textGreen : ( Number(props.profit) < 0 ? styles.textRead : '')
  return (
    <div className={styles.userCard}>
      <div className={styles.userInfo}>
        <div className={styles.userDetail}>
          <div>
            <span>{props?.name || '--'}</span>
            <div className={styles.vipIcon}>V{props.vipGrade}</div>
          </div>
          <p>
            <span className={styles.inactive + ' ' +
          (props.realName ? styles.tagSuccess : '')
          }>{props.realName ? '已实名' : '未实名'}</span>
          </p>
        </div>

        <div className={styles.moneyDetail}>
          <div>
            <span>存款</span>
            <span>{props?.deposit}</span>
          </div>
          <div>
            <span>提款</span>
            <span>{props?.draw}</span>
          </div>
        </div>

        <div className={styles.profitDetail}>
          <span>总输赢</span>
          <span className={ colorClass }>¥{props.profit}</span>
        </div>
      </div>
      <div className={styles.cardBottom}>
        <div className={styles.dateTime}>
          <div className={styles.cardText}>
            <span>注册时间</span>
            <span>{props.registerDate || '--'}</span>
          </div>
          <IconImage onClick={()=> navigate('/main/members/detail',{
            state: {
              ...props
            }
          })} className={styles.cardArrowDown} imagePath={circleArrow} />
        </div>
      </div>
    </div>
  )
}

const MemberList = () => {
  const options1 = useRef([
    { value: -1, label: '全部' },
    { value: 1, label: '是' },
    { value: 0, label: '否' }
  ])
  const options2 = useRef([
    { value: -1, label: '全部' },
    { value: 1, label: '正常' },
    { value: 0, label: '禁用' }
  ])

  const [formData, setFormData] = useState({
    startDate: getStartAndEndOfMonth(0).startOfMonth,
    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
    isBet: -1,
    status: -1,
    name: ''
  })

  const { filter, pager, nextPage, reset, error } = useFilterMemberList({
    ...formData
  })


  async function loadMore() {
    await nextPage( {
      ...formData
    })
  }

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.radio,
        label: '是否投注',
        prop: 'isBet',
        options: options1.current
      },
      {
        domType: FormDomTypes.radio,
        label: '状态',
        prop: 'status',
        options: options2.current
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.search,
        placeHolder: '会员账号',
        prop: 'name',
        width: '115px'
      },
      {
        domType: FormDomTypes.dateRange,
        prop: ['startDate', 'endDate'],
        placeHolder: ['开始时间', '结束时间'],
        maxDate: new Date()
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            startDate: getStartAndEndOfMonth(0).startOfMonth,
            endDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
            isBet: -1,
            status: -1,
            name: ''
          }
          setFormData(params)
          reset(params)
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({
            ...formData
          })
        }
      }
    ],
    [formData]
  )

  useEffect(()=>{
    if(error) {
      Toast.show(error?.message)
      setFormData({
        ...formData,
        startDate: getStartAndEndOfMonth(0).startOfMonth,
        endDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
      })
    }
  },[error])

  return (
    <div className={styles.memberList}>
      <span>下级成员列表</span>
      <div className={styles.content}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />

        <div className={styles.list}>
          <LoadMoreList
            datas={pager?.list || []}
            loadMore={loadMore}
            hasMore={pager.hasMore}
            firstLoading={pager.isFirstLoading}
            render={(item, index) => {
              return <ListItem {...item} />
            }}
            itemClassName={styles.memerItem}
          />
        </div>
      </div>
    </div>
  )
}

export default MemberList