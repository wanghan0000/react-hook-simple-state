import HeaderUI from '@/compoments/HeaderUI'
import React, { useEffect, useMemo, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import QuestionMark from '@/assets/main/questionMark.png'
import RecordImage from '@/assets/common/agentDepositRecordIcon.png'
import styles from './index.module.scss'
import IconImage from '@/compoments/IconImage'
import MaskContentPop from '@/compoments/maskContentPop'
import FormList, { FormListItemType } from '@/compoments/formList'
import { Button, Toast } from 'antd-mobile'
import SecurityCheck from '@/compoments/securityCheck'
import {
  useAgentDrawMoney,
  useGetAgentDepositConfig,
  useGetDrawMoney
} from '../api'
import SkeletonUI from '@/compoments/SkeletonUI'
import { md5Hash } from '@/utils/md5'
import { useCheckSecurity } from '../../myProfile/securityCenter/api'

const AgentDeposit = () => {
  const navigate = useNavigate()
  const configs = [
    {
      title: '什么是代理代存',
      content: [
        '代理代存是一种新的存款方式，即代理可直接将指定金额存款到自身下级会员的中心钱包。此类代存可以参与网站优惠，并且计算首存和活跃。'
      ]
    },
    {
      title: '额度代存',
      content: [
        '将“可用额度”的余额为下级会员进行代存。有下述两种途径对“可用额度”充值：',
        '1）通过“额度充值”进行充值',
        '2）通过联系平台管理员进行申请充值'
      ]
    },
    {
      title: '佣金代存',
      content: ['将“可用佣金”的余额为下级会员进行代存。']
    }
  ]
  const location = useLocation()
  const locaData = location.state || {}
  const [visible, setVisible] = useState(false)
  const [showSecurity, setShowSecurity] = useState(false)
  const { trigger } = useGetDrawMoney()
  const { trigger: triggerSubmit, isMutating } = useAgentDrawMoney()
  const { data: depositConfig, isLoading, error } = useGetAgentDepositConfig()
  const { data: config } = useCheckSecurity()
  const [formData, setFormData] = useState({
    //0 佣金代存 1 额度代存
    proxyType: 1,
    disableAmount: '****',
    commissionAmount: '****',
    agentName: locaData?.name,
    amount: '',
    flowRatio: '1',
    validateType: 1,
    googleCode: '',
    payPassword: ''
  })

  useEffect(() => {
    if (config?.googleWhite === 1) {
      setFormData({
        ...formData,
        validateType: 2
      })
    }
  }, [config])

  const columns = useMemo(() => {
    const { min, max, agentTurnoverMax, agentTurnoverMin, todayDepositLimit } =
      depositConfig?.agentDepositSetting ?? {}

    let options = [
      { value: 1, label: '谷歌验证码' },
      { value: 2, label: '支付密码' }
    ]

    if (config?.googleWhite === 1) {
      options = [{ value: 2, label: '支付密码' }]
    }

    return [
      {
        domType: FormListItemType.select,
        prefix: '代存类型',
        prop: 'proxyType',
        options: [
          { value: 0, label: '佣金代存' },
          { value: 1, label: '额度代存' }
        ],
        className: 'select-content'
      },
      {
        domType:
          formData.disableAmount === '****'
            ? FormListItemType.password
            : FormListItemType.text,
        prefix: '可代存金额',
        prop: 'disableAmount',
        readonly: true,
        onClickEye: async () => {
          setShowSecurity(true)
        },
        show: formData.proxyType === 1,
        className: 'select-content'
      },
      {
        domType:
          formData.commissionAmount === '****'
            ? FormListItemType.password
            : FormListItemType.text,
        prefix: '可代存金额',
        prop: 'commissionAmount',
        readonly: true,
        onClickEye: async () => {
          setShowSecurity(true)
        },
        show: formData.proxyType === 0
      },
      {
        domType: FormListItemType.input,
        prefix: '下级账号',
        prop: 'agentName',
        placeHolder: '请输入下级账号'
      },
      {
        domType: FormListItemType.input,
        prefix: '代存金额',
        prop: 'amount',
        placeHolder: '请输入代存金额',
        inputMode: 'decimal',
        tips: `${min}≤单次代存金额≤${max}当日限额${todayDepositLimit}`
      },
      {
        domType: FormListItemType.input,
        prefix: '提款流水倍数',
        prop: 'flowRatio',
        inputMode: 'decimal',
        placeHolder: '请输入流水倍数',
        tips: `${agentTurnoverMin}≤提款流水倍数≤${agentTurnoverMax}`
      },
      {
        domType: FormListItemType.select,
        prefix: '验证方式',
        prop: 'validateType',
        options: options,
        className: 'select-content'
      },
      {
        domType: FormListItemType.input,
        prefix: '谷歌验证码',
        prop: 'googleCode',
        placeHolder: '请输入谷歌验证码',
        show: formData.validateType === 1
      },
      {
        domType: FormListItemType.input,
        prefix: '支付密码',
        prop: 'payPassword',
        placeHolder: '请输入支付密码',
        show: formData.validateType === 2
      }
    ]
  }, [formData, depositConfig, config])

  const buttonDisabled = useMemo(() => {
    if (isMutating) {
      return true
    }
    const { min, max, agentTurnoverMax, agentTurnoverMin } =
      depositConfig?.agentDepositSetting ?? {}
    const vAmount = Number(formData.amount)
    const vFlowRatio = Number(formData.flowRatio)
    if (vAmount < Number(min) || vAmount > Number(max)) {
      return true
    }
    if (
      vFlowRatio < Number(agentTurnoverMin) ||
      vFlowRatio > Number(agentTurnoverMax)
    ) {
      return true
    }
    if (!formData.agentName?.length) {
      return true
    }
    if (formData.validateType === 1 && !formData.googleCode?.length) {
      return true
    }
    if (formData.validateType === 2 && !formData.payPassword?.length) {
      return true
    }
    return false
  }, [formData, isMutating, depositConfig])

  const rules = useMemo(() => {
    const { min, max, agentTurnoverMax, agentTurnoverMin } =
      depositConfig?.agentDepositSetting ?? {}
    return {
      amount: {
        validate: (value) => {
          if (!value) {
            return true
          }
          const v = Number(value)
          if (v < Number(min) || v > Number(max)) {
            return false
          }
          return true
        }
      },
      flowRatio: {
        validate: (value) => {
          if (!value) {
            return true
          }
          const v = Number(value)
          if (v < Number(agentTurnoverMin) || v > Number(agentTurnoverMax)) {
            return false
          }
          return true
        }
      }
    }
  }, [depositConfig])

  const handleSubmit = async () => {
    try {
      await triggerSubmit({
        agentName: formData.agentName,
        amount: formData.amount,
        flowRatio: formData.flowRatio,
        googleCode: formData.validateType === 1 ? formData.googleCode : '',
        payPassword:
          formData.validateType === 2 ? md5Hash(formData.payPassword) : '',
        validateType: formData.validateType,
        proxyType: formData.proxyType
      })
      Toast.show('操作成功')

      setFormData({
        proxyType: 1,
        disableAmount: '****',
        commissionAmount: '****',
        agentName: locaData?.name,
        amount: '',
        flowRatio: '1',
        validateType: 1,
        googleCode: '',
        payPassword: ''
      })
    } catch (error: any) {
      Toast.show(error?.message)
    }
  }

  return (
    <div>
      <HeaderUI
        title="代理代存"
        showBack={true}
        onClickBack={() => navigate(-1)}
        rightNode={
          <div className={styles.headerRight}>
            <IconImage
              onClick={() => setVisible(true)}
              imagePath={QuestionMark}
              className={styles.questionMark}
            />

            <IconImage
              onClick={() => {
                navigate('/main/members/history')
              }}
              className={styles.recordImage}
              imagePath={RecordImage}
            />
          </div>
        }
      />

      <SkeletonUI
        data={depositConfig}
        isLoading={isLoading}
        error={error}
        block={3}
      >
        <FormList
          className={styles.formList}
          columns={columns}
          values={formData}
          rules={rules}
          onChange={(v) => {
            setFormData(v)
          }}
        />

        <div className={styles.agentDepositBtn}>
          <Button
            loading={isMutating}
            onClick={handleSubmit}
            disabled={buttonDisabled}
          >
            确认代存
          </Button>
        </div>
      </SkeletonUI>

      <MaskContentPop
        visible={visible}
        onMaskClick={() => setVisible(false)}
        title={'温馨提示'}
        onClickConfirm={() => setVisible(false)}
        configs={configs}
        showIndex={false}
        textCenter={false}
        model={2}
      />

      <SecurityCheck
        eyesType={formData?.proxyType === 1 ? 3 : 2}
        onSussess={async () => {
          //请求数据
          await trigger({}).then((data) => {
            setFormData({
              ...formData,
              disableAmount: data?.valetMoney,
              commissionAmount: data?.agentMoney
            })
            setShowSecurity(false)
          })
        }}
        visible={showSecurity}
        onClose={() => setShowSecurity(false)}
      />
    </div>
  )
}

export default AgentDeposit
