export default {
    name: "agentDeposit",
    author: true,
    isRootRouter: true
};
  