import { apiFetcher, useSWRExpand } from '@/api/api'

/**获取代理信息 缓存20分钟*/
export function useMemberDetail(params: any) {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/member/detail',
        type: 'post'
      },
      {
        arg: params
      }
    )
  }
  return useSWRExpand('useMemberDetail', fetcherFuc, {
    dedupingInterval: 20 * 60 * 1000
  })
}
