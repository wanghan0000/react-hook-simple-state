export default {
    name: "detail",
    author: true,
    isRootRouter: true
};
  