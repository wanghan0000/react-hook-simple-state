import HeaderUI from '@/compoments/HeaderUI'
import React, { useEffect, useMemo, useState } from 'react'
import QuestionMark from '@/assets/main/questionMark.png'
import MaskContentPop from '@/compoments/maskContentPop'
import { useLocation, useNavigate } from 'react-router'
import IconImage from '@/compoments/IconImage'
import CopyPng from '@/assets/common/copy.png'
import WalletDeposit from './assets/walletDeposit.png'
import WalletDraw from './assets/walletDraw.png'
import { Button, Toast } from 'antd-mobile'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import { useAgentInfo, useGetAllGameVenue } from '@/commonApi'
import { getCurrentDateString } from '@/utils/date'
import FormFilter from '@/compoments/formFilter'
import { useMemberDetail } from './api'
import LoadMoreList from '@/compoments/loadMoreList'
import { GameRecordItem } from '@/views/gameRecord'
import copy from 'copy-to-clipboard'
import styles from './index.module.scss'
import { useGetGameInfoList } from '@/views/gameRecord/api'

const UserInfo = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const locaData = location.state || {}

  const { data } = useMemberDetail({
    id: locaData.id,
    pageNum: 1,
    pageSize: 10,
    startDate: getCurrentDateString(0, true, 'YYYY-MM-DD'),
    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
  })

  const dataLeftDetails = useMemo(
    () => [
      { title: '红利', value: `¥${Number(data?.promo || 0).toFixed(2)}` },
      { title: '返水', value: `¥${Number(data?.rebate || 0).toFixed(2)}` },
      {
        title: '有效投注',
        value: `¥${Number(data?.netAmount || 0).toFixed(2)}`
      },
      { title: '总投注(已结算)', value: `¥${Number(data?.betAmount || 0).toFixed(2)}` }
    ],
    [data]
  )
  const dataRightDetails = useMemo(
    () => [
      {
        title: '今日输赢',
        value: `¥${Number(data?.toDayProfit || 0).toFixed(2)}`
      },
      { title: '总输赢', value: `¥${Number(data?.profit || 0).toFixed(2)}` },
      {
        title: '账户调整',
        value: `¥${Number(data?.riskAdjust || 0).toFixed(2)}`
      }
    ],
    [data]
  )

  return (
    <div className={styles.detailInfo}>
      <div className={styles.userInfo}>
        <div className={styles.userTop}>
          <div className={styles.userTopLeft}>
            <div className={styles.userAvater}>{locaData?.name?.[0]}</div>
            <div className={styles.userInfoInfo}>
              <div className={styles.userInfoName}>
                <span>{locaData?.name}</span>
                <IconImage
                  onClick={() => {
                    if (copy(locaData?.name)) {
                      Toast.show('复制成功')
                    }
                  }}
                  imagePath={CopyPng}
                  className={styles.copyImage}
                />
              </div>
              <div className={styles.userStatus}>
                <div className={styles.userVipIcon}>V{locaData?.vipGrade}</div>
              </div>
            </div>
          </div>

          <div className={styles.userTopRight}></div>
        </div>

        <div className={styles.userLine}></div>

        <div className={styles.userDate}>
          <div className={styles.userInfoItem}>
            <span>注册时间</span>
            <span>{locaData?.registerDate}</span>
          </div>
          <div className={styles.userInfoItem}>
            <span>最后登录</span>
            <span>{locaData?.lastLoginTime}</span>
          </div>
        </div>
      </div>

      <div className={styles.moneyInfo}>
        <div>
          <IconImage className={styles.moenyIcon} imagePath={WalletDraw} />
          <div className={styles.moneyDetail}>
            <span>存款</span>
            <span>
              ¥{data?.deposit ? Number(data?.deposit).toFixed(2) : '0.00'}
            </span>
          </div>
        </div>
        <div>
          <IconImage className={styles.moenyIcon} imagePath={WalletDeposit} />
          <div className={styles.moneyDetail}>
            <span>取款</span>
            <span>¥{data?.draw ? Number(data?.draw).toFixed(2) : '0.00'}</span>
          </div>
        </div>
      </div>

      <div className={styles.userInfoList}>
        <div className={styles.dataDetail}>
          <div className={styles.dataDetailLeft}>
            {dataLeftDetails.map((v, index) => {
              return (
                <div key={index}>
                  <span>{v.title}</span>
                  <span>{v.value}</span>
                </div>
              )
            })}
          </div>

          <div className={styles.dataDetailLine}></div>

          <div className={styles.dataDetailRight}>
            {dataRightDetails.map((v, index) => {
              return (
                <div key={index}>
                  <span>{v.title}</span>
                  <span>{v.value}</span>
                </div>
              )
            })}
          </div>
        </div>

        <div className={styles.isDisabledBox}>
          <span>账户状态：</span>
          <span className={styles.tagSuccess}>
            {locaData?.status === 0 ? '停用' : '正常'}
          </span>
        </div>

        <div className={styles.userInfoLine}></div>

        <div className={styles.depositBox}>
          <Button
            onClick={() =>
              navigate('/main/members/agentDeposit', {
                state: { ...locaData }
              })
            }
            className={styles.depositBoxBtn}
          >
            代存
          </Button>
        </div>
      </div>
    </div>
  )
}

const Detail = () => {
  const configs = ['基本信息统计时间为本月区间，从当月1号起至当月最后一天。']
  const navigate = useNavigate()
  const [visible, setVisible] = useState(false)

  const { data: options = [] } = useGetAllGameVenue()
  const { data: userInfo } = useAgentInfo()

  const location = useLocation()
  const locaData = location.state || {}

  const [formData, setFormData] = useState({
    startDate: getCurrentDateString(0, true, 'YYYY-MM-DD'),
    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
    memberName: locaData?.name,
    venueId: -1,
    flag: -1
  })

  const { filter, pager, nextPage, reset , error } = useGetGameInfoList({
    ...formData
  })

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.dateRange,
        prop: ['startDate', 'endDate'],
        placeHolder: ['开始时间', '结束时间']
      },
      {
        domType: FormDomTypes.select,
        placeHolder: '选择游戏场馆',
        prop: 'venueId',
        width: '130px',
        options: options
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            startDate: getCurrentDateString(0, true, 'YYYY-MM-DD'),
            endDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
            flag: -1,
            memberName: locaData?.name,
            venueId: -1
          }
          setFormData(params)
          filter({
            ...params
          })
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({
            ...formData
          })
        }
      }
    ],
    [options, formData, locaData]
  )

  async function loadMore() {
    await nextPage({
      ...formData
    })
  }

  useEffect(() => {
    if (error) {
      Toast.show({
        content: error?.message
      })
      setFormData({
        ...formData,
        startDate: getCurrentDateString(0, true, 'YYYY-MM-DD'),
        endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
      })
    }
  }, [error])

  return (
    <div>
      <HeaderUI
        title="成员"
        showBack={true}
        onClickBack={() => navigate(-1)}
        rightNode={
          <>
            <img
              onClick={() => setVisible(true)}
              className={styles.questionMark}
              src={QuestionMark}
              alt="question mark"
            />
          </>
        }
      />
      <UserInfo />
      <div className={styles.detailList}>
        <div className={styles.gameTitle}>游戏动态</div>
        <div className={styles.betWrap}>
          <p className={styles.betTime}>最后投注时间：2024-04-21 19:19:51</p>
          <p className={styles.betTips}>
            该投注时间仅作为参考，可能存在时间偏差
          </p>
        </div>
        <div className={styles.gameMainList}>
          <FormFilter
            value={formData}
            onChange={(v) => {
              setFormData({
                ...v
              })
            }}
            columns={columns}
          />

          <LoadMoreList
            datas={pager.list}
            loadMore={loadMore}
            hasMore={pager.hasMore}
            firstLoading={pager.isFirstLoading}
            render={(item, index) => {
              return (
                <GameRecordItem
                  {...item}
                  vTopAgentName={userInfo?.name ?? '--'}
                />
              )
            }}
            itemClassName={styles.gameRecordItem}
          />
        </div>
      </div>

      <MaskContentPop
        visible={visible}
        onMaskClick={() => setVisible(false)}
        title={'温馨提示'}
        onClickConfirm={() => setVisible(false)}
        configs={configs}
        showIndex={false}
        textCenter={true}
      />
    </div>
  )
}

export default Detail
