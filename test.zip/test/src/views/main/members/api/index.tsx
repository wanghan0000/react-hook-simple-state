import { apiFetcher, useSWRExpand } from '@/api/api'
import { usePagePlus } from '@/commonHooks/usePagePlus'
import useSWRMutation from 'swr/mutation'

//筛选成员列表
export const useFilterMemberList = (params) => {
  return usePagePlus({
    formData: params,
    catchKey: 'useFilterMemberList',
    apiPath: '/member/list'
  })
}

//获取代理佣金余额
export const useGetDrawMoney = () => {
  const params = {
    path: '/finance/draw/initMoney',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

export const useGetDrawCacheMoney = () => {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: "/finance/draw/initMoney",
        type: "post",
      },
      {}
    );
  };
  return useSWRExpand("useGetDrawCacheMoney", fetcherFuc, {
    dedupingInterval: 20 * 60 * 1000,
    revalidateOnMount: false
  });
}

//代理代存
export const useAgentDrawMoney = () => {
  const params = {
    path: '/finance/deposit/agentDeposit',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}
//代理转账-代理转账接口
export const useApiAgentTransfer = () => {
  const params = {
    path: '/finance/transfer/agentTransfer',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

//获取存款配置
export function useGetAgentDepositConfig() {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: "/front/getAgentDepositConfig",
        type: "post",
      },
      {}
    );
  };
  return useSWRExpand("useGetAgentDepositConfig", fetcherFuc, {
    dedupingInterval: 20 * 60 * 1000,
  });
}


//代存记录列表
export const useAgentRecordList = (formData) => {
  // const params = {
  //   path: '/finance/deposit/agentDepositRecordList',
  //   type: 'post'
  // }
  // return useSWRMutation(params, (params, arg: { arg: any }) => {
  //   return apiFetcher<any>(params, { ...arg })
  // })
  return usePagePlus({
    formData: formData,
    catchKey: 'useAgentRecordList',
    apiPath: '/finance/deposit/agentDepositRecordList'
  })
}
//代理转账-分页获取转账记录列表
export const useApiTransferRecordList = (formData) => {
  // const params = {
  //   path: '/finance/deposit/agentDepositRecordList',
  //   type: 'post'
  // }
  // return useSWRMutation(params, (params, arg: { arg: any }) => {
  //   return apiFetcher<any>(params, { ...arg })
  // })
  return usePagePlus({
    formData: formData,
    catchKey: 'useApiTransferRecordList',
    apiPath: '/finance/transfer/transferRecordList'
  })
}
