import HeaderUI from '@/compoments/HeaderUI'
import FormFilter from '@/compoments/formFilter'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'
import LoadMoreList from '@/compoments/loadMoreList'
import { usePage } from '@/commonHooks/usePage'
import { useAgentRecordList } from '../api'
import DescriptionCard from '@/compoments/descriptionCard'
import { getCurrentDateString, getStartAndEndOfMonth } from '@/utils/date'
import { Toast } from 'antd-mobile'

const dictDrawStatus = [
  { label: '全部', value: -1 },
  { label: '成功', value: 403 },
  { label: '失败', value: 99 }
]
const dictDrawTransferStatus = [    
  { label: '全部', value: -1 },
  { label: '处理中', value: 1 },
  { label: '成功', value: 2 },
  { label: '失败', value: 3 }
]

const HistoryItem = (props: any) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [{ title: '申请时间', text: props?.createdAt ?? '--' }]
      },
      {
        group: [{ title: '代存类型', text: props?.withdrawTypeStr ?? '--' }]
      },
      {
        group: [{ title: '下级账号', text: props?.transferMemberName ?? '--' }]
      },
      {
        group: [{ title: '订单号', text: props?.billNo ?? '--' }]
      },
      {
        group: [{ title: '备注', text: props?.remark ?? '--' }]
      }
    ],
    [props]
  )

  const handleDrawStatusText = useMemo(() => {
    if (typeof props.drawStatus !== 'number') {
      return '--'
    }
    return (
      dictDrawStatus.find((item) => item.value === props.drawStatus)?.label ??
      props.drawStatus
    )
  }, [props])

  return (
    <DescriptionCard
      topNode={
        <>
          <div className={styles.itemMoney}>
            ¥{`${Number(props?.amount || 0).toFixed(2)}`}
          </div>
          <div className={styles.itemStatus + ' ' + styles.itemSuccess}>
            <i></i>
            <div>{handleDrawStatusText}</div>
          </div>
        </>
      }
      bodyColumns={bodyColumns}
    />
  )
}

const History = () => {
  const navigate = useNavigate()

  const [formData, setFormData] = useState({
    status: -1,
    startDate: getStartAndEndOfMonth(0).startOfMonth,
    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
  })
//useApiTransferRecordList

  const { filter, pager, nextPage, reset, error } = useAgentRecordList(formData)

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.select,
        placeHolder: '选择游戏场馆',
        prop: 'status',
        width: '130px',
        options: dictDrawStatus
      },
      {
        domType: FormDomTypes.dateRange,
        prop: ['startDate', 'endDate'],
        placeHolder: ['开始时间', '结束时间']
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            status: -1,
            startDate: getStartAndEndOfMonth(0).startOfMonth,
            endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
          }
          setFormData(params)
          reset(params)
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter(formData)
        }
      }
    ],
    [formData]
  )

  async function loadMore() {
    await nextPage({
      ...formData
    })
  }

  useEffect(() => {
    if (error) {
      Toast.show(error?.message)
      setFormData({
        ...formData,
        startDate: getStartAndEndOfMonth(0).startOfMonth,
        endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
      })
    }
  }, [error])

  return (
    <div>
      <HeaderUI
        title="代存记录"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.historyBox}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>

      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <HistoryItem {...item} />
          }}
          itemClassName={styles.historyItem}
        />
      </div>
    </div>
  )
}

export default History
