import React, { useState } from 'react'
import styles from './index.module.scss'
import HeaderUI from '@/compoments/HeaderUI'
import QuestionMark from '@/assets/main/questionMark.png'
import Overview from './compoments/overview'
import MemberList from './compoments/memberList'
import MaskContentPop from '@/compoments/maskContentPop'
const Members = () => {
  const configs = [
    '数据更新，系统每天会定时更新成员数据，部分数据可能会存在延迟',
    '输赢: 会员游戏产生的输赢会用绿颜色标记数据表示代理方盈利；红颜色标记数据则表示代理方亏损',
    '活跃: 会员在时间段内累计的投注/存款金额达标即算活跃；活跃会员会显示“跃”字图标',
    '转代: 会员从其他代理转入或通过溢出申请找回时算转代，转代会员会显示“转”字图标；'
  ]
  const [visible, setVisible] = useState(false)

  return (
    <div>
      <MaskContentPop 
      visible={visible}
      onMaskClick={() => setVisible(false)}
      title={'提示'}
      onClickConfirm={()=> setVisible(false)}
      configs={configs}
      />
      <HeaderUI
        title="成员"
        rightNode={
          <>
            <img
              onClick={() => setVisible(true)}
              className={styles.questionMark}
              src={QuestionMark}
              alt="question mark"
            />
          </>
        }
      />
      <div className={styles.memberContent}>
        <Overview />
        <MemberList />
      </div>
    </div>
  )
}
//
export default Members
