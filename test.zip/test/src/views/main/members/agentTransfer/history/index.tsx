import HeaderUI from '@/compoments/HeaderUI'
import FormFilter from '@/compoments/formFilter'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'
import LoadMoreList from '@/compoments/loadMoreList'
import { usePage } from '@/commonHooks/usePage'
import { useAgentRecordList, useApiTransferRecordList } from '../../api'
import DescriptionCard from '@/compoments/descriptionCard'
import { getCurrentDateString, getStartAndEndOfMonth } from '@/utils/date'
import { Toast } from 'antd-mobile'
import { formatNumberWithCommas } from '@/utils'

const dictDrawTransferStatus = [
  { label: '全部', value: -1 },
  { label: '处理中', value: 1 },
  { label: '成功', value: 2 },
  { label: '失败', value: 3 }
]

const HistoryItem = (props: any) => {
  const withdrawTypeStr =
    props?.withdrawType == 20203
      ? '佣金转账 '
      : props?.withdrawType == 20204
        ? '额度转账 '
        : ''
  const bodyColumns = useMemo(
    () => [
      {
        group: [{ title: '订单号', text: props?.billNo ?? '--' }]
      },
      {
        group: [{ title: '团队代理', text: props?.transferMemberName ?? '--' }]
      },
      {
        group: [{ title: '转账类型', text: withdrawTypeStr ?? '--' }]
      },
      {
        group: [
          {
            title: '转账金额',
            text: formatNumberWithCommas(props?.amount) ?? '--'
          }
        ]
      },
      {
        group: [{ title: '申请时间', text: props?.createdAt ?? '--' }]
      },
      {
        group: [{ title: '备注', text: props?.drawComment ?? '--' }]
      }
    ],
    [props]
  )

  const handleDrawStatusText = useMemo(() => {
    if (typeof props.drawStatus !== 'number') {
      return '--'
    }
    return (
      // dictDrawTransferStatus.find((item) => item.value === props.drawStatus)?.label ??
      props.drawStatusStr
    )
  }, [props])

  return (
    <DescriptionCard
      topNode={
        <>
          <div className={styles.itemMoney}>
            ¥{`${Number(props?.amount || 0).toFixed(2)}`}
          </div>
          <div className={styles.itemStatus + ' ' + styles.itemSuccess}>
            <i></i>
            <div>{handleDrawStatusText}</div>
          </div>
        </>
      }
      bodyColumns={bodyColumns}
    />
  )
}

const History = () => {
  const navigate = useNavigate()

  const [formData, setFormData] = useState({
    status: -1,
    startDate: getStartAndEndOfMonth(0).startOfMonth,
    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
    drawType: 0
  })

  const { filter, pager, nextPage, reset, error } =
    useApiTransferRecordList(formData)

  const columnsFilter = useMemo(
    () => [
      {
        domType: FormDomTypes.select,
        placeHolder: '选择游戏场馆',
        prop: 'status',
        width: '130px',
        options: dictDrawTransferStatus
      },
      {
        domType: FormDomTypes.dateRange,
        prop: ['startDate', 'endDate'],
        placeHolder: ['开始时间', '结束时间']
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.select,
        prop: 'drawType',
        options: [
          { label: '佣金转账', value: 0 },
          { label: '额度转账', value: 1 }
        ]
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            status: -1,
            startDate: getStartAndEndOfMonth(0).startOfMonth,
            endDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
            drawType: 0
          }
          setFormData(params)
          reset(params)
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter(formData)
        }
      }
    ],
    [formData]
  )

  async function loadMore() {
    await nextPage({
      ...formData
    })
  }

  useEffect(() => {
    if (error) {
      Toast.show(error?.message)
      setFormData({
        ...formData,
        startDate: getStartAndEndOfMonth(0).startOfMonth,
        endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
      })
    }
  }, [error])

  return (
    <div>
      <HeaderUI
        title="转账记录"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.historyBox}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columnsFilter}
        />
      </div>

      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <HistoryItem {...item} />
          }}
          itemClassName={styles.historyItem}
        />
      </div>
    </div>
  )
}

export default History
