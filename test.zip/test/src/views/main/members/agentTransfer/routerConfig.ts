/*
 * @Author: Mark
 * @Date: 2024-06-04 21:59:24
 * @LastEditTime: 2024-06-04 21:59:25
 * @LastEditors: MarkMark
 * @Description: 佛祖保佑无bug
 * @FilePath: /agent_h5/src/views/main/members/agentTransfer/routerConfig.ts
 */
export default {
    name: "agenttransfer",
    author: true,
    isRootRouter: true
};
  