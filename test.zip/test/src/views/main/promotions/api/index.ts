import { apiFetcher, useSWRExpand } from "@/api/api"
import useSWRMutation from "swr/mutation";

/*  推广中心-推广链接 缓存20分钟*/
export function useApiPromoteLin() {
    const fetcherFuc = () => {
      return apiFetcher(
        {
            path: '/promoteCenter/promoteLink',
            type: 'post'
        },
        {}
      ).then((data: any) => {
        const result = {
          ...data
        }
        return result
      })
    };
    return useSWRExpand("useApiPromoteLin", fetcherFuc, {
      dedupingInterval: 20 * 60 * 1000,
    });
}


/*  推广中心-推广素材 */
export const useApiSelectMaterialList = () => {
    const params = {
        path: '/promoteCenter/selectMaterialList',
        type: 'post'
    }
    return useSWRMutation(params, (params, arg: { arg: any }) => {
      return apiFetcher<any>(params, { ...arg })
    })
}

// /*  推广中心-推广素材 全部图片大小*/
// export function apiSelectMaterialSizeList(data: Partial<any>) {
//     return request.post({ url: '/promoteCenter/selectMaterialSizeList', data })
// }

// /*  推广中心- 下载次数   */
// export function apiMaterialDownloadTimes(data: Partial<any>) {
//     return request.post({ url: '/promoteCenter/materialDownloadTimes', data })
// }

