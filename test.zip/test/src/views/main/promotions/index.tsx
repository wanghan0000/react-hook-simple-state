import React, { Dispatch, SetStateAction, useRef, useState } from 'react'
import SwiperTabs from '@/compoments/SwiperTabs'
import { Button, Dialog, Modal, Picker, Space, Toast } from 'antd-mobile'
import logoSrc from '../home/assets/logo.png'
import QRCode from 'qrcode.react'
import { useApiPromoteLin } from './api/index'
import { useAgentInfo } from '@/commonApi'
import domtoimage from 'dom-to-image'
import IconImage from '@/compoments/IconImage'
import DeletePng from '@/assets/common/delete.png'
import styles from './index.module.scss'
import CopyPath from '@/assets/common/copy.png'
import DownLoadPath from '@/assets/common/download.png'
import copy from 'copy-to-clipboard'

interface MySwiperProps {
  tabItems: { key: string; title: string }[]
  activeIndex: number
  setActiveIndex: Dispatch<SetStateAction<number>>
  children: React.ReactNode[]
}
interface basicColumnsProps {
  title: string
  link: string
}

export const basicColumns = [
  [
    { label: '长链接', value: 1 }
    // { label: '防封短链(微信)', value: 2 },
    // { label: '防封短链(QQ)', value:3 }
  ]
]

const handleDialogCopy = async (item: basicColumnsProps, handler: any) => {
  Dialog.confirm({
    title: '温馨提示',
    bodyClassName: styles.promotionsDialogCopy,
    content: `已帮你生成${item.title}并复制\n ${item.link}`,
    // cancelText: '重新生成',
    confirmText: '复制',
    onConfirm: async () => {
      navigator.clipboard.writeText(item.link)
      await 3000
      Toast.show({
        icon: 'success',
        content: '复制成功',
        position: 'center'
      })
    }
  })
}

const useResData = () => {
  const { data: userInfo } = useAgentInfo()
  const inviteCode = '?icode=' + userInfo?.inviteCode
  const { data: resData } = useApiPromoteLin()
  const dataArr = [
    { title: '全站App代理链接', link: resData?.sportAppDomainUrl + inviteCode },
    { title: 'PC端代理链接', link: resData?.pcDomainUrl + inviteCode },
    { title: 'H5版代理链接', link: resData?.h5DomainUrl + inviteCode }
  ]
  return dataArr
}

const MyComponent1 = () => {
  const contentRef = useRef(null)
  const handleModalErm = async (item: basicColumnsProps, handler: any) => {
    handler.current = Modal.show({
      bodyClassName: styles.promotionsModalErm,
      header: (
        <div className={styles.codeHeader}>
          <img src={logoSrc} />
          <IconImage
            onClick={() => {
              handler.current?.close()
            }}
            imagePath={DeletePng}
            className={styles.deletePng}
          />
        </div>
      ),
      // image: logoSrc,
      content: (
        <div ref={contentRef}>
          <QRCode
            value={item.link}
            size={220}
            bgColor="#f0f0f0"
            fgColor="#333"
            level="H"
            includeMargin={false}
          />
          <p className={styles.first}>扫一扫，体验好博体育丰富的娱乐游戏</p>
          <p className={styles.last}>每日每场皆有奖，福利惊喜不停</p>
        </div>
      ),
      closeOnMaskClick: false,
      actions: [
        {
          key: 'save',
          text: '保存二维码',
          onClick: () => {
            //todo : 进行图片下载
            domtoimage.toPng(contentRef.current).then(function (dataUrl) {
              const link = document.createElement('a')
              link.download = 'my-image-name.png'
              link.href = dataUrl
              link.click()

              handler.current?.close()
            })
          }
        }
      ]
    })
  }

  const handleClick = async (
    item: basicColumnsProps,
    i: number,
    handler: any
  ) => {
    const value = await Picker.prompt({
      popupClassName: styles.promotionsPickerPrompt,
      title: i == 1 ? '下载二维码' : '复制链接',
      columns: basicColumns,
      style: {
        '--title-font-size': '18px',
        '--header-button-font-size': '16px'
      }
    })
    if (i == 1) {
      value && handleModalErm(item, handler)
    } else if (i == 2) {
      value && handleDialogCopy(item, handler)
    }
  }

  const handler = useRef<any>()
  const data = useResData()
  return (
    <>
      {data?.map((item, key) => {
        return (
          <div className={styles.promotionsLink} key={key}>
            <div className={styles.promotionsLinkBox}>
              <div className={styles.left}>
                <p>{item.title}</p>
                <b>{item.link}</b>
              </div>
              <div className={styles.right}>
                <Button
                  className={styles.link_btn1}
                  onClick={() => {
                    handleClick(item, 1, handler)
                  }}
                >
                  <img src={DownLoadPath} />
                </Button>
                <Button
                  className={styles.link_btn2}
                  onClick={() => {
                    handleClick(item, 2, handler)
                  }}
                >
                  <img src={CopyPath} />
                  <span>复制</span>
                </Button>
              </div>
            </div>
          </div>
        )
      })}
    </>
  )
}

const MyComponent2 = () => {
  const { data } = useApiPromoteLin()
  const privateDomain = data?.privateDomain || []
  return (
    <div>
      {privateDomain.map((v, index) => {
        return (
          <div key={index} className={styles.privateDomainItem}>
            <div>
              <span className={styles.domainTitle}>{v.targetStr}</span>
            </div>
            <div>
              {v?.domain?.map((e, index) => {
                return (
                  <div key={index} className={styles.domainItem}>
                    <span>{e.privateDomain}</span>
                    <Button
                      className={styles.link_btn2}
                      onClick={() => {
                        if(copy(e.privateDomain)) {
                          Toast.show('复制成功')
                        }
                        //handleClick(item, 2, handler)
                      }}
                    >
                      <img src={CopyPath} />
                      <span>复制</span>
                    </Button>
                  </div>
                )
              })}
            </div>
          </div>
        )
      })}
    </div>
  )
}

const Promotions = () => {
  const [tabItems, setTabItems] = useState([
    { key: 'promotionLink', title: '推广链接' },
    { key: 'exclusiveDomain ', title: '专属域名' }
    // { key: 'promotionPkg', title: '渠道打包' }
  ])

  const childComponents = [<MyComponent1 key={0} />, <MyComponent2 key={1} />]
  const [activeIndex, setActiveIndex] = useState(0)
  return (
    <SwiperTabs
      tabItems={tabItems}
      activeIndex={activeIndex}
      setActiveIndex={setActiveIndex}
      childComponents={childComponents}
    />
  )
}
//
export default Promotions
