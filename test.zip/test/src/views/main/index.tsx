import React, { useEffect, useState } from 'react'
import { Outlet, useLocation, useNavigate } from 'react-router'
import BottomBar from './compoments/bottomBar'
import style from './index.module.scss'
import WelcomePop from './compoments/welcomePop'
import { useCheckSecurity } from './myProfile/securityCenter/api'
import SafetyWarningPop from './compoments/SafetyWarningPop'

const ShowWelcomPop = () => {
  const location = useLocation()
  const navigate = useNavigate()
  const { showWelcome } = location.state || {}
  const [visible, setVisible] = useState(showWelcome)

  useEffect(() => {
    if (showWelcome) {
      // 使用 replace 更新当前路由，但不包含任何 state
      navigate('/main/home', { replace: true, state: {} })
    }
  }, [showWelcome, navigate, location.pathname])

  return (
    <div>
      <WelcomePop
        visible={visible}
        onClose={() => {
          setVisible(false)
        }}
      />
      <SafetyWarning welcomeClose={visible} />
    </div>
  )
}

const SafetyWarning = (props: any) => {
  const { data } = useCheckSecurity()
  const location = useLocation()

  const [visible, setVisible] = useState(false)
  const { data: config  } = useCheckSecurity()

  useEffect(() => {
    if (!props.welcomeClose && data) {
      if ((!data.googleAuth && config?.googleWhite !== 1) || !data.payPassword || !data.secretSecurity) {
        setVisible(true)
      } else {
        setVisible(false)
      }
    }
  }, [props, data, location.pathname,config])

  return <SafetyWarningPop visible={visible} />
}

const Main = () => {
  return (
    <div className={style.main}>
      <div className={style.content}>
        <Outlet />
      </div>
      <div className={style.bottomBar}>
        <BottomBar />
      </div>

      <ShowWelcomPop />
    </div>
  )
}

export default Main
