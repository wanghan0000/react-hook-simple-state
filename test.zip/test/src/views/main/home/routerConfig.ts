export default {
    name: "home",
    author: true
};
  