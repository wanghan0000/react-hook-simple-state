import React from 'react';
import styles from './index.module.scss'
import Logo from './compoments/logo';
import Cabbage from './compoments/cabbage';
import Menu from './compoments/menu';
import LineChartContent from './compoments/lineChart';
import Deposit from './compoments/deposit';
import GameWin from './compoments/gameWin';
const Home = () => {

  return (
    <div >
        <div className={styles.banner}>
          <Logo />
          <Cabbage />
          <Menu />
          <LineChartContent />
          <Deposit />
          <GameWin />
        </div>
    </div>
  );
};
//
export default Home;
