import React, { useEffect, useRef } from 'react'
import List from '../list'
import { useGetLastDeposit } from '../../api'
import { useNavigate } from 'react-router'

export interface DepositProps {}

const Deposit = (props: DepositProps) => {
  const { isLoading, data } = useGetLastDeposit()
  const navigate = useNavigate()

  return (
    <List
      onClickMore={() => navigate('/depositRecord')}
      title="最新存款"
      amountTitle="存款金额"
      datas={data?.list}
      isLoading={isLoading}
    />
  )
}

export default Deposit
