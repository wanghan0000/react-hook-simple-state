import React from 'react'
import styles from './index.module.scss'
import SvgProgress from '@/compoments/SvgProgress'
import { useGetFrontBanner } from '../../api'

const Cabbage = () => {
  const { data, isLoading } = useGetFrontBanner()

  const rate = data?.rate || 0
  const profit = Number(data?.netWinLose || 0)?.toFixed(2) || '0.00'
  const activeMembers = data?.activeMembers || 0
  const effectiveNew = data?.effectiveNew || 0
  const firstDepositNum = data?.firstDepositNum || 0
  const commission = data?.commission || 0
  const registerMembers = data?.registerMembers || 0
  return (
    <div className={styles.cabbage}>
      <div className={styles.leftBox}>
        <div className={styles.echartBox}>
          <SvgProgress percent={rate} className={styles.svg} />
        </div>
        <footer>
          <div className={styles.percentage}>
            {rate}
            <span>%</span>
          </div>
          <div className={styles.illustrate}>本月佣金比例</div>
        </footer>
      </div>
      <div className={styles.rightBox}>
        <div className={styles.commission}>
          <main>
            <p>本月净输赢</p>
            <p className={styles.number + ' ' + (Number(profit) > 0 ? styles.green : styles.red)}>¥{profit}</p>
            <span></span>
          </main>
          <main>
            <p>本月佣金</p>
            <p className={styles.number}>¥{commission}</p>
          </main>
        </div>
        <div className={styles.numberOfPeople}>
          <main>
            <p>活跃人数</p>
            <p className={styles.number}>{activeMembers}</p>
            <span></span>
          </main>
          <main>
            <p>登录人数</p>
            <p className={styles.number}>{registerMembers}</p>
          </main>
          <main className={styles.mainBottom}>
            <p>新增下级</p>
            <p className={styles.number}>{effectiveNew}</p>
            <span></span>
          </main>
          <main className={styles.mainBottom}>
            <p>首存人数</p>
            <p className={styles.number}>{firstDepositNum}</p>
          </main>
        </div>
      </div>
      <div style={{ clear: 'both' }}></div>
    </div>
  )
}

export default Cabbage
