import React, { useMemo } from 'react'

import styles from './index.module.scss'
import logo from '../../assets/logo.png'
import message from '../../assets/message.png'
import UnMessageIcon from '@/assets/common/unMessageIcon.png'
import server from '@/assets/main/server.png'
import { useAgentInfo } from '@/commonApi'
import { DotLoading } from 'antd-mobile'
import { useNavigate } from 'react-router'
import { useGetUnreadForType } from '@/views/main/myProfile/api'

const Logo = () => {
  const { data } = useAgentInfo()
  const navigate = useNavigate()
  const { data: notice } = useGetUnreadForType()

  const isShow = useMemo(() => {
    return (
      !!notice?.noticeCount ||
      !!notice?.activityCount ||
      !!notice?.bulletinCount
    )
  }, [notice])

  const handleServer = () => {
     navigate('/online')
  }

  return (
    <div className={styles.logoContent}>
      <img className={styles.logo} src={logo} alt="logo" />
      <div className={styles.welcome}>
        Welcome, {!data?.name ? <DotLoading /> : `${data?.name}!`}
      </div>
      <img onClick={handleServer} className={styles.server} src={server} alt="server" />
      <img
        onClick={() => {
          navigate('/main/myProfile/notice')
        }}
        className={styles.message}
        src={isShow ? message : UnMessageIcon}
        alt="message"
      />
      <div className={styles.pump}>
        {!data?.name?.[0] ? <DotLoading /> : data?.name?.[0]}
      </div>
    </div>
  )
}
//
export default Logo
