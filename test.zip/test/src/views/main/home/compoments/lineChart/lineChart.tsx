import React, { memo, useEffect, useRef, useState } from 'react'
import Highcharts from 'highcharts'
import HighchartsReact, { HighchartsReactRefObject } from 'highcharts-react-official'
import styles from './index.module.scss'

export interface LineChartProps {
  //y 间隔
  tickInterval: number | undefined
  //展示数据
  series1: any[] | undefined
  //
  series2: any[] | undefined
  //
  min: number | undefined
  max: number | undefined
}

const LineChart = ({
  tickInterval = 1,
  series1 = [],
  series2 = [],
  min = 0,
  max = 1
}: LineChartProps) => {
  function getDaysInMonth() {
    const currentDate = new Date()
    const month = currentDate.getMonth() + 1
    const year = new Date().getFullYear()
    return new Date(year, month, 0).getDate()
  }

  const days = useRef<number>(getDaysInMonth())

  const chartComponentRef = useRef<HighchartsReactRefObject>(null)

  const options = {
    chart: {
      type: 'spline',
      className: styles.react,
      height: 192,
      style: {
        fontSize: '12px' // 设置全局字体大小
      }
    },
    title: {
      text: ''
    },
    xAxis: {
      categories: Array.from({ length: days.current }, (_, i) => `${i + 1}日`),
      crosshair: {
        width: 1, // 十字准线的宽度
        color: 'rgb(227, 228, 230)', // 十字准线的颜色
        dashStyle: 'Solid' // 十字准线的样式
      },
      tickInterval: 6,
      labels: {
        y: 18 // 根据实际需要调整此值
      }
    },
    yAxis: {
      title: '',
      tickInterval: tickInterval,
      gridLineDashStyle: 'Dash', // 设置虚线样式
      min: min,
      max: max
    },
    series: [
      {
        name: '',
        //data: Array.from({ length: 31 }, (_, i) => (0)),
        data: series1,
        showInLegend: false,
        marker: {
          enabled: false
        },
        linecap: 'round', // 设定线条末端为圆形,
        lineWidth: 1.5,
        color: '#000000'
      },
      {
        name: '',
        data: series2,
        showInLegend: false,
        marker: {
          enabled: false
        },
        lineWidth: 1.5,
        linecap: 'round' // 设定线条末端为圆形
      }
    ],
    credits: {
      enabled: false
    },
    plotOptions: {
      series: {
        states: {
          hover: {
            halo: {
              size: 10, // 内圈的大小
              opacity: 1, // 内圈完全不透明
              attributes: {
                fill: 'rgba(255, 255, 255, 1)' // 外圈颜色为白色，带有一定的透明度
              }
            }
          }
        },
        marker: {
          symbol: 'circle' // 将数据点形状设置为圆形
        }
      }
    },
    tooltip: {
      useHTML: true, // 启用HTML标签
      style: {
        fontSize: '12px' // 更小的字体大小
      },
      crosshairs: true, // 显示十字准线
      shared: true, // 在多序列的图表中共享提示框
      formatter: function ({ chart: { hoverPoints } }: any) {
        // 自定义工具提示的内容
        const blackCircle = '<span style="color: #333333;">●</span> '
        const blueCircle = '<span style="color: #7cb5ec;">●</span> '
        const title = hoverPoints?.[0]?.category + '<br/>'
        return (
          title +
          blackCircle +
          '上月：' +
          (hoverPoints?.[0]?.options?.y ?? '--') +
          '<br/>' +
          blueCircle +
          '本月：' +
          (hoverPoints?.[1]?.options?.y ?? '--')
        )
      }
    }
  }

  useEffect(() => {
     if(chartComponentRef.current) {
      //chartComponentRef.current.chart.u
     }
  }, [options])

  return (
    <div className={styles.lineChartContent}>
    <HighchartsReact
        ref={chartComponentRef}
        highcharts={Highcharts}
        options={options}
      />
    </div>
  )
}

export default memo(LineChart)
