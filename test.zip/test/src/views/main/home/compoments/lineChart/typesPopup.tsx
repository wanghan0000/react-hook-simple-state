import React, { useEffect, useState } from 'react'
import { PickerView, Popup } from 'antd-mobile'
import { PickerValue } from 'antd-mobile/es/components/picker'
import styles from './index.module.scss'
import './typesPopup.scss'
import { basicColumns } from './common'

interface TypesPopupProps {
  visible?: boolean
  value?: '1' | '2' | '3' | '4' | '6' | '7'
  onConfirm?: (value: any) => void
  onClose?: () => void
}

const TypesPopup = (props: TypesPopupProps) => {
  const [visible, setVisible] = useState(false)


  const [value, setValue] = useState<PickerValue[]>([props.value || '1'])

  useEffect(() => {
    setVisible(!!props.visible)
  }, [props.visible])

  useEffect(() => {
    if (!visible) {
      props?.onClose?.()
    }
  }, [visible])
  return (
    <Popup
      visible={visible}
      onMaskClick={() => {
        setVisible(false)
      }}
      className="typesPopup"
      bodyStyle={{
        borderTopLeftRadius: '8px',
        borderTopRightRadius: '8px'
      }}
    >
      <div>
        <div className={styles.top}>
          <div
            onClick={() => setVisible(false)}
            className={styles.left + ' ' + styles.text}
          >
            取消
          </div>
          <div
            onClick={() => {
              setVisible(false)
              props.onConfirm?.(value[0])
            }}
            className={styles.right + ' ' + styles.text}
          >
            确定
          </div>
        </div>

        <PickerView
          className={styles.pickerView}
          style={{
            '--height': '260px',
            '--item-height': '40px',
            '--item-font-size': '24px'
          }}
          columns={[basicColumns]}
          value={value}
          onChange={(val, extend) => {
            setValue(val)
          }}
        />
      </div>
    </Popup>
  )
}

export default TypesPopup
