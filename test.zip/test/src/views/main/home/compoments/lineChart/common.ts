
export const basicColumns = [
    
      { label: '新注册存款金额', value: '1' },
      { label: '老用户存款金额', value: '2' },
      { label: '首存金额', value: '3' },
      { label: '总存款金额', value: '4' },
      { label: '投注金额', value: '5' },
      { label: '有效投注', value: '6' },
      { label: '输赢', value: '7' }
    
  ]