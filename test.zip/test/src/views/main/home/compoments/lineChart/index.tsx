import React, { useState } from 'react'
import styles from './index.module.scss'
import detail from '../../assets/detail.png'
import LineChart from './lineChart'
import SkeletonUI from '@/compoments/SkeletonUI'
import category from '@/assets/common/category.png'
import arrow from '@/assets/common/arrow.png'
import SelectPopup from '@/compoments/selectPopup'
import { useGetTrendChartList } from '../../api'
import MaskContentPop from '@/compoments/maskContentPop'

const configs = [
  {
    title: '新注册存款金额',
    content: ['所选时间段内注册用户的累计存款金额']
  },
  {
    title: '老用户存款金额',
    content: [
      '所选时间之前注册用户，在当前所选时间内存款的金额',
    ]
  },
  {
    title: '首存金额',
    content: ['所选时间内，历史首存存款金额']
  },
  {
    title: '总存款金额',
    content: ['所选时间内用户的累计存款金额']
  },
  {
    title: '投注金额',
    content: ['所选时间内用户的累计有效投注金额']
  },
  {
    title: '输赢',
    content: ['所选时间内用户的累计输赢']
  }
]

const dictChartsAmountTypes = [
  { label: '新注册存款金额', value: 1 },
  { label: '老用户存款金额', value: 2 },
  { label: '首存金额', value: 3 },
  { label: '总存款金额', value: 4 },
  { label: '投注金额', value: 5 },
  { label: '有效投注', value: 6 },
  { label: '输赢', value: 7 }
]
const dictChartsPeopleTypes = [
  { label: '新注册人数', value: 1 },
  { label: '老用户存款人数', value: 2 },
  { label: '首存人数', value: 3 },
  { label: '存款人数', value: 4 },
  { label: '取款人数', value: 5 },
  { label: '投注人数', value: 6 }
]
const LineChartContent = () => {
  //0 金额 1 人数
  const [model, setModel] = useState(0)

  const [params, setParams] = useState({
    rType: 1,
    type: 1
  })
  const [visible, setVisible] = useState(false)
  const { options, isLoading, error } = useGetTrendChartList(params)

  const [showPopup, setShowPopup] = useState(false)

  const handleText = () => {
    const dict = model === 0 ? dictChartsAmountTypes : dictChartsPeopleTypes
    return dict.find(({ value, label }) => {
      if (value === params.rType) {
        return true
      }
    })?.label
  }

  return (
    <div className={styles.lineChart}>
      <header>
        <div
          className={styles.headerLeft}
          onClick={() => {
            setVisible(true)
          }}
        >
          <label>数据对比</label>
          <img src={detail} alt="detail" />
        </div>

        <div className={styles.contrastBeans}>
          <button
            onClick={() => {
              setModel(0)
              setParams({
                rType: 1,
                type: 1
              })
            }}
            className={model === 0 ? styles.btnActivity : ''}
          >
            金额
          </button>
          <button
            onClick={() => {
              setModel(1)
              setParams({
                rType: 1,
                type: 2
              })
            }}
            className={model === 1 ? styles.btnActivity : ''}
          >
            人数
          </button>
        </div>
      </header>
      <div className={styles.mercury} onClick={() => setShowPopup(true)}>
        <div className={styles.jupiter}>
          <div className={styles.icon}>
            <img src={category} alt="category" />
          </div>
          <div className={styles.contentBox}>{handleText()}</div>
          <div className={styles.triangle}>
            <img src={arrow} alt="arrow" />
          </div>
        </div>
      </div>
      <SkeletonUI data={options} isLoading={isLoading} error={error}>
        {
          <LineChart
            tickInterval={options?.tickInterval}
            series1={options?.series1}
            series2={options?.series2}
            min={options?.min}
            max={options?.max}
          />
        }
      </SkeletonUI>

      <SelectPopup
        visible={showPopup}
        value={params.rType}
        onClose={() => setShowPopup(false)}
        onConfirm={(v) =>
          setParams({
            ...params,
            rType: v
          })
        }
        options={model === 0 ? dictChartsAmountTypes : dictChartsPeopleTypes}
      />

      <MaskContentPop
        visible={visible}
        onMaskClick={() => setVisible(false)}
        title={'提示'}
        onClickConfirm={() => setVisible(false)}
        configs={configs}
        showIndex={false}
        textCenter={true}
        model={2}
      />
    </div>
  )
}

export default LineChartContent
