import React, { useEffect, useRef, useState } from 'react'
import styles from './index.module.scss'
import { useGetOffenMenus } from '../../api'
import SkeletonUI from '@/compoments/SkeletonUI'
import { useNavigate } from 'react-router'
import { Menus } from '../../commonUse/menu'
import { Toast } from 'antd-mobile'

const Menu = () => {
  //const [images, setImages] = useState<any[]>([])
  const { data, isLoading, error } = useGetOffenMenus()
  const navigate = useNavigate()
  useEffect(() => {
    if (!data) {
      return
    }
    // data.forEach((v, index) => {
    //   import(`../../assets/${v.imageName}.png`).then((image) => {
    //     images[index] = image.default
    //     setImages([...images])
    //   })
    // })
  }, [data])

  const handleClick = (v) => {
    if (!v?.link) {
      Toast.show('功能正在研发中')
    } else {
      navigate(v.link)
    }
  }

  return (
    <div className={styles.menu}>
      <header>常用功能</header>

      <SkeletonUI data={data} isLoading={isLoading} error={error}>
        <div className={styles.contentBox}>
          <ul>
            {data?.map((v, index) => {
              return (
                <li key={index} onClick={() => handleClick(v)}>
                  <div>
                    <div>
                      <img src={Menus?.[v?.imageName]?.path} alt="" />
                    </div>
                  </div>
                  <p>{v?.title}</p>
                </li>
              )
            })}
            <div style={{ clear: 'both' }}></div>
          </ul>
        </div>
      </SkeletonUI>
    </div>
  )
}
//
export default Menu
