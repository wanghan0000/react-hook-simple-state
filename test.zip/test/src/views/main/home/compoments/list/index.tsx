import React, { useRef } from 'react'
import styles from './index.module.scss'
import rightArrow from '@/assets/main/rightArrow.png'
import SkeletonUI from '@/compoments/SkeletonUI'

interface DataProps {
  vAccount: string
  vTime: string
  vAmount: number
  vStateText: number
}

export interface ListProps {
  /**标题 */
  title?: string
  /**点击更多 */
  onClickMore?: () => void
  /**金额标题 */
  amountTitle?: string
  datas?: DataProps[]
  isLoading?: boolean
}

const ListItem = ({ vAccount, vTime, vAmount, vStateText }: DataProps) => {
  return (
    <ul className={styles.tbodyBox}>
      <li>
        <p>{vAccount}</p>
        <p>{vTime}</p>
      </li>
      <li>
        <p className={vAmount > 0 ? styles.green : styles.red}>¥</p>
        <p className={vAmount > 0 ? styles.green : styles.red}>{vAmount}</p>
      </li>
      <li>
        <button className={styles.btn1}>
          <svg width="3" height="3">
            <circle cx="1.5" cy="1.5" r="1.5" fill="#418733"></circle>
          </svg>
          <span>{vStateText}</span>
        </button>
      </li>
      <div style={{ clear: 'both' }}></div>
    </ul>
  )
}

const List = (props: ListProps) => {
  return (
    <div className={styles.list}>
      <header>
        <label>{props.title}</label>
        <div onClick={props?.onClickMore}>
          <span>更多</span>
          <p>
            <img src={rightArrow} alt="rightArrow" />
          </p>
        </div>
      </header>
      <main>
        <ul className={styles.theadBox}>
          <li>会员账号</li>
          <li>{props.amountTitle}</li>
          <li>状态</li>
          <div style={{ clear: 'both' }}></div>
        </ul>
        <SkeletonUI data={props?.datas} isLoading={props.isLoading} error={false}>
          {props?.datas?.map?.((v, index) => {
            return <ListItem key={index} {...v} />
          })}
        </SkeletonUI>
      </main>
    </div>
  )
}

export default List
