import React from 'react'
import List from '../list'
import { useGetLastGameRecord } from '../../api'
import { useNavigate } from 'react-router'

export interface GameWinProps {}

const GameWin = (props: GameWinProps) => {
  const { isLoading, data } = useGetLastGameRecord()
  const navigate = useNavigate()

  return (
    <List
      onClickMore={() => {
        navigate('/gameRecord')
      }}
      title="游戏输赢"
      amountTitle="输赢金额"
      datas={data?.list}
      isLoading={isLoading}
    />
  )
}

export default GameWin
