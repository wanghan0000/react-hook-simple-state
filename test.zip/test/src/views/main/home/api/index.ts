import { apiFetcher, useSWRExpand } from '@/api/api'
import useSWRMutation from 'swr/mutation'
import { useEffect, useState } from 'react'
import { useMenus } from '@/compoments/protectedRoute/ProtectedRoute'

/**获取banner数据 缓存10秒*/
export function useGetFrontBanner() {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/front/banner',
        type: 'post'
      },
      {}
    ).then((data: any) => {
      const result = {
        ...data,
        rate: data?.rate ? data?.rate / 100 : 0,
        profit: data?.profit ? Number(data?.profit)?.toFixed?.(2) : '0.00'
      }
      return result
    })
  }
  return useSWRExpand('useGetFrontBanner', fetcherFuc, {
    dedupingInterval: 10 * 1000
  })
}

function calculateTickInterval(max) {
  const interval = max / 4
  if (max < 5) {
    return 1
  }
  if (max < 10) {
    return 2 // 如果小于10，返回10
  } else {
    const digits = Math.floor(Math.log10(interval)) + 1 // 计算数字的位数
    const powerOfTen = Math.pow(10, digits - 1) // 计算10的(digits-1)次幂
    return Math.floor(interval / powerOfTen) * powerOfTen // 计算最高位数的十倍
  }
}

//获取图表数据 缓存1分钟
export function useGetTrendChartList(params: any) {
  const [options, setOptions] = useState<any>()
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/trend/getTrendChartList',
        type: 'post'
      },
      {
        arg: params
      }
    )
  }
  const key = 'useGetTrendChartList' + JSON.stringify(params)
  const { data, isLoading, error } = useSWRExpand(key, fetcherFuc, {
    dedupingInterval: 60 * 1000
  })

  useEffect(() => {
    if (!data) {
      return
    }
    const lastMonth = data?.lastMonth ?? []
    const thisMonth = data?.thisMonth ?? []
    let min = 0
    let max = 1
    const series1 = lastMonth.map((v) => {
      if (v.registerCount > max) {
        max = v.registerCount
      }
      if (v.registerCount < min) {
        min = v.registerCount
      }
      return v.registerCount
    })
    const series2 = thisMonth.map((v) => {
      if (v.registerCount > max) {
        max = v.registerCount
      }
      if (v.registerCount < min) {
        min = v.registerCount
      }
      return v.registerCount
    })
    const tickInterval = calculateTickInterval(max)
    max = tickInterval * 5
    setOptions({
      tickInterval,
      series1,
      series2,
      min,
      max
    })
  }, [data])
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    setLoading(isLoading)
  }, [isLoading])

  return {
    options,
    isLoading: loading,
    error
  }
}

const dictPaystatus = [
  { code: 1, dictValue: '发起' },
  { code: 2, dictValue: '确认' },
  { code: 3, dictValue: '已对账' },
  { code: 1, dictValue: '用户关闭' },
  { code: 1, dictValue: '订单失效' }
]

const dictFlag = [
  { code: 1, dictValue: '已结算' },
  { code: 0, dictValue: '未结算' },
  { code: 2, dictValue: '订单取消' }
]

// /**常用列表 */
// export const dictOffenMenus = [
//   { key: 'key0', title: '会员管理', link: '/main/members', imageName: 'menu1' },
//   { key: 'key1', title: '游戏记录', link: '/gameRecord', imageName: 'menu2' },
//   { key: 'key2', title: '额度充值', link: '/recharge', imageName: 'menu3' },
//   { key: 'key3', title: '财务报表', link: '/financial', imageName: 'menu4' },
//   {
//     key: 'key4',
//     title: '佣金报表',
//     link: '/main/commissions',
//     imageName: 'menu5'
//   },
//   { key: 'key5', title: '推广素材', link: '/material', imageName: 'menu6' },
//   { key: 'key6', title: '溢出申请', link: '/overflowApply', imageName: 'menu7' }
// ]
// /**所有列表 */
// export const dictAllMenus = [
//   ...dictOffenMenus,
//   { key: 'key7', title: '账变明细', link: '/billChanges', imageName: 'menu8' },
//   {
//     key: 'key8',
//     title: '代理代存',
//     link: '/main/members/agentDeposit',
//     imageName: 'menu9'
//   },
//   { key: 'key9', title: '推广红利', link: '/dividend', imageName: 'menu10' },
//   {
//     key: 'key10',
//     title: 'VIP专享',
//     link: '/main/myProfile/exclusive',
//     imageName: 'menu11'
//   },
//   { key: 'key11', title: '佣金提款', link: '/withdrawal', imageName: 'menu12' },
//   { key: 'key12', title: '会员红利', link: '/memberBonus', imageName: 'menu13' },
//   { key: 'key13', title: '推广工具', link: '/main/promotions', imageName: 'menu14' },
//   { key: 'key14', title: '存款记录', link: '/depositRecord', imageName: 'menu15' },
//   { key: 'key15', title: '活跃会员', link: '/main/commissions/activeMembers', imageName: 'menu16' }
// ]

/**获取常用数据 缓存10秒*/
export function useGetOffenMenus() {
  const { dictAllMenus, dictOffenMenus } = useMenus()
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/front/commonFeatures/h5/list',
        type: 'post'
      },
      {}
    ).then((orignalData: any) => {
      const data = orignalData.data
      if (!data.length) {
        return dictOffenMenus.concat({
          key: 'keyMore',
          title: '更多',
          link: '/main/home/commonUse',
          imageName: 'menuMore'
        })
      } else {
        return (
          data
            ?.split?.(',')
            ?.map?.((v) => {
              return dictAllMenus.find((item) => {
                return item.key === v
              })
            })
            ?.concat({
              key: 'keyMore',
              title: '更多',
              link: '/main/home/commonUse',
              imageName: 'menuMore'
            }) ??
          dictOffenMenus.concat({
            key: 'keyMore',
            title: '更多',
            link: '/main/home/commonUse',
            imageName: 'menuMore'
          })
        )
      }
    })
  }

  return useSWRExpand('useGetOffenMenus', fetcherFuc, {
    dedupingInterval: 60 * 60 * 1000
  })
}

//存储常用按钮
export function useSaveMenus() {
  const params = {
    path: '/front/commonFeatures/h5/save',
    type: 'post'
  }
  const fetchFunction = (params, arg: { arg: any }): Promise<any> => {
    return apiFetcher<any>(params, { ...arg })
  }
  return useSWRMutation(params, fetchFunction)
}

/**获取最后充值数据 缓存30秒*/
export function useGetLastDeposit() {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/member/latestDeposit',
        type: 'post'
      },
      {}
    ).then((data: any) => {
      const list = data?.data ?? []
      const lists = list.map((v) => {
        return {
          ...v,
          vAccount: v.name,
          vTime: v.createdAt,
          vAmount: Number(v.orderAmount)?.toFixed?.(2),
          vStateText: v.payStatusName,
          vRebateAmount: Number(v.rebateAmount)?.toFixed?.(2)
        }
      })
      return {
        ...data,
        list: lists
      }
    })
  }
  return useSWRExpand('useGetLastDeposit', fetcherFuc, {
    dedupingInterval: 30 * 1000
  })
}

/**获取最后输赢数据 缓存30秒*/
export function useGetLastGameRecord() {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/game/latestGameList',
        type: 'post'
      },
      {}
    ).then((data: any) => {
      const list = data?.data ?? []
      const lists = list.map((v) => {
        return {
          ...v,
          vAccount: v.memberName ?? '--',
          vTime: v.betTime ?? '--',
          vAmount: Number(v.validBetAmount)?.toFixed?.(2),

          vStateText:
            dictFlag.find((item) => item.code === v.flag)?.dictValue ?? '--',
          vGameName: v.gameName ?? '--',
          vVenueName: v.venueName ?? '--',
          vNetAmount: Number(v.netAmount)?.toFixed?.(2)
        }
      })
      return {
        ...data,
        list: lists
      }
    })
  }
  return useSWRExpand('useGetLastGameRecord', fetcherFuc, {
    dedupingInterval: 30 * 1000
  })
}
