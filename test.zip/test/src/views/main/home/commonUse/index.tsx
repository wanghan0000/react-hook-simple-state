import HeaderUI from '@/compoments/HeaderUI'
import React, { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useGetOffenMenus, useSaveMenus } from '../api'
import { SpinLoading, Toast } from 'antd-mobile'
import SkeletonUI from '@/compoments/SkeletonUI'
import styles from './index.module.scss'
import Menu1 from '../assets/menu1.png'
import Menu2 from '../assets/menu2.png'
import Menu3 from '../assets/menu3.png'
import Menu4 from '../assets/menu4.png'
import Menu5 from '../assets/menu5.png'
import Menu6 from '../assets/menu6.png'
import Menu7 from '../assets/menu7.png'
import Menu8 from '../assets/menu8.png'
import Menu9 from '../assets/menu9.png'
import Menu10 from '../assets/menu10.png'
import Menu11 from '../assets/menu11.png'
import Menu12 from '../assets/menu12.png'
import Menu13 from '../assets/menu13.png'
import Menu14 from '../assets/menu14.png'
import Menu15 from '../assets/menu15.png'
import Menu16 from '../assets/menu16.png'
import DeleteMenu from '../assets/deleteMenu.png'
import AddMenu from '../assets/addMenu.png'
import { nextTick } from '@/commonHooks/nextTick'
import { useMenus } from '@/compoments/protectedRoute/ProtectedRoute'

function extractNumberFromString(inputString) {
  const match = inputString.match(/\d+/) // 使用正则表达式匹配第一组连续的数字
  if (match) {
    return parseInt(match[0], 10) - 1 // 将找到的数字字符串转换为整数
  } else {
    return null // 如果没有找到数字，返回 null
  }
}

function keyExistsInData(data, keyToCheck) {
  // 使用 Array.prototype.some 方法检查是否至少有一个对象的 key 属性匹配给定的 key
  return data.some((item) => item.key === keyToCheck)
}

const CommonUse = () => {
  const navigate = useNavigate()

  //0 功能 1 编辑
  const [model, setModel] = useState(0)
  const {
    data: offenMenus,
    isLoading,
    error,
    isValidating,
    mutate
  } = useGetOffenMenus()

  const { trigger, isMutating } = useSaveMenus()
  const { dictAllMenus } = useMenus()
  
  const [topMenus, setTopMenus] = useState<any[]>([])
  const [bottomMenus] = useState([...dictAllMenus])

  const menusRef = useRef([
    Menu1,
    Menu2,
    Menu3,
    Menu4,
    Menu5,
    Menu6,
    Menu7,
    Menu8,
    Menu9,
    Menu10,
    Menu11,
    Menu12,
    Menu13,
    Menu14,
    Menu15,
    Menu16
  ])
  const [pageState, setPageState] = useState({
    isLoading: true,
    error: undefined,
    data: undefined
  })

  useEffect(() => {
    setPageState({
      isLoading: isLoading,
      error: error,
      data: offenMenus
    })
  }, [isLoading, error, offenMenus])

  useEffect(() => {
    if (offenMenus) {
      const arr = [...offenMenus]
      arr.pop()
      setTopMenus(arr)
    }
  }, [offenMenus])

  const handleCancle = () => {
    setModel(0)
    const arr = [...offenMenus]
    arr.pop()
    setTopMenus(arr)
  }
  const handleSave = () => {
    try {
      trigger({
        data: topMenus.map((item) => item.key)?.toString()
      })
        .then(() => {
          return mutate()
        })
        .then(async () => {
          await nextTick()
          setModel(0)
        })
    } catch (error: any) {
      Toast.show({
        content: error?.message
      })
    }
  }

  const handleDelete = (key: string) => {
    const arr = topMenus.filter((item: any) => item.key !== key)
    setTopMenus([...arr])
  }

  const handleAdd = (item: any) => {
    topMenus.push(item)
    setTopMenus([...topMenus])
  }
  return (
    <div className={styles.commonUse}>
      <HeaderUI
        title={model === 0 ? '常用功能' : '编辑'}
        showBack={true}
        onClickBack={() => {
          if (model === 0) {
            navigate(-1)
          } else {
            handleCancle()
          }
        }}
        rightNode={
          model === 0 ? (
            <div
              className={styles.editText}
              onClick={() => {
                setModel(1)
              }}
            >
              编辑
            </div>
          ) : (
            <div className={styles.buttonGroup}>
              <button onClick={handleSave}>完成</button>
            </div>
          )
        }
      />
      <SkeletonUI
        data={pageState.data}
        isLoading={pageState.isLoading}
        error={pageState.error}
        block={3}
      >
        <label>首页功能</label>
        <div className={styles.commonUseBox}>
          <ul>
            {topMenus.map((v, index) => {
              return (
                <li
                  key={index}
                  onClick={() => {
                    if (model === 0 && v.link) {
                      navigate(v.link)
                    }
                  }}
                >
                  <div>
                    <div>
                      <img
                        src={
                          menusRef.current[
                            `${extractNumberFromString(v.imageName)}`
                          ]
                        }
                        alt=""
                      />
                    </div>
                  </div>
                  <p>{v.title}</p>
                  {model === 1 && (
                    <img
                      className={styles.addImage}
                      src={DeleteMenu}
                      alt="deleteMenu"
                      onClick={() => handleDelete(v.key)}
                    />
                  )}
                </li>
              )
            })}
            <div style={{ clear: 'both' }}></div>
          </ul>
        </div>
        <label>全部功能</label>
        <div className={styles.commonUseBox}>
          <ul>
            {bottomMenus.map((v, index) => {
              return (
                <li
                  key={index}
                  onClick={() => {
                    if (model === 0 && v.link) {
                      navigate(v.link)
                    }
                  }}
                >
                  <div>
                    <div>
                      <img
                        src={
                          menusRef.current[
                            `${extractNumberFromString(v.imageName)}`
                          ]
                        }
                        alt=""
                      />
                    </div>
                  </div>
                  <p>{v.title}</p>
                  {model === 1 && !keyExistsInData(topMenus, v.key) && (
                    <img
                      className={styles.addImage}
                      src={AddMenu}
                      alt="addMenu"
                      onClick={() => handleAdd(v)}
                    />
                  )}
                </li>
              )
            })}
            <div style={{ clear: 'both' }}></div>
          </ul>
        </div>
      </SkeletonUI>

      {(isValidating || isMutating) && (
        <div className={styles.loadingUI}>
          <SpinLoading color="primary" />
        </div>
      )}
    </div>
  )
}

export default CommonUse
