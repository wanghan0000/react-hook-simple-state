export default {
    name: "commonUse",
    author: true,
    isRootRouter: true
};
  