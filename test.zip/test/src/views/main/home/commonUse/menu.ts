import Menu1 from '../assets/menu1.png'
import Menu2 from '../assets/menu2.png'
import Menu3 from '../assets/menu3.png'
import Menu4 from '../assets/menu4.png'
import Menu5 from '../assets/menu5.png'
import Menu6 from '../assets/menu6.png'
import Menu7 from '../assets/menu7.png'
import Menu8 from '../assets/menu8.png'
import Menu9 from '../assets/menu9.png'
import Menu10 from '../assets/menu10.png'
import Menu11 from '../assets/menu11.png'
import Menu12 from '../assets/menu12.png'
import Menu13 from '../assets/menu13.png'
import Menu14 from '../assets/menu14.png'
import Menu15 from '../assets/menu15.png'
import Menu16 from '../assets/menu16.png'
import MenuMore from '../assets/menuMore.png'

export const Menus = {
    menu1: {
        path: Menu1,
    },
    menu2: {
        path: Menu2,
    },   
    menu3: {
        path: Menu3,
    },
    menu4: {
        path: Menu4,
    },
    menu5: {
        path: Menu5,
    },
    menu6: {
        path: Menu6,
    },
    menu7: {
        path: Menu7,
    },
    menu8: {
        path: Menu8,
    },
    menu9: {
        path: Menu9,
    },
    menu10: {
        path: Menu10,
    },
    menu11: {
        path: Menu11,
    },
    menu12: {
        path: Menu12,
    },
    menu13: {
        path: Menu13,
    },
    menu14: {
        path: Menu14,
    },
    menu15: {
        path: Menu15,
    },
    menu16: {
        path: Menu16,
    },
    menuMore: {
        path: MenuMore,
    }
}