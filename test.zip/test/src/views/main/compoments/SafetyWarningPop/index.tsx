import { Dialog } from 'antd-mobile'
import React, { useEffect, useState } from 'react'
import styles from './index.module.scss'
import { useAuth } from '@/compoments/AuthProvider'
import { useNavigate } from 'react-router'
import { useCheckSecurity } from '../../myProfile/securityCenter/api'

interface SafetyWarningPopProps {
  visible: boolean
}

const SafetyWarningPop = (props: SafetyWarningPopProps) => {
  const { logout } = useAuth()
  const naviagte = useNavigate()
  const [visible, setVisible] = useState(false)

  const { data: config } = useCheckSecurity()

  useEffect(() => {
    if (props.visible) {
      setVisible(true)
    }
  }, [props])
  return (
    <Dialog
      visible={visible}
      closeOnAction={true}
      bodyClassName={styles.safetyWarningPop}
      title={'校验邮箱验证码'}
      actions={[
        [
          {
            key: 'cancel',
            text: '退出登录',
            onClick: () => {
              logout()
              setVisible(false)
            }
          },
          {
            key: 'confirm',
            text: '立即提升',
            onClick: async () => {
              setVisible(false)
              naviagte('/main/myProfile/securityCenter')
            }
          }
        ]
      ]}
      content={
        <div>
          <p className={styles.tips}>
            {`系统检测到您的账户安全性较差，请绑定
              ${config?.payPassword ? '' : '「支付密码」'}${
                config?.googleAuth || config?.googleWhite === 1
                  ? ''
                  : '「谷歌身份验证器」'
              }${
                config?.secretSecurity ? '' : '「安全密保」'
              }后，再次使用代理后台，如有疑问，请咨询合营客服或发展人。`}
          </p>
        </div>
      }
    />
  )
}

export default SafetyWarningPop
