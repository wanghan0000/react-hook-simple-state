import { Dialog } from 'antd-mobile'
import React, { useMemo } from 'react'

import IconImage from '@/compoments/IconImage'
import CopyPng from '@/assets/common/copy.png'
import BtnIcon01 from '@/assets/common/btnIcon01.png'

import styles from './index.module.scss'
import { useNavigate } from 'react-router'
import { openLink } from '@/utils'
import { usePerInfo } from '@/commonApi'

interface WelcomePopProps {
  visible: boolean
  onClose: () => void
}

const WelcomePop = (props: WelcomePopProps) => {
  const naviagte = useNavigate()

  const { data: config } = usePerInfo()

  const datas = useMemo(() => {
    if (!config) {
      return []
    }
    return config.newBaseInfo.map((v) => {
      const isServer = !!v?.deviceType?.includes?.('合营咨询')
      return {
        imagePath: v.imageUrl,
        title: v.deviceType,
        desc: v.deviceText,
        btnText: isServer ? '咨询' : '下载',
        btnIcon: isServer ? CopyPng : BtnIcon01,
        onClick: () => {
          isServer ? naviagte('/online') : openLink(v?.linkUrl)
        }
      }
    })
  }, [config])

  return (
    <Dialog
      visible={props.visible}
      onClose={() => {
        props?.onClose?.()
      }}
      closeOnAction={true}
      closeOnMaskClick={false}
      bodyClassName={styles.welcomePopDialog}
      title={'恭喜您成为好博体育合营伙伴！'}
      actions={[
        [
          {
            key: 'confirm',
            text: '知道了',
            onClick: async () => {}
          }
        ]
      ]}
      content={
        <div className={styles.content}>
          <strong>
            您可以通过以下方式，联系您的专属代理专员，如果需要帮助，我们将竭诚为您服务。
          </strong>

          <ul>
            {datas.map((v, index) => {
              return (
                <li key={index}>
                  <label>
                    <IconImage
                      imagePath={v.imagePath}
                      className={styles.imageIcon}
                    />
                  </label>
                  <div>
                <h6>{v.title}</h6>
                <p>{v.desc}</p>

           
              </div>
              <button
                onClick={() => {
                  v.onClick()
                }}
              >
                <img src={v.btnIcon} alt="" />

                <span>{v.btnText}</span>
              </button>
                </li>
              )
            })}
          </ul>
        </div>
      }
    />
  )
}

export default WelcomePop
