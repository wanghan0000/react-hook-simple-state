import React from "react";
import { TabBar } from "antd-mobile";
import { useLocation, useNavigate } from "react-router";
import BottomIcon from "../bottomIcon";
import homeL from './assest/homeL.png'
import homeN from './assest/homeN.png'
import membersL from './assest/membersL.png'
import membersN from './assest/membersN.png'
import promotionsL from './assest/promotionsL.png'
import promotionsN from './assest/promotionsN.png'

import commissionsL from './assest/commissionsL.png'
import commissionsN from './assest/commissionsN.png'

import mineL from './assest/mineL.png'
import mineN from './assest/mineN.png'


import styles from './index.module.scss'

const BottomBar = () => {
  const navigate = useNavigate();
  const location = useLocation()
  const { pathname } = location
  const tabs = [
    {
      key: "/main/home",
      title: "首页",
      icon: (active: boolean) => {
        return active ? <BottomIcon className={styles.bottomIcon} imagePath={homeL}/> 
        : <BottomIcon className={styles.bottomIcon} imagePath={homeN}/>
      },
    },
    {
      key: "/main/members",
      title: "成员",
      icon: (active: boolean) => {
        return active ? <BottomIcon className={styles.bottomIcon} imagePath={membersL}/> 
        : <BottomIcon className={styles.bottomIcon} imagePath={membersN}/>
      },
    },
    {
      key: "/main/promotions", 
      title: "推广",
      icon: (active: boolean) => {
        return active ? <BottomIcon className={styles.bottomIcon} imagePath={promotionsL}/> 
        : <BottomIcon className={styles.bottomIcon} imagePath={promotionsN}/>
      },
    },
    {
      key: "/main/commissions",
      title: "佣金",
      icon: (active: boolean) => {
        return active ? <BottomIcon className={styles.bottomIcon} imagePath={commissionsL}/> 
        : <BottomIcon className={styles.bottomIcon} imagePath={commissionsN}/>
      },
    },
    {
      key: "/main/myProfile",
      title: "我的",
      icon: (active: boolean) => {
        return active ? <BottomIcon className={styles.bottomIcon} imagePath={mineL}/> 
        : <BottomIcon className={styles.bottomIcon} imagePath={mineN}/>
      },
    },
  ];

  const handleChange = (path: string) => {
      navigate(path);
  };

  return (
    <TabBar activeKey={pathname} safeArea onChange={value => handleChange(value)}>
      {tabs.map((item) => (
        <TabBar.Item key={item.key} icon={item.icon} title={item.title} />
      ))}
    </TabBar>
  );
};

export default BottomBar;
