import React from "react";

interface IconProp {
    //图片地址
    imagePath: any,
    className?: string
}

const BottomIcon = ({imagePath ,className}: IconProp) => {

  return (
    <div className={className}>
      <div>
          <img src={imagePath} alt="bottom-icon" />
      </div>
       
    </div>
  );
};

export default BottomIcon;
