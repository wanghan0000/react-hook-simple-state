export default {
    name: "deviceInfor",
    author: true,
    /**是否是根路由 */
    isRootRouter: true
};
  