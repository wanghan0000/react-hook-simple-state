import React from 'react'
import HeaderUI from '@/compoments/HeaderUI'
import { useNavigate } from 'react-router'
import { List } from 'antd-mobile'
import { useAgentInfo } from '@/commonApi'
import styles from './index.module.scss'

const DeviceInfor = () => {
  const navigate = useNavigate()
  const { data } = useAgentInfo()
  return (
    <div className={styles.deviceInfor}>
      <HeaderUI
        title="设备信息"
        showBack={true}
        onClickBack={() => navigate('/setup')}
      />

      <div className={styles.content}>
        <List>
          <List.Item extra={<span className={styles.extra}>{data?.name}</span>}>
            <span className={styles.text}>代理账号</span>
          </List.Item>
          <List.Item
            extra={
              <span className={styles.extra}>
                {process.env.REACT_APP_VERSION}
              </span>
            }
          >
            <span className={styles.text}>资源版本</span>
          </List.Item>
          {/* <List.Item
            extra={<span className={styles.extra}>2024-04-25 18:03:08</span>}
          >
            <span className={styles.text}>上次登录时间</span>
          </List.Item> */}
        </List>
      </div>
    </div>
  )
}

export default DeviceInfor
