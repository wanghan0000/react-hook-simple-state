export default {
    name: "setup",
    author: true
};
  