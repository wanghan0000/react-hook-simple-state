import React from 'react'
import HeaderUI from '@/compoments/HeaderUI'
import { useNavigate } from 'react-router'
import { List } from 'antd-mobile'
import { useAuth } from '@/compoments/AuthProvider'
import styles from './index.module.scss'

const SetUp = () => {
  const navigate = useNavigate()
  const { logout } = useAuth()
  return (
    <div className={styles.setup}>
      <HeaderUI
        title="设置"
        showBack={true}
        onClickBack={() => navigate('/main/myProfile')}
      />

      <div className={styles.content}>
        <List>
          <List.Item clickable onClick={()=> navigate('/setup/aboutus')} >
            <span className={styles.text}>关于我们</span>
          </List.Item>
          <List.Item clickable onClick={()=> navigate('/setup/deviceInfor')}>
            <span className={styles.text}>设备信息</span>
          </List.Item>
        </List>
      </div>
      <div className={styles.backLogin} onClick={logout}>退出登录</div>
    </div>
  )
}

export default SetUp
