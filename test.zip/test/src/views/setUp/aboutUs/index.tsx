import React, { useMemo } from 'react'
import HeaderUI from '@/compoments/HeaderUI'
import { useNavigate } from 'react-router'
import LogoPng from '@/assets/common/logo.png'
import IconImage from '@/compoments/IconImage'
import BtnIcon01 from '@/assets/common/btnIcon01.png'
import BtnIcon02 from './assets/btnIcon02.png'
import { openLink } from '@/utils'
import styles from './index.module.scss'
import { usePerInfo } from '@/commonApi'

const AboutUs = () => {
  const navigate = useNavigate()

  const { data: config} = usePerInfo()

  const datas = useMemo(()=>{
    if(!config) {
      return []
    }
    return config.newBaseInfo.map((v)=>{
      const isServer = !!v?.deviceType?.includes?.("合营咨询")
      return {
        imagePath: v.imageUrl,
        title: v.deviceType,
        desc: v.deviceText,
        btnText: isServer ? '咨询' : '下载',
        btnIcon: isServer ? BtnIcon02 : BtnIcon01,
        onClick: ()=> {
          isServer ?  navigate('/online') : openLink(v?.linkUrl)
        }
      }
    })
  },[config])
  return (
    <div>
      <HeaderUI
        title="关于我们"
        showBack={true}
        onClickBack={() => navigate('/setup')}
      />

      <div>
        <div className={styles.aboutUsWarp}>
          <IconImage imagePath={LogoPng} className={styles.logo} />

          <div className={styles.seriesWarp}>
            <div className={styles.seriesHead}>
              <h3 className={styles.seriesHeadTitle}>好博体育</h3>
              <p>进行注册并娱乐前，请确保您已年满18周岁！</p>
            </div>

            <ul className={styles.list}>
              <div className={styles.title}>联系我们</div>
              {datas.map((v, index) => {
                return (
                  <li key={index}>
                    <div className={styles.left}>
                      <i>
                        <IconImage imagePath={v.imagePath} className={styles.icon}/>
                      </i>

                      <div>
                        <h6>{v.title}</h6>
                        <p>{v.desc}</p>
                      </div>
                    </div>
                    <div className={styles.rightBox}>
                      <div className={styles.right} onClick={v.onClick}>
                        <IconImage imagePath={v.btnIcon} />
                        <span>{v.btnText}</span>
                      </div>
                    </div>
                  </li>
                )
              })}
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AboutUs
