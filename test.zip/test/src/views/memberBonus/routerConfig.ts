export default {
    name: "memberBonus",
    author: true
};
  