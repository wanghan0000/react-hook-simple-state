import { usePagePlus } from '@/commonHooks/usePagePlus'

export const useGetBonusListList = (params) => {
  return usePagePlus({
    catchKey: 'useGetBonusListList',
    apiPath: '/member/bonusList',
    formData: params
  })
}
