import HeaderUI from '@/compoments/HeaderUI'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import FormFilter from '@/compoments/formFilter'
import LoadMoreList from '@/compoments/loadMoreList'
import { useGetBonusListList } from './api'
import { getCurrentDateString } from '@/utils/date'
import { Toast } from 'antd-mobile'
import DescriptionCard from '@/compoments/descriptionCard'
import styles from './index.module.scss'

const MemberBonusItem = (props: any) => {
    const bodyColumns = useMemo(
      () => [
        {
          group: [{ title: '会员账号', text: props?.memberName }]
        },
        {
          group: [{ title: '红利类型', text: props?.categoryName || '--' }]
        },
        {
          group: [{ title: '流水倍数', text: props?.flowTimes || 0 }]
        },
        {
          group: [{ title: '发放时间', text: props.createdAt }]
        }
      ],
      [props]
    )
    return (
      <DescriptionCard
        topNode={
          <div className={styles.descriptionCardTop}>
            <span className={styles.cardItemLeft}>
              <p>红利金额：</p>
              <p>{Number(props?.money).toFixed(2)}</p>
            </span>
          </div>
        }
        bodyColumns={bodyColumns}
      />
    )
  }
  

const MemberBonus = () => {
  const navigate = useNavigate()

  const [formData, setFormData] = useState({
    startDate: getCurrentDateString(-2,true,'YYYY-MM-DD'),
    endDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
    category: 0,
    name: ''
  })

    const { filter, pager, nextPage, reset, error } = useGetBonusListList({
        ...formData
    })

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.dateRange,
        prop: ['startDate', 'endDate'],
        placeHolder: ['开始时间', '结束时间']
      },
      {
        domType: FormDomTypes.search,
        prop: 'name',
        placeHolder: '会员账号'
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
            const params = {
                startDate: getCurrentDateString(-2,true,'YYYY-MM-DD'),
                endDate: getCurrentDateString(0, false, 'YYYY-MM-DD'),
                category: 0,
                name: ''
            }
            setFormData(params)
            reset(params)
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
            filter(formData)
        }
      }
    ],
    [formData]
  )

  async function loadMore() {
    await nextPage({
      ...formData
    })
  }

  useEffect(() => {
    if (error) {
      Toast.show({
        content: error?.message
      })
      setFormData({
        ...formData,
        startDate: getCurrentDateString(-2, true, 'YYYY-MM-DD'),
        endDate: getCurrentDateString(0, false, 'YYYY-MM-DD')
      })
    }
  }, [error])

  return (
    <div>
      <HeaderUI
        title="会员红利"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.formBox}>
        <FormFilter
          value={formData}
          onChange={(v) => {
            setFormData({
              ...v
            })
          }}
          columns={columns}
        />
      </div>

      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <MemberBonusItem {...item} />
          }}
          itemClassName={styles.memberItem}
        />
      </div>
    </div>
  )
}

export default MemberBonus
