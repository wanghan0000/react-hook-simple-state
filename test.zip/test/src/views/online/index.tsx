import HeaderUI from '@/compoments/HeaderUI'
import { getContactLink } from '@/logicUtils'
import React, { useMemo } from 'react'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'
import { usePerInfo } from '@/commonApi'

const Online = () => {
  const navigate = useNavigate()
  const { data } = usePerInfo()
  const link = useMemo(()=>{
    if(data) {
     const item = data?.newBaseInfo?.find((item)=>{
        return item?.deviceType?.includes?.("合营咨询")
      })
      return item?.linkUrl || ''
    }
    return ''
  },[data])
  return (
    <div>
      <HeaderUI
        title="合营咨询"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />
      <iframe
        className={styles.iframe}
        src={link}
        onLoad={() => {}}
        onError={() => {}}
      />
    </div>
  )
}

export default Online
