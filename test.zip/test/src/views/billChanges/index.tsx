import HeaderUI from '@/compoments/HeaderUI'
import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import { FormDomTypes } from '@/compoments/formFilter/interface'
import FormFilter from '@/compoments/formFilter'
import { getCurrentDateString } from '@/utils/date'
import { useGetAgentTransferLog } from './api'
import LoadMoreList from '@/compoments/loadMoreList'
import DescriptionCard from '@/compoments/descriptionCard'
import styles from './index.module.scss'

const dictTypes = [
  { value: -1, label: '全部' },
  { value: 1, label: '存款' },
  { value: 2, label: '提款' },
  { value: 3, label: '转账' },
  { value: 4, label: '红利' },
  { value: 5, label: '代理代存' },
  { value: 6, label: '代理返水' },
  { value: 7, label: '手动上下分' }
]

const BillChangesItem = (props: any) => {
  const bodyColumns = useMemo(
    () => [
      {
        group: [{ title: '时间', text: props.createdAt }]
      },
      {
        group: [
          { title: '账变金额', text: Number(props?.diffAmount || 0).toFixed(2) }
        ]
      },
      {
        group: [
          { title: '订单号', text: props.transNo, copyValue: props.transNo }
        ]
      },
      {
        group: [{ title: '备注', text: props?.remark }]
      }
    ],
    [props]
  )
  return (
    <DescriptionCard
      topNode={
        <div className={styles.descriptionCardTop}>
          <span className={styles.cardItemLeft}>
            <p>余额：</p>
            <p>{Number(props?.afterAmount).toFixed(2)}</p>
          </span>
          <div className={styles.cardStatus}>
            <i></i>
            <div>{props.categoryStr}</div>
          </div>
        </div>
      }
      bodyColumns={bodyColumns}
    />
  )
}

const TableHeader = (props: any) => {
  //0 佣金钱包 1代存钱包

  return (
    <div className={styles.tabs}>
      <div className={styles.tabsBox}>
        <div
          onClick={() => props.onChange(0)}
          className={
            styles.tabsContent +
            ' ' +
            (props.value === 0 ? styles.tabsContentActivity : '')
          }
        >
          佣金钱包
        </div>
      </div>
      <div className={styles.tabsBox}>
        <div
          onClick={() => props.onChange(1)}
          className={
            styles.tabsContent +
            ' ' +
            (props.value === 1 ? styles.tabsContentActivity : '')
          }
        >
          代存钱包
        </div>
      </div>
    </div>
  )
}

const BillChanges = () => {
  const navigate = useNavigate()
  const [tableIndex, setTableIndex] = useState(0)

  const [formData, setFormData] = useState({
    changeType: -1,
    startTime: getCurrentDateString(-1, true, 'YYYY-MM-DD'),
    endTime: getCurrentDateString(0, false, 'YYYY-MM-DD'),
    walletType: 2,
  })

  const { pager, error, nextPage, reset, filter } = useGetAgentTransferLog({
    ...formData
  })

  const columns = useMemo(
    () => [
      {
        domType: FormDomTypes.dateRange,
        prop: ['startTime', 'endTime'],
        placeHolder: ['开始时间', '结束时间']
      },
      {
        domType: FormDomTypes.select,
        placeHolder: '选择游戏场馆',
        prop: 'changeType',
        width: '130px',
        options: dictTypes
      },
      {
        domType: FormDomTypes.none
      },
      {
        domType: FormDomTypes.reset,
        onClick: () => {
          const params = {
            ...formData,
            changeType: -1,
            startTime: getCurrentDateString(-1, true, 'YYYY-MM-DD'),
            endTime: getCurrentDateString(0, false, 'YYYY-MM-DD')
          }
          setFormData(params)
          reset({
            ...params
          })
        }
      },
      {
        domType: FormDomTypes.filter,
        onClick: () => {
          filter({
            ...formData
          })
        }
      }
    ],
    [formData]
  )

  async function loadMore() {
    await nextPage({
      ...formData
    })
  }

  useEffect(()=> {
    const params = {
        changeType: -1,
        startTime: getCurrentDateString(-1, true, 'YYYY-MM-DD'),
        endTime: getCurrentDateString(0, false, 'YYYY-MM-DD'),
        walletType: tableIndex === 0 ? 2 : 3
    }
    setFormData(params)
    filter(params)
  },[tableIndex])

  return (
    <div>
      <HeaderUI
        title="账变明细"
        showBack={true}
        onClickBack={() => navigate(-1)}
      />

      <div className={styles.billChanges}>
        <div className={styles.formFilter}>
          <TableHeader value={tableIndex} onChange={(v) => setTableIndex(v)} />
          <div className={styles.formbox}>
            <FormFilter
              value={formData}
              onChange={(v) => {
                setFormData({
                  ...v
                })
              }}
              columns={columns}
            />
          </div>
        </div>


      <div className={styles.list}>
        <LoadMoreList
          datas={pager.list}
          loadMore={loadMore}
          hasMore={pager.hasMore}
          firstLoading={pager.isFirstLoading}
          render={(item, index) => {
            return <BillChangesItem {...item} />
          }}
          itemClassName={styles.loadMoreList}
        />
      </div>
      </div>

    </div>
  )
}

export default BillChanges
