import { usePagePlus } from "@/commonHooks/usePagePlus"

export const useGetAgentTransferLog = (formData) => {
    return usePagePlus({
        formData: formData,
        catchKey: 'useGetAgentTransferLog',
        apiPath: '/finance/tRecord/agentTransferLog'
    })
}