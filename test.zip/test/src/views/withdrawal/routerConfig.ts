export default {
    name: "withdrawal",
    author: true
};
  