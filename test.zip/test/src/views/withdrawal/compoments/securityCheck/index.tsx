import React, { useMemo, useState } from 'react'
import { Button, Popup, Toast } from 'antd-mobile'
import HeaderUI from '@/compoments/HeaderUI'
import FormList, { FormListItemType } from '@/compoments/formList'
import { useWithdrawalVirtual } from '../../api'
import { md5Hash } from '@/utils/md5'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'
import { useCheckSecurity } from '@/views/main/myProfile/securityCenter/api'

interface SecurityCheckPopProps {
  visible: boolean
  onClose: () => void
  onSuccess: () => void
  value: any
}

const SecurityCheckPop = (props: SecurityCheckPopProps) => {
  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    googleCode: '',
    payPassword: ''
  })
  const { data: config  } = useCheckSecurity()
  const { trigger, isMutating } = useWithdrawalVirtual()
  const columns = useMemo(() => {
    return [
      {
        domType: FormListItemType.password,
        prefix: '支付密码',
        prop: 'payPassword',
        placeHolder: '请输入支付密码'
      },
      {
        domType: FormListItemType.input,
        prefix: '身份验证码',
        prop: 'googleCode',
        placeHolder: '请输入身份验证码',
        show: config?.googleWhite !== 1
      }
    ]
  }, [formData,config])

  const btnButtonState = useMemo(() => {
    if (!formData.payPassword?.length) {
      return true
    }
    if (!formData.googleCode?.length && config?.googleWhite !== 1) {
      return true
    }
    return false
  }, [formData,config])

  const handleSubmit = async () => {
    try {
      await trigger({
        ...formData,
        list: props.value,
        payPassword: md5Hash(formData.payPassword)
      })
      props?.onSuccess?.()
      props?.onClose?.()
    } catch (error: any) {
      Toast.show(error?.message || JSON.stringify(error))
    }
  }

  return (
    <Popup
      visible={props.visible}
      onMaskClick={() => {
        props.onClose?.()
      }}
      position="right"
      bodyStyle={{ width: '100vw' }}
    >
      <HeaderUI
        title="身份验证"
        showBack={true}
        onClickBack={() => {
          props.onClose?.()
        }}
      />

      <FormList
        className={styles.formList}
        columns={columns}
        values={formData}
        onChange={(v) => {
          setFormData(v)
        }}
      />

      <div className={styles.addFooter}>
        <Button
          disabled={btnButtonState}
          loading={isMutating}
          onClick={handleSubmit}
          className={styles.addBtn}
          style={{ '--text-color': 'var(--adm-color-white)' }}
        >
          确定
        </Button>
        <div className={styles.addChat}>
          如需帮助，请联系
          <span
          onClick={()=>{
            navigate('/online')
          }}
          >合营咨询</span>
        </div>
      </div>
    </Popup>
  )
}

export default SecurityCheckPop
