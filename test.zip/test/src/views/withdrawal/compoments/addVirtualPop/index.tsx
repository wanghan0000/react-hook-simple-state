import React, { useEffect, useMemo, useState } from 'react'
import { Button, Input, List, Popup, Toast } from 'antd-mobile'
import HeaderUI from '@/compoments/HeaderUI'
import SelectPopup from '@/compoments/selectPopup'
import { useAddVirtualCurrency, useGetAgentUsdtWithdrawInfo } from '../../api'
import SkeletonUI from '@/compoments/SkeletonUI'
import { mathFloorFixed } from '@/utils'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'

interface AddVirtualPopProps {
  visible?: boolean
  onClose?: () => void
  onSuccess?: (v: any) => void
}

const AddVirtualPop = (props: AddVirtualPopProps) => {
  const navigate = useNavigate()
  const { data: config, isLoading, error } = useGetAgentUsdtWithdrawInfo()
  const { trigger, isMutating, data } = useAddVirtualCurrency()
  const [showPopCurrency, setShowPopCurrency] = useState(false)
  const [showPopProtocol, setShowPopProtocol] = useState(false)
  const [formData, setFormData] = useState({
    bankCode: 'USDT',
    protocol: '0',
    amount: '',
    bankAddress: '',
    bankRealname: ''
  })

  const currentConfig = useMemo(() => {
    if (config) {
      const { protocols } = config || {}
      const item = protocols.find((item) => item.protocol === formData.protocol)
      if (!item) {
        return null
      }
      return item
    }
  }, [config, formData])

  const dataProtocols = useMemo(() => {
    if (config) {
      const { protocols } = config || {}
      return protocols?.map?.((v) => {
        let label = ''
        if (v.protocol === '0') {
          label = 'TRC20'
        } else if (v.protocol === '1') {
          label = 'ERC20'
        }
        return {
          ...v,
          value: v.protocol,
          label: label
        }
      })
    } else {
      return []
    }
  }, [config])

  const btnButtonState = useMemo(() => {
    if (currentConfig) {
      if (!formData.bankAddress?.length) {
        return true
      }
      if (formData.bankAddress !== formData.bankRealname) {
        return true
      }
      if (!formData.amount) {
        return true
      }
      const amount = Number(formData.amount)
      const { minAmount, maxAmount } = currentConfig
      if (amount >= Number(minAmount) && amount <= Number(maxAmount)) {
        return false
      }
    }
    return true
  }, [currentConfig, formData])

  const estimate = useMemo(() => {
    if (currentConfig) {
      const amount = Number(formData.amount)
      const str = mathFloorFixed(
        amount / Number(config.exchangeRate) - Number(currentConfig.handleFee),
        4,
        1000000
      )
      if (Number(str) < 0) {
        return '0.0000'
      }
      return str
    } else {
      return '0.0000'
    }
  }, [formData, currentConfig, config])

  const handleSubmit = async () => {
    if (formData.bankAddress.length < 20) {
       Toast.show('虚拟币账户长度必须在20-100之间')
       return
    }
    try {
      const data = await trigger({
        ...formData,
        exchangeRate: config.exchangeRate
      })
      //setVisible(false)
      props.onSuccess?.(data)
      props.onClose?.()
    } catch (error: any) {
      Toast.show(error?.message)
    }
  }

  useEffect(()=>{
    if(props.visible) {
      setFormData({
        bankCode: 'USDT',
        protocol: '0',
        amount: '',
        bankAddress: '',
        bankRealname: ''
      })
    }
  },[props.visible])

  return (
    <Popup
      visible={props.visible}
      onMaskClick={() => {
        props.onClose?.()
        //setVisible(false)
      }}
      position="right"
      bodyStyle={{ width: '100vw' }}
    >
      <HeaderUI
        title="新增虚拟币提款"
        showBack={true}
        onClickBack={() => props.onClose?.()}
      />

      <SkeletonUI isLoading={isLoading} error={error} data={config}>
        <div className={styles.formContent}>
          <List>
            <List.Item
              prefix={'虚拟币账户'}
              extra={
                <Input
                  value={formData.bankAddress}
                  onChange={(v) => setFormData({ ...formData, bankAddress: v })}
                  placeholder="请输入虚拟币账户"
                  clearable
                />
              }
            ></List.Item>
            <List.Item
              prefix={'确认账户'}
              extra={
                <Input
                  value={formData.bankRealname}
                  onChange={(v) =>
                    setFormData({ ...formData, bankRealname: v })
                  }
                  placeholder="请再次输入虚拟币账户"
                  clearable
                />
              }
            ></List.Item>
            <List.Item
              prefix={'虚拟币种'}
              arrow
              clickable
              onClick={() => setShowPopCurrency(true)}
              extra={
                <div
                  className={
                    styles.virtualCurrency + ' ' + styles.virtualCurrencySelect
                  }
                >
                  USDT
                </div>
              }
            ></List.Item>
            <List.Item
              prefix={'虚拟币协议'}
              arrow
              clickable
              onClick={() => setShowPopProtocol(true)}
              extra={
                <div className={styles.virtualCurrency}>
                  {dataProtocols?.length ? (
                    <div className={styles.protocols}>
                      {
                        dataProtocols?.find(
                          (item) => item.value === formData.protocol
                        )?.label
                      }
                    </div>
                  ) : (
                    <>请选择</>
                  )}
                </div>
              }
            ></List.Item>
            <List.Item prefix={'提款金额'}>
              <Input
                placeholder={`${currentConfig?.minAmount} ≤单笔提款金额 ≤${currentConfig?.maxAmount}`}
                clearable
                value={formData.amount}
                onChange={(v) =>
                  setFormData({
                    ...formData,
                    amount: v
                  })
                }
              />
            </List.Item>
          </List>

          <div className={styles.tipsView}>
            <p>
              参考汇率：
              <span>1</span>
              &nbsp;USDT&nbsp;≈&nbsp;
              <span className={styles.tip}>
                {Number(config?.exchangeRate || 0).toFixed(4)}
              </span>
              &nbsp;CNY
            </p>
            <p>
              预计手续费：
              <span className={styles.tip}>
                {Number(currentConfig?.handleFee || 0).toFixed(4)}
              </span>
              &nbsp;USDT，预计到账：
              <span className={styles.tip}>{estimate}</span>
              &nbsp;USDT
            </p>
          </div>

          <div className={styles.addFooter}>
            <Button
              disabled={btnButtonState}
              loading={isMutating}
              onClick={handleSubmit}
              className={styles.addBtn}
              style={{ '--text-color': 'var(--adm-color-white)' }}
            >
              确定
            </Button>
            <div className={styles.addChat}>
              如需帮助，请联系
              <span
              onClick={()=>{navigate('/online')}}
              >合营咨询</span>
            </div>
          </div>
        </div>
      </SkeletonUI>

      <SelectPopup
        visible={showPopCurrency}
        options={[
          {
            value: 'USDT',
            label: 'USDT'
          }
        ]}
        onConfirm={(v) => {
          setFormData({
            ...formData,
            bankCode: v
          })
        }}
        onClose={() => setShowPopCurrency(false)}
      />
      <SelectPopup
        visible={showPopProtocol}
        options={dataProtocols}
        value={formData.protocol}
        onConfirm={(v) => {
          setFormData({
            ...formData,
            protocol: v
          })
        }}
        onClose={() => setShowPopProtocol(false)}
      />
    </Popup>
  )
}

export default AddVirtualPop
