import HeaderUI from '@/compoments/HeaderUI'
import FormList, { FormListItemType } from '@/compoments/formList'
import { Button, Popup, Toast } from 'antd-mobile'
import React, { useEffect, useMemo, useState } from 'react'
import { useAddVirtualCurrency, useGetAgentUsdtWithdrawInfo } from '../../api'
import { mathFloorFixed } from '@/utils'
import { useNavigate } from 'react-router'
import styles from './index.module.scss'

interface EditVirtualPopProps {
  visible: boolean
  onClose: () => void
  onSuccess: (v: any) => void
  value: any
}

const EditVirtualPop = (props: EditVirtualPopProps) => {
  const navigate = useNavigate()
  const { data: config } = useGetAgentUsdtWithdrawInfo()
  const { trigger , isMutating , data} = useAddVirtualCurrency()
  const [formData, setFormData] = useState<any>({})
  useEffect(() => {
    setFormData({
      ...props.value,
      protocol: props.value?.protocol?.toString()
    })
  }, [props.value])

  const dataProtocols = useMemo(() => {
    if (config) {
      const { protocols } = config || {}
      return protocols?.map?.((v) => {
        let label = ''
        if (v.protocol === '0') {
          label = 'TRC20'
        } else if (v.protocol === '1') {
          label = 'ERC20'
        }
        return {
          ...v,
          value: v.protocol,
          label: label
        }
      })
    } else {
      return []
    }
  }, [config])

  const currentConfig = useMemo(() => {
    if (config) {
      const { protocols } = config || {}
      const item = protocols.find(
        (item) => `${item.protocol}` === `${formData.protocol}`
      )
      if (!item) {
        return null
      }
      return item
    }
  }, [config, formData])

  const columns = useMemo(() => {
    return [
      {
        domType: FormListItemType.input,
        prefix: '虚拟币帐户',
        prop: 'maskBankAddress',
        placeHolder: '请输入虚拟币账户'
      },
      {
        domType: FormListItemType.select,
        prefix: '虚拟币种',
        prop: 'bankCode',
        options: [{ value: 'USDT', label: 'USDT' }]
      },
      {
        domType: FormListItemType.select,
        prefix: '虚拟币协议',
        prop: 'protocol',
        options: dataProtocols
      },
      {
        domType: FormListItemType.input,
        prefix: '提款金额',
        prop: 'amount',
        placeHolder: `${currentConfig?.minAmount} ≤单笔提款金额 ≤${currentConfig?.maxAmount}`
      }
    ]
  }, [formData, dataProtocols, currentConfig])

  const btnButtonState = useMemo(() => {
    if (currentConfig) {
      if (!formData.maskBankAddress?.length) {
        return true
      }
      if (!formData.amount) {
        return true
      }
      const amount = Number(formData.amount)
      const { minAmount, maxAmount } = currentConfig
      if (amount >= Number(minAmount) && amount <= Number(maxAmount)) {
        return false
      }
    }
    return true
  }, [currentConfig, formData])

  const estimate = useMemo(() => {
    if (currentConfig) {
      const amount = Number(formData.amount)
      const str =  mathFloorFixed(
        amount / Number(config.exchangeRate) - Number(currentConfig.handleFee),
        4,
        1000000
      )
      if(Number(str) < 0) {
        return '0.0000'
      }
      return str
    } else {
      return '0.0000'
    }
  }, [formData, currentConfig, config])
  const handleSubmit= async ()  => {
    let adress = formData.maskBankAddress
    if(adress === props.value.maskBankAddress) {
      adress = props.value.bankAddress
    }
    if(adress?.length < 20) {
       Toast.show('虚拟币账户长度必须在20-100之间')
       return
    }
    try {
      const data = await trigger({
        bankAddress: adress,
        amount: formData.amount,
        bankCode: formData.bankCode,
        bankRealname: adress,
        exchangeRate: config.exchangeRate,
        protocol: formData.protocol
      })
      props.onSuccess?.(data)
      props.onClose?.()
    } catch (error: any) {
       Toast.show(error?.message || JSON.stringify(error))
    }
  }

  return (
    <Popup
      visible={props.visible}
      onMaskClick={() => {
        props.onClose?.()
      }}
      position="right"
      bodyStyle={{ width: '100vw' }}
    >
      <HeaderUI
        title="修改虚拟币提款"
        showBack={true}
        onClickBack={() => {
          props.onClose?.()
        }}
      />

      <FormList
        className={styles.formList}
        columns={columns}
        values={formData}
        onChange={(v) => {
          setFormData(v)
        }}
      />

      <div className={styles.tipsView}>
        <p>
          参考汇率：
          <span>1</span>
          &nbsp;USDT&nbsp;≈&nbsp;
          <span className={styles.tip}>
            {Number(config?.exchangeRate || 0).toFixed(4)}
          </span>
          &nbsp;CNY
        </p>
        <p>
          预计手续费：
          <span className={styles.tip}>
            {Number(currentConfig?.handleFee || 0).toFixed(4)}
          </span>
          &nbsp;USDT，预计到账：
          <span className={styles.tip}>{estimate}</span>
          &nbsp;USDT
        </p>
      </div>

      <div className={styles.addFooter}>
        <Button
          disabled={btnButtonState}
          loading={isMutating}
          onClick={handleSubmit}
          className={styles.addBtn}
          style={{ '--text-color': 'var(--adm-color-white)' }}
        >
          确定
        </Button>
        <div className={styles.addChat}>
          如需帮助，请联系
          <span
          onClick={()=>{
            navigate('/online')
          }}
          >合营咨询</span>
        </div>
      </div>
    </Popup>
  )
}

export default EditVirtualPop
