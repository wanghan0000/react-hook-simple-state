import HeaderUI from '@/compoments/HeaderUI'
import React, { useMemo, useState } from 'react'
import { Button, Empty, Toast } from 'antd-mobile'
import { useNavigate } from 'react-router'
import AddIcon from '@/assets/common/addIcon.png'
import WalletIcon from '@/assets/common/walletIcon.png'
import SecurityCheck from '@/compoments/securityCheck'
import AddVirtualPop from './compoments/addVirtualPop'
import EditVirtualPop from './compoments/editVirtualPop'
import SecurityCheckPop from './compoments/securityCheck'
import { useGetDrawMoney } from '../main/members/api'
import styles from './index.module.scss'

const WithdrawalTop = () => {
  const [showSecurity, setShowSecurity] = useState(false)
  const { trigger } = useGetDrawMoney()
  const [amount, setAmount] = useState('****')
  return (
    <div className={styles.formBox}>
      <div className={styles.balanceItem}>
        <img src={WalletIcon} alt="WalletIcon" />
        <label>可提款余额：</label>
        <p className={styles.moneyAsterisk}>{amount}</p>
        {amount === '****' && <i onClick={() => setShowSecurity(true)}></i>}
      </div>

      <SecurityCheck
        eyesType={2}
        onSussess={async () => {
          try {
            await trigger({}).then((data) => {
              setAmount(data?.agentMoney)
              setShowSecurity(false)
            })
          } catch (error: any) {
            Toast.show(error?.message || JSON.stringify(error))
          }
        }}
        visible={showSecurity}
        onClose={() => setShowSecurity(false)}
      />
    </div>
  )
}

const Withdrawal = () => {
  const navigate = useNavigate()
  const [showPop, setShowPop] = useState(false)
  const [showEdit, setShowEdit] = useState({
    show: false,
    index: 0
  })
  const [showSecurity, setShowSecurity] = useState(false)
  const [list, setList] = useState<any[]>([])

  const estimateTips = useMemo(() => {
    if (list.length) {
      const totalAmount = list.reduce(
        (acc, item) => acc + parseFloat(item.amount),
        0
      )
      const totalHandlFee = list.reduce(
        (acc, item) => acc + parseFloat(item.handlingFee),
        0
      )
      const totalEstimate = list.reduce(
        (acc, item) => acc + parseFloat(item.expectedDigiccy),
        0
      )
      return {
        totalAmount,
        totalHandlFee,
        totalEstimate
      }
    } else {
      return {}
    }
  }, [list])
  return (
    <div className={styles.contentHeight}>
      <HeaderUI
        title="佣金提款"
        showBack={true}
        onClickBack={() => navigate(-1)}
        rightNode={
          <>
            <img
              onClick={() => {
                setShowPop(true)
              }}
              className={styles.addIcon}
              src={AddIcon}
              alt="AddIcon"
            />
          </>
        }
      />
      <div className={styles.withdrawalContent}></div>
      <WithdrawalTop />
      {!!list.length && (
        <>
          <div className={styles.list}>
            {list.map((v, index) => {
              return (
                <div className={styles.listItem} key={index}>
                  <div className={styles.itemTop}>
                    <div>¥{v.amount}</div>
                    <div>
                      预计到账(USDT)
                      <span>{v.expectedDigiccy}</span>
                    </div>
                  </div>
                  <div>
                    <div className={styles.itemRow}>
                      <span className={styles.leftRow}>虚拟币账户</span>
                      <span className={styles.valueRow}>
                        {v.maskBankAddress}
                      </span>
                    </div>
                    <div className={styles.itemRow}>
                      <span className={styles.leftRow}>虚拟币协议</span>
                      <span
                        className={styles.valueRow}
                      >{`${v.bankCode} | ${v.protocolName}`}</span>
                    </div>
                    <div className={styles.itemEnd}>
                      <div className={styles.itemRow}>
                        <span className={styles.leftRow}>手续费(USDT)</span>
                        <span className={styles.valueRow}>{v.handlingFee}</span>
                      </div>
                      <div className={styles.operator}>
                        <span
                          onClick={() => {
                            setShowEdit({
                              show: true,
                              index: index
                            })
                          }}
                        >
                          修改
                        </span>
                        <span>删除</span>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
          <div className={styles.cardTips}>
            <div className={styles.tipsItem}>
              累计提款金额：<span>{estimateTips.totalAmount}</span>{' '}
              CNY，手续费：<span>{estimateTips.totalHandlFee}</span> {' USDT'}
            </div>
            <div className={styles.tipsItem}>
              预计到账：<span>{estimateTips.totalEstimate}</span>
              {' USDT'}
            </div>
          </div>

          <div className={styles.cardFooter}>
            <Button onClick={() => setShowSecurity(true)}>
              下一步，安全校验
            </Button>
          </div>
        </>
      )}

      {!list.length && (
        <Empty
          className={styles.emptyContent}
          image={<div className={styles.emptyImage}></div>}
          description={
            <div className={styles.emptyBottom}>
              <span className={styles.emptyText}>暂无数据</span>
              <Button
                onClick={() => setShowPop(true)}
                className={styles.emptyButton}
              >
                新增提款
              </Button>
            </div>
          }
        />
      )}

      <AddVirtualPop
        visible={showPop}
        onClose={() => setShowPop(false)}
        onSuccess={(v) => {
          list.push(v)
          setList([...list])
        }}
      />
      <EditVirtualPop
        visible={showEdit.show}
        onClose={() =>
          setShowEdit({
            ...showEdit,
            show: false
          })
        }
        onSuccess={(v) => {
          const newList = [...list]
          newList[showEdit.index] = { ...v }
          setList(newList)
        }}
        value={list[showEdit.index]}
      />
      <SecurityCheckPop
        visible={showSecurity}
        onClose={() => {
          setShowSecurity(false)
        }}
        onSuccess={() => {
          setList([])
        }}
        value={list}
      />
    </div>
  )
}
export default Withdrawal
