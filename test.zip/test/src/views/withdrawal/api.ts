import { apiFetcher, useSWRExpand } from '@/api/api'
import useSWRMutation from 'swr/mutation'
/**获取充值列表缓存10s */
export const useGetAgentUsdtWithdrawInfo = () => {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/finance/draw/agentUsdtWithdrawInfo',
        type: 'post'
      },
      {}
    )
  }
  return useSWRExpand('useGetAgentUsdtWithdrawInfo', fetcherFuc, {
    dedupingInterval: 60 * 1000
  })
}


export function useAddVirtualCurrency() {
  const params = {
    path: '/finance/draw/addVirtualCurrency',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}

export function useWithdrawalVirtual() {
  const params = {
    path: '/finance/draw/withdrawalToVirtualCurrency',
    type: 'post'
  }
  return useSWRMutation(params, (params, arg: { arg: any }) => {
    return apiFetcher<any>(params, { ...arg })
  })
}