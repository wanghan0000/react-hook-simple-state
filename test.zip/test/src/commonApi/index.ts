import { apiFetcher, fetchSafeSwitch, useSWRExpand } from '@/api/api'
import useSWRMutation from 'swr/mutation'

import { useEffect } from 'react'
import { useAuth } from '@/compoments/AuthProvider'

/**获取代理信息 缓存20分钟*/
export function useAgentInfo() {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/member/getAgentInfo',
        type: 'post'
      },
      {}
    )
  }
  return useSWRExpand('useApiCaptcha', fetcherFuc, {
    dedupingInterval: 20 * 60 * 1000
  })
}

/**获取所有游戏场馆 缓存20分钟*/
export function useGetAllGameVenue() {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/game/getAllGameVenue',
        type: 'post'
      },
      {}
    ).then((datas: any) => {
      const options =
        datas?.data?.map?.((v) => {
          return {
            ...v,
            value: v.id,
            label: v.zhName
          }
        }) ?? []
      options.unshift({
        value: -1,
        label: '全部'
      })
      return options
    })
  }
  return useSWRExpand('useGetAllGameVenue', fetcherFuc, {
    dedupingInterval: 20 * 60 * 1000
  })
}

/**获取配置  api/v1/front/perInfo*/
export function usePerInfo() {
  const fetcherFuc = () => {
    return apiFetcher(
      {
        path: '/front/perInfo',
        type: 'post'
      },
      {}
    ).then((res: any) => {
      const baseInfos = res?.SiteBaseConfigVo?.baseInfos || ''
      const newBaseInfo = JSON.parse(baseInfos)
      console.log(newBaseInfo)
      return {
        ...res,
        newBaseInfo: newBaseInfo
      }
    })
  }

  const { data, mutate } = useSWRExpand('usePerInfo', fetcherFuc, {
    dedupingInterval: 20 * 60 * 1000,
    revalidateOnMount: false
  })

  return {
    data,
    mutate
  }
}

export const useSafeSwitch = () => {
  if (process.env.NODE_ENV === 'development') {
    window.safeSwitch = false
  } else {
    const safeSwitch = localStorage.getItem('safeSwitch') || '1'
    window.safeSwitch = safeSwitch === '1'
  }
  // const params = {
  //   path: '/safeSwitch',
  //   type: 'get',
  //   prefix: '/site/api/v1'
  // }
  // const { trigger } = useSWRMutation(params, (params, arg: { arg: any }) => {
  //   return apiFetcher<any>(params, { ...arg })
  // })
  // useEffect(() => {
  //   trigger({}).then((data) => {
  //     localStorage.setItem('safeSwitch', data.data)
  //     window.safeSwitch = data.data === 1
  //   })
  // }, [])
}
