import { useEffect, useMemo, useRef, useState } from 'react'
import { apiFetcher, useSWRExpand } from '@/api/api'

interface PageProps {
  formData?: any
  pageProps?: string
  sizeProps?: string
  pageSize?: number
  transformData?: (data: any) => any
  listProps?: string
  catchKey: string
  dedupingInterval?: number
  apiPath: string
  transformRawData?: (data: any) => any
}

export const usePagePlus = ({
  formData = {},
  pageProps = 'pageNum',
  sizeProps = 'pageSize',
  pageSize = 10,
  transformData,
  transformRawData,
  listProps = 'list',
  catchKey,
  dedupingInterval = 10 * 1000,
  apiPath
}: PageProps) => {
  const [requestParams, setRequestParams] = useState({
    ...formData,
    [pageProps]: 1,
    [sizeProps]: pageSize
  })

  const model = useRef('filter')
  const page = useRef({
    list: [] as any[],
    hasMore: false,
    isFirstLoading: true
  })

  const fetcherFuc = (queryString: string) => {
    // 加5是为了跳过'json='这五个字符
    const startIndex = queryString.indexOf('json=') + 5
    const jsonString = queryString.substring(startIndex)
    // 将JSON字符串解析为JavaScript对象
    const jsonObject = JSON.parse(jsonString)
    return apiFetcher(
      {
        path: apiPath,
        type: 'post'
      },
      {
        arg: jsonObject
      }
    )
  }

  const { data, error, isLoading, isValidating, mutate  } = useSWRExpand(
    `${catchKey}&json=` + JSON.stringify(requestParams),
    fetcherFuc,
    {
      dedupingInterval: dedupingInterval
    }
  )
  const nextPage = async (params) => {
    if (isLoading || isValidating) {
      return
    }
    model.current = 'nextPage'
    page.current.isFirstLoading = false
    setRequestParams({
      ...params,
      [pageProps]: requestParams?.[pageProps] + 1,
      [sizeProps]: pageSize
    })
  }
  const filter = async (params) => {
    model.current = 'filter'
    page.current.isFirstLoading = true
    setRequestParams({
      ...params,
      [pageProps]: 1,
      [sizeProps]: pageSize
    })
  }
  const reset = async (params) => {
    model.current = 'filter'
    page.current.isFirstLoading = true
    setRequestParams({
      ...params,
      [pageProps]: 1,
      [sizeProps]: pageSize
    })
  }
  const resetMutate = async (params) => {
    model.current = 'filter'
    page.current.isFirstLoading = true
    setRequestParams({
      ...params,
      [pageProps]: 1,
      [sizeProps]: pageSize
    })
    return new Promise((res, reject) => {
      setTimeout(async () => {
        try {
          const data = await mutate()
          res(data)
        } catch (error) {
          reject(error)
        }
      }, 20)
    })
  }

  const pager = useMemo(() => {
    if (data) {
      let hasMore
      if (model.current === 'filter') {
        if (transformRawData) {
          page.current.list = transformRawData(data)
          hasMore = page.current.list?.length === pageSize
        } else {
          if (data?.list?.length) {
            page.current.list =
              transformData?.(data[listProps]) ?? data[listProps]
            hasMore = data.list?.length === pageSize
          } else {
            page.current.list = []
            hasMore = false
          }
        }
      } else if (model.current === 'nextPage') {
        if (transformRawData) {
          const list = transformRawData(data)
          page.current.list = page.current.list.concat(list)
          hasMore = list?.length === pageSize
        } else {
          if (data?.list?.length) {
            const list = transformData?.(data[listProps]) ?? data[listProps]
            page.current.list = page.current.list.concat(list)
            hasMore = data.list?.length === pageSize
          } else {
            hasMore = false
          }
        }
      }
      page.current.hasMore = hasMore
      page.current.isFirstLoading = false
    }
    if (error) {
      page.current.isFirstLoading = false
    }
    return {
      ...page.current
    }
  }, [data, error])

  return {
    error,
    pager,
    nextPage,
    filter,
    reset,
    resetMutate
  }
}
