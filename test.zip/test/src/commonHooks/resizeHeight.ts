import { useEffect } from "react";
import { nextTick } from "./nextTick";
 
export const useResizeHeight = () => {
    useEffect(() => {
        function adjustHeight() {
          document.documentElement.style.setProperty(
            "--vh-content",
            `${window.innerHeight}px`
          );
        }
    
        window.addEventListener("resize", adjustHeight);
        adjustHeight(); // 初始化调用一次以设置正确的高度
    }, []);
}


// 创建一个全局的 blur 事件监听的 Hook
export const useGlobalInputBlur = (callback) => {
  useEffect(() => {
    // 定义处理 blur 事件的函数
    const handleBlur = async (event) => {
      // 确保事件源是 input 元素
      if (event.target.tagName === 'INPUT') {
        callback(event);

        //修复ios11 输入框重影bug
        event.target.style.display = 'none'
        await nextTick()
        event.target.style.display = 'block'
      }
    };

    // 添加全局的 blur 事件监听器
    document.addEventListener('blur', handleBlur, true); // 使用捕获阶段

    // 清理函数，用于移除事件监听器
    return () => {
      document.removeEventListener('blur', handleBlur, true);
    };
  }, [callback]); // 确保 callback 改变时更新侦听器
}