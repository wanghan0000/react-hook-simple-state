import { useRef, useState } from 'react'

interface PagerInfo {
  pageNumber: number
  pageSize: number
  firstLoading: boolean
  hasMore: boolean
  lists: any[]
  type: 'filter' | 'nextPage'
  totalRecord: number
}

interface PageProps {
  pageNumProps?: string,
  pageSzieProps?: string,
  size?: number
}
export const usePage = ({
  pageNumProps= 'pageNumber',
  pageSzieProps = 'pageSize',
  size = 10
}: PageProps = {}) => {
  const pagerRef = useRef<PagerInfo>({
    pageNumber: 0,
    pageSize: size,
    firstLoading: true,
    hasMore: true,
    lists: [],
    type: 'filter',
    totalRecord: 0
  })
  const [update, setUpdate] = useState({})

  const getLists = (trigger: any, params) => {
    if (pagerRef.current.type !== 'nextPage') {
      pagerRef.current.firstLoading = true
      setUpdate({})
    }
    const transfomrParams = {
      ...params,
    }
    transfomrParams[pageNumProps] =pagerRef.current.pageNumber
    transfomrParams[pageSzieProps] = pagerRef.current.pageSize
    return trigger({
      ...transfomrParams
    })
      .then((res: any) => {
        if (!res || res?.length == 0) {
          if (pagerRef.current.type === 'filter') {
            pagerRef.current.pageNumber = 1
            pagerRef.current.hasMore = false
            pagerRef.current.firstLoading = false
            pagerRef.current.lists = []
          } else if (pagerRef.current.type === 'nextPage') {
            pagerRef.current.hasMore = false
            pagerRef.current.firstLoading = false
          }
          return Promise.resolve([])
        } else {
          if (res?.hasOwnProperty('totalRecord') || res?.hasOwnProperty('total')) {
            const totalRecord = res?.totalRecord || res?.total
            if (res?.hasOwnProperty('list')) {
              if (pagerRef.current.type === 'nextPage') {
                pagerRef.current.lists = pagerRef.current.lists.concat(
                  res?.list ?? []
                )
              } else {
                pagerRef.current.lists = res?.list
              }
            } else if (res?.hasOwnProperty('lists')) {
              if (pagerRef.current.type === 'nextPage') {
                pagerRef.current.lists = pagerRef.current.lists.concat(
                  res?.lists ?? []
                )
              } else {
                pagerRef.current.lists = res?.lists
              }
            } else if (res?.hasOwnProperty('baseInfo')) {
              if (pagerRef.current.type === 'nextPage') {
                pagerRef.current.lists = pagerRef.current.lists.concat(
                  res?.baseInfo ?? []
                )
              } else {
                pagerRef.current.lists = res?.baseInfo
              }
            }
            if (pagerRef.current.lists?.length >= totalRecord) {
              pagerRef.current.hasMore = false
            }else {
              pagerRef.current.hasMore = true
            }
            return Promise.resolve(res)
          }
        }
      })
      .finally(() => {
        pagerRef.current.firstLoading = false
        setUpdate({})
      })
  }

  //筛选
  const filter = async (trigger, params) => {
    pagerRef.current.pageNumber = 1
    pagerRef.current.type = 'filter'
    return getLists(trigger, params)
  }
  //下一页
  const nextPage = async (trigger, params) => {
    if(pagerRef.current.hasMore) {
      pagerRef.current.type = 'nextPage'
      pagerRef.current.pageNumber = pagerRef.current.pageNumber + 1
      return getLists(trigger, params)
    }else {
       return Promise.resolve()
    }
  }

  return {
    filter,
    nextPage,
    pagerRef,
    update
  }
}
