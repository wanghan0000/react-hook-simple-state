import { Toast } from 'antd-mobile'
import { useEffect, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'

export const useCommonErrorCode = () => {
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const jumpLoginRef = useRef(false)
  useEffect(() => {
    function receiveMessage(event) {
      if (
        event.data === 'jumpLogin' &&
        !pathname.includes('login') &&
        !jumpLoginRef.current
      ) {
        jumpLoginRef.current = true
        navigate('/login', {
          replace: true
        })

        localStorage.setItem('authToken', '')
        Toast.show('为了你的安全，请重新登录')
        setTimeout(() => {
          jumpLoginRef.current = false
        }, 300)
      }
    }
    window.addEventListener('message', receiveMessage, false)
    return ()=>{
      window.removeEventListener('message',receiveMessage)
    }
  }, [pathname])
}
