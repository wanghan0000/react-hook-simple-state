import React, { useEffect } from 'react'
import AutomaticGeneratedRoutes from './index'
import { Navigate, Route, Routes, useLocation } from 'react-router'
import LazyCompoment from '@/compoments/LazyCompoment/LazyCompoment'
import ProtectedRouteLogin from '@/compoments/ProtectedRouteLogin'
import ProtectedRoute from '@/compoments/protectedRoute/ProtectedRoute'

console.log(AutomaticGeneratedRoutes)


const RouteCenter = () => {
  return (
    <Routes>
      {AutomaticGeneratedRoutes.map((v: any, index: number) => {
        return (
          <Route
            key={index}
            path={v.path}
            element={
              v.author ? (
                <ProtectedRouteLogin>
                  <ProtectedRoute>
                    <LazyCompoment component={v.component}></LazyCompoment>
                  </ProtectedRoute>
                </ProtectedRouteLogin>
              ) : (
                <LazyCompoment component={v.component}></LazyCompoment>
              )
            }
          >
            {v?.children?.map((v: any, index: number) => {
              return (
                <Route
                  key={index}
                  path={v.path}
                  element={
                    v.author ? (
                      <ProtectedRouteLogin>
                        <ProtectedRoute>
                          <LazyCompoment
                            component={v.component}
                          ></LazyCompoment>
                        </ProtectedRoute>
                      </ProtectedRouteLogin>
                    ) : (
                      <LazyCompoment component={v.component}></LazyCompoment>
                    )
                  }
                ></Route>
              )
            })}
            {
              // 设置默认子路由
              v?.defaultRoute && (
                <Route
                  index
                  element={
                    <ProtectedRoute>
                      <Navigate replace to={v?.defaultRoute}></Navigate>
                    </ProtectedRoute>
                  }
                />
              )
            }
          </Route>
        )
      })}
      <Route path={'*'} element={<Navigate to="/main"></Navigate>}></Route>
    </Routes>
  )
}

export default RouteCenter
