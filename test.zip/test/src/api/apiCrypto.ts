import CryptoJS from 'crypto-js';

// 示例密钥和 IV（初始化向量）
const secretKey:string = process.env.REACT_APP_SECRET_KEY || ''; // 生成随机密钥
const iv:string = process.env.REACT_APP_SECRET_IV || ''; // 生成随机 IV
// AES 加密函数
export function aesEncrypt(data: string): string {
  const key = CryptoJS.enc.Utf8.parse(secretKey);
  const ivBytes = CryptoJS.enc.Utf8.parse(iv);
  const encrypted = CryptoJS.AES.encrypt(data, key, {
    iv: ivBytes,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  return encrypted.toString();
}

// AES 解密函数
export function aesDecrypt(encryptedData: string): string {
  const key = CryptoJS.enc.Utf8.parse(secretKey);
  const ivBytes = CryptoJS.enc.Utf8.parse(iv);
  const decrypted = CryptoJS.AES.decrypt(encryptedData, key, {
    iv: ivBytes,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  return decrypted.toString(CryptoJS.enc.Utf8);
}



// 用于请求的原始路径
// const originalPath = '/site/api/v1/health';
// const timestamp = Math.floor(Date.now() / 1000).toString(); // 生成 11 位时间戳
// const dataToEncrypt = timestamp + originalPath;

// 加密请求路径
// const encryptedPath = aesEncrypt(dataToEncrypt, secretKey, iv);
// console.log('Encrypted Path:', encryptedPath);

// 假设请求 body
// const requestBody = JSON.stringify({ name: 'John Doe', age: 30 });
// const encryptedBody = aesEncrypt(requestBody, secretKey, iv);
// console.log('Encrypted Body:', encryptedBody);

// 假设从服务器返回的加密内容
// const encryptedResponse = aesEncrypt('{"status":"ok","data":"Hello!"}', secretKey, iv);
// console.log('Encrypted Response:', encryptedResponse);

// 解密返回内容
// const decryptedResponse = aesDecrypt(encryptedResponse, secretKey, iv);
// console.log('Decrypted Response:', decryptedResponse);
