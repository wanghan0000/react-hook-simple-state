import { AxiosTypes, ResponseTypes } from '@/net/axios/index.inter'
import { aesDecrypt, aesEncrypt } from './apiCrypto'
// import { Md5 } from 'ts-md5';

//加密body
export const getApiSign = (params: any) => {
  const pobj = params ? params : {}
  if (window.safeSwitch) {
    const requestBody = JSON.stringify(pobj)
    const encryptedBody = aesEncrypt(requestBody)
    return encryptedBody
  } else {
    return pobj
  }
}

export enum RequestCodeEnum {
  SUCCESS = 6000, // 成功
  TOKEN_INVALID = 6001, // TOKEN参数无效，会跳到登录窗口
  LOGIN_ACCOUNT_ERROR = 6002, // 登录账号或密码错误
  NO_PERMISSTION = 6003, // 无相关权限 同403
  REQUEST_404_ERROR = 6004, // 请求接口不存在， 同404
  SYSTEM_ERROR = 6005, // 系统错误, 同500
  BAD_GATEWAY = 6006, // 无效网关, 同502
  REQUEST_FAILED = 6007, // 接口请求失败, 无法接受参数，会跳到登录窗口
  PARAMS_TYPE_ERROR = 6008, // 违法的参数
  DATA_HAS_EXIST = 6009, // 数据已存在
  UPLOAD_FILE_FAILED = 6010, // 上传文件失败
  REQUEST_REFUSED = 6011, // 频繁请求被拒绝
  LOGIN_WARNING = 6012, // 警告 非常用登录IP(web h5)或者非常用设备（移动端）
  SYSTEM_MAINTENANCE = 6013, // 系统维护
  CALL_ERRER = 6014, // 调用错误
  REMOTE_LOGIN = 6035 // 异地登录，需要验证邮箱验证码
}

const baseUrl =
  process.env.NODE_ENV === 'development'
    ? process.env.REACT_APP_MAIN_API
    : `${window.location.origin}`

export const config = {
  domainName: baseUrl,
  timeout: 10 * 1000,
  headers: {
    'X-API-SITE': process.env.REACT_APP_X_API_SITE,
    'Content-Type': 'application/json;charset=UTF-8',
    'X-API-CLIENT': 'agent_h5',
    'JMPT': 1,
    version: process.env.REACT_API_VERSION
  }
}

export const onDynamicHeader = () => {
  const headers = {
    'X-API-UUID': window.visitorId
  }
  return headers
}

export const onHandleResponseData = <T>(
  response: AxiosTypes<ResponseTypes<T>>
) => {
  return new Promise<any>((resolve, reject) => {
    //解密body
    const decryptedResponse: any = response.data
    let data = decryptedResponse
    if(typeof decryptedResponse === 'string' && window.safeSwitch) {
      data = JSON.parse(aesDecrypt(decryptedResponse))
    }
    if (data.status_code === RequestCodeEnum.TOKEN_INVALID.valueOf()) {
      window.postMessage('jumpLogin')
      reject({ ...data })
    } else if (data.status_code !== RequestCodeEnum.SUCCESS) {
      if (data.status_code) {
        reject({ ...data })
      } else {
        reject({ code: 'ERROR_DATA', message: '网络异常' })
      }
    } else {
      if (data.data) {
        if (Array.isArray(data.data)) {
          resolve({
            data: [...data.data],
            clientRawData: data
          })
        } else if (typeof data.data === 'object') {
          resolve({
            ...data.data,
            clientRawData: data
          })
        } else {
          resolve({
            data: data.data,
            clientRawData: data
          })
        }
      } else {
        resolve({
          ...data,
          clientRawData: data
        })
      }
    }
  })
}
const dealDataErrorCode = (code: any) => {
  //   if (ERROR_CODE.includes(`ERROR_${code}`)) {
  //     return `ERROR_${code}`;
  //   } else {
  //     return 'ERROR_999';
  //   }
}
