import { BaseAxios } from '@/net/axios'
import qs from 'qs'
import {
  config,
  getApiSign,
  onDynamicHeader,
  onHandleResponseData
} from './axiosConfig'
import {
  BareFetcher,
  Fetcher,
  KeyedMutator,
  SWRConfiguration,
  SWRHook,
  SWRResponse
} from 'swr/dist/_internal'
import useSWR from 'swr'
import useStorage from '@/commonHooks/useStorage'
import { aesEncrypt } from './apiCrypto'

const axios = new BaseAxios({
  requestConfig: config,
  onDynamicHeader: onDynamicHeader,
  onHandleResponseData: onHandleResponseData,
  handleSign: getApiSign
})

export const fetchSafeSwitch = async () => {
  return axios.request(
    {
      path: '/site/api/v1/safeSwitch'
    },
    {}
  )
}

export const apiFetcher = <T>(API: any, {arg}: any): Promise<T> => {
  const { formData = false, path = '', needToken = true , prefix = '/agent/api/v1' } = API
  let params = arg
  if (formData) {
    params = new URLSearchParams(qs.stringify(arg))
  }
  let headers = {}

  //const safeSwitch = localStorage.getItem('safeSwitch')

  if (needToken) {
    headers = {
      'X-API-Token': `${localStorage.getItem('authToken')}`
    }
  }
  let apiPath = prefix + path
  //console.log('加密之前的数据url======',API.path)
  if(window.safeSwitch) {
     const originalPath = apiPath;
     const timestamp = Math.floor(Date.now() / 1000).toString(); // 生成 11 位时间戳
     const dataToEncrypt = timestamp + originalPath;
     const encrypt = aesEncrypt(dataToEncrypt)
     apiPath = '/xxxx/' + encrypt
  }
  //console.log('加密之后的数据url======',API.path)
 
  return axios
    .request<T | any>({
      ...API,
      path:apiPath
    }, params, {
      headers
    })
    .then((res) => {
      return res
    })
}

function generateRandomString(length) {
  const characters =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let result = ''
  const charactersLength = characters.length
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength))
  }
  return result
}

export class SWRCenter {
  private static instance: SWRCenter | null = null
  private cacheKey: string = ''
  public static getInstance(): SWRCenter {
    if (!SWRCenter.instance) {
      SWRCenter.instance = new SWRCenter()
    }
    return SWRCenter.instance
  }

  constructor() {
    this.randomKey()
  }

  /**只有退出登录后 再刷新key */
  public randomKey() {
    this.cacheKey = generateRandomString(10)
  }

  public getCacheKey(): string | undefined {
    return SWRCenter.instance?.cacheKey
  }
}

export interface IFSWRResponse {
  isLoading: boolean
  data: any
  error: any
  mutate: KeyedMutator<any>
  isValidating: boolean
  randomKey: () => void
}

export const useSWRExpand = (
  key: string,
  fetcher: any,
  options?: SWRConfiguration<any, any, BareFetcher<any>>
): IFSWRResponse => {
  const { randomKey, cacheKey } = useSWRCacheKey(key)
  const result = useSWR<any>(
    SWRCenter.getInstance().getCacheKey() + key + cacheKey,
    fetcher,
    options
  )
  return {
    ...result,
    randomKey
  }
}

const useSWRCacheKey = (props) => {
  const [key, setKey] = useStorage(props, '')

  const randomKey = () => {
    const keys = generateRandomString(5)
    setKey(keys)
  }

  return {
    cacheKey: key || '',
    randomKey
  }
}
