/* 联系我们*/
export const getContactLink = (key: string) => {
  let strLink = ''
  switch (key) {
    case 'hyzx':
      // strLink = 'https://chatweb.sribgio.com/chat/index.html'
      strLink =
        'https://5nayny.com:443/chat/text/chat_0QtdEs.html?skill=8a2a80918e8911d1018ec2ae8c6b3926'
      break
    case 'skype':
      strLink = 'https://www.skype.com/zh-Hans/get-skype/'
      break
    case 'yx':
      strLink = 'https://www.youxin1.app/'
      break
    default:
      break
  }
  return strLink
}

export function isLetter(char: any) {
  return /[a-zA-Z]/.test(char)
}
export function containsTwoLetters(str: any, count: any) {
  // 使用正则表达式匹配字母，并计算匹配到的数量
  const letterCount = (str.match(/[a-zA-Z]/g) || []).length
  // 如果字母数量大于等于2，则返回 true，否则返回 false
  return letterCount >= count
}
