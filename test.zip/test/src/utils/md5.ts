import * as CryptoJS from "crypto-js";

export function md5Hash(content: string) {
  // 使用 MD5 进行加密
  const hash: CryptoJS.lib.WordArray = CryptoJS.MD5(content);

  // 将结果转换为字符串（16进制）
  return hash.toString(CryptoJS.enc.Hex);
}
