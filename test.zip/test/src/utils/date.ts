/**2024-04-01 */
export const TimeStringToDate = (time: string) => {
  return new Date(Date.parse(time))
}

export const timestampToString = (timestamp: number) => {
  const date = new Date(timestamp)
  // 使用Date对象的方法获取年、月、日
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0') // 月份从0开始，需要加1
  const day = String(date.getDate()).padStart(2, '0')

  // 组合成字符串
  const dateString = `${year}-${month}-${day}`
  return dateString
}

export const timestampToMonth = (timestamp: number) => {
  const date = new Date(timestamp)
  // 使用Date对象的方法获取年、月、日
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0') // 月份从0开始，需要加1

  // 组合成字符串
  const dateString = `${year}-${month}`
  return dateString
}

/**
 * console.log(getDateString(-7, true, 'YYYY-MM-DD')); // 7 days ago, start of the day
 * console.log(getDateString(7, false, 'YYYY-MM-DD HH:mm:ss')); // 7 days ahead, end of the day
 * console.log(getDateString(-7, true, 'YYYY')); // Just the year, 7 days ago
 */
export function getCurrentDateString(
  delayDays: number,
  isStart: boolean,
  format:
    | 'YYYY'
    | 'MM'
    | 'DD'
    | 'YYYY-MM'
    | 'YYYY-MM-DD'
    | 'YYYY-MM-DD HH:mm:ss'
    | 'HH:mm:ss'
): string {
  const now = new Date()
  now.setDate(now.getDate() + delayDays)

  if (isStart) {
    now.setHours(0, 0, 0, 0)
  } else {
    now.setHours(23, 59, 59, 999)
  }

  const year = now.getFullYear()
  const month = String(now.getMonth() + 1).padStart(2, '0')
  const day = String(now.getDate()).padStart(2, '0')
  const hours = String(now.getHours()).padStart(2, '0')
  const minutes = String(now.getMinutes()).padStart(2, '0')
  const seconds = String(now.getSeconds()).padStart(2, '0')

  switch (format) {
    case 'YYYY':
      return `${year}`
    case 'MM':
      return `${month}`
    case 'DD':
      return `${day}`
    case 'YYYY-MM':
      return `${year}-${month}`
    case 'YYYY-MM-DD':
      return `${year}-${month}-${day}`
    case 'YYYY-MM-DD HH:mm:ss':
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
    case 'HH:mm:ss':
      return `${hours}:${minutes}:${seconds}`
    default:
      // Default format if none match
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
  }
}

/**
 * @description 时间格式化
 * @param dateTime { number } 时间戳 时间戳
 * @param onlyDate { bool } 是否只返回日期格式，默认false
 * @returns { string } 返回格式化后的时间 onlyDate: false YYYY-MM-DD HH:mm:ss, true: YYYY-MM-DD
 */
export const timeFormat = (
  dateTime: number,
  fmt = 'yyyy-mm-dd hh:mm:ss'
): string => {
  // 如果为null,则格式化当前时间
  if (!dateTime) {
    dateTime = Number(new Date())
  }
  // 如果dateTime长度为10或者13，则为秒和毫秒的时间戳，如果超过13位，则为其他的时间格式
  if (dateTime.toString().length == 10) {
    dateTime *= 1000
  }
  const date = new Date(dateTime)
  const year = date.getFullYear()
  const month = (date.getMonth() + 1).toString().padStart(2, '0')
  const day = date.getDate().toString().padStart(2, '0')
  const hours = date.getHours().toString().padStart(2, '0')
  const minutes = date.getMinutes().toString().padStart(2, '0')
  const seconds = date.getSeconds().toString().padStart(2, '0')
  if (fmt == 'yyyy-mm-dd') {
    return `${year}-${month}-${day}`
  } else if (fmt == 'yyyy-mm') {
    return `${year}-${month}`
  } else if (fmt == 'hh:mm:ss') {
    return `${hours}:${minutes}:${seconds}`
  } else {
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
  }
}

export const timeStartFormat = (
  nDay = 0,
  fmt = 'yyyy-mm-dd hh:mm:ss'
): string => {
  return timeFormat(
    new Date().setHours(0, 0, 0, 0) - nDay * 24 * 60 * 60 * 1000,
    fmt
  )
}
//23:59:59结束日期
export const timeEndFormat = (
  nDay = 0,
  fmt = 'yyyy-mm-dd hh:mm:ss'
): string => {
  return timeFormat(
    new Date().setHours(23, 59, 59, 999) - nDay * 24 * 60 * 60 * 1000,
    fmt
  ) // 订单结束时间
}

/* 来获取当前月份的起始和结束日期 */
export const formatDate = (date: any) => {
  const year = date.getFullYear()
  const month = (date.getMonth() + 1).toString().padStart(2, '0') // 月份从0开始，所以加1
  const day = date.getDate().toString().padStart(2, '0')
  return `${year}-${month}-${day}`
}

export const getStartAndEndOfMonth = (nMonth = 0) => {
  const now = new Date()
  const iMonth = new Date(now.getFullYear(), now.getMonth() + nMonth, 1)
  const startOfMonth = new Date(iMonth.getFullYear(), iMonth.getMonth(), 1)
  const endOfMonth = new Date(iMonth.getFullYear(), iMonth.getMonth() + 1, 0)
  return {
    startOfMonth: formatDate(startOfMonth),
    endOfMonth: formatDate(endOfMonth)
  }
}

export const formatMonth = (date: any) => {
  const year = date.getFullYear()
  const month = (date.getMonth() + 1).toString().padStart(2, '0') // 月份从0开始，所以加1
  return `${year}-${month}`
}

export const getMonth = (nMonth = 0) => {
  const now = new Date()
  const iMonth = new Date(now.getFullYear(), now.getMonth() + nMonth, 1)
  const startOfMonth = new Date(iMonth.getFullYear(), iMonth.getMonth(), 1)
  const endOfMonth = new Date(iMonth.getFullYear(), iMonth.getMonth() + 1, 0)
  return {
    startOfMonth: formatMonth(startOfMonth),
    endOfMonth: formatMonth(endOfMonth)
  }
}
