export const openLink = (url) => {
  const link = document.createElement('a')
  link.href = url
  link.target = '_blank'
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

/**处理金额，四舍五入后保留N位小数
 * @amount 金额
 * @fixed 小数位
 * @return 处理后的金额
 */
export const mathFloorFixed = (
  amount: number,
  fixed: number,
  accuracy = 100
) => {
  amount = Number(amount) ?? 0
  return (Math.floor(amount * accuracy) / accuracy).toFixed(fixed)
}


export function deepClone(obj: any) {
  if (obj === null || typeof obj !== 'object') {
      return obj
  }

  const clonedObject: any = Array.isArray(obj) ? [] : {}

  for (const key in obj) {
      if (Object.hasOwnProperty.call(obj, key)) {
          clonedObject[key] = deepClone(obj[key])
      }
  }

  return clonedObject
}

export const formatNumberWithCommas = (value: any) => {
  // 先保留两位小数
  if (value == null || value == undefined) {
      value = 0
  }
  if (typeof value != 'number') {
      value = Number(value)
  }
  const roundedNumber = ((value * 100) / 100).toFixed(2)
  return roundedNumber.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}