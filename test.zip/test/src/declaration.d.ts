

interface Window {
  /**是否需要接口加密 */
  safeSwitch: boolean
  /**设备指纹 */
  visitorId: string
}
