"use strict";

const fs = require("fs");
const path = require("path");
const webpack = require("webpack");
const resolve = require("resolve");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CaseSensitivePathsPlugin = require("case-sensitive-paths-webpack-plugin");
const InlineChunkHtmlPlugin = require("react-dev-utils/InlineChunkHtmlPlugin");
const TerserPlugin = require("terser-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const CssMinimizerPlugin = require("css-minimizer-webpack-plugin");
const { WebpackManifestPlugin } = require("webpack-manifest-plugin");
const InterpolateHtmlPlugin = require("react-dev-utils/InterpolateHtmlPlugin");
const WorkboxWebpackPlugin = require("workbox-webpack-plugin");
const ModuleScopePlugin = require("react-dev-utils/ModuleScopePlugin");
const getCSSModuleLocalIdent = require("react-dev-utils/getCSSModuleLocalIdent");
const ESLintPlugin = require("eslint-webpack-plugin");
const paths = require("./paths");
const modules = require("./modules");
const getClientEnvironment = require("./env");
const ModuleNotFoundPlugin = require("react-dev-utils/ModuleNotFoundPlugin");
const ForkTsCheckerWebpackPlugin =
  process.env.TSC_COMPILE_ON_ERROR === "true"
    ? require("react-dev-utils/ForkTsCheckerWarningWebpackPlugin")
    : require("react-dev-utils/ForkTsCheckerWebpackPlugin");
const ReactRefreshWebpackPlugin = require("@pmmmwh/react-refresh-webpack-plugin");
const CompressionPlugin = require('compression-webpack-plugin');
const createEnvironmentHash = require("./webpack/persistentCache/createEnvironmentHash");

// Source maps 是资源密集型的，可能会导致大型源文件的内存溢出问题。
const shouldUseSourceMap = process.env.GENERATE_SOURCEMAP !== "false";

const reactRefreshRuntimeEntry = require.resolve("react-refresh/runtime");
const reactRefreshWebpackPluginRuntimeEntry = require.resolve(
  "@pmmmwh/react-refresh-webpack-plugin"
);
const babelRuntimeEntry = require.resolve("babel-preset-react-app");
const babelRuntimeEntryHelpers = require.resolve(
  "@babel/runtime/helpers/esm/assertThisInitialized",
  { paths: [babelRuntimeEntry] }
);
const babelRuntimeRegenerator = require.resolve("@babel/runtime/regenerator", {
  paths: [babelRuntimeEntry],
});

// 一些应用程序不需要节省网络请求的好处，所以不内联 chunk 可以使构建过程更加顺畅。
const shouldInlineRuntimeChunk = process.env.INLINE_RUNTIME_CHUNK !== "false";

const emitErrorsAsWarnings = process.env.ESLINT_NO_DEV_ERRORS === "true";
const disableESLintPlugin = process.env.DISABLE_ESLINT_PLUGIN === "true";

const imageInlineSizeLimit = parseInt(
  process.env.IMAGE_INLINE_SIZE_LIMIT || "10000"
);

console.log('process',process.env)
// 检查是否设置了 TypeScript
const useTypeScript = fs.existsSync(paths.appTsConfig);

// 检查是否存在 Tailwind 配置
const useTailwind = fs.existsSync(
  path.join(paths.appPath, "tailwind.config.js")
);

// 获取未编译的 service worker 路径（如果存在）。
const swSrc = paths.swSrc;

// 样式文件正则表达式
const cssRegex = /\.css$/;
const cssModuleRegex = /\.module\.css$/;
const sassRegex = /\.(scss|sass)$/;
const sassModuleRegex = /\.module\.(scss|sass)$/;

const hasJsxRuntime = (() => {
  if (process.env.DISABLE_NEW_JSX_TRANSFORM === "true") {
    return false;
  }

  try {
    require.resolve("react/jsx-runtime");
    return true;
  } catch (e) {
    return false;
  }
})();

// 这是生产和开发环境的配置。
// 它侧重于开发者体验、快速重建和最小化的包。
module.exports = function (webpackEnv) {
  const isEnvDevelopment = webpackEnv === "development";
  const isEnvProduction = webpackEnv === "production";

  // 用于在生产中启用性能分析的变量
  // 通过构建命令中的标志传递给别名对象
  const isEnvProductionProfile =
    isEnvProduction && process.argv.includes("--profile");

  // 我们将 `paths.publicUrlOrPath` 提供给我们的应用程序
  // 作为 `index.html` 中的 %PUBLIC_URL% 和 JavaScript 中的 `process.env.PUBLIC_URL`。
  // 省略尾部斜杠，因为 %PUBLIC_URL%/xyz 比 %PUBLIC_URL%xyz 看起来更好。
  // 获取注入到我们应用的环境变量。
  const env = getClientEnvironment(paths.publicUrlOrPath.slice(0, -1));

  const shouldUseReactRefresh = env.raw.FAST_REFRESH;

  // 通用函数以获取样式加载器
  const getStyleLoaders = (cssOptions, preProcessor) => {
    const loaders = [
      isEnvDevelopment && require.resolve("style-loader"),
      isEnvProduction && {
        loader: MiniCssExtractPlugin.loader,
        // css 位于 `static/css` 中，使用 '../../' 定位 index.html 文件夹
        // 在生产中 `paths.publicUrlOrPath` 可以是相对路径
        options: paths.publicUrlOrPath.startsWith(".")
          ? { publicPath: "../../" }
          : {},
      },
      {
        loader: require.resolve("css-loader"),
        options: cssOptions,
      },
      {
        // PostCSS 的选项，因为我们在两处引用了这些选项
        // 根据你在 package.json 中指定的浏览器支持添加供应商前缀
        loader: require.resolve("postcss-loader"),
        options: {
          postcssOptions: {
            // 外部 CSS 导入工作所必需的
            // https://github.com/facebook/create-react-app/issues/2677
            ident: "postcss",
            config: false,
            plugins: !useTailwind
              ? [
                  "postcss-flexbugs-fixes",
                  require('postcss-preset-env')({
                    stage: 3,
                    features: {
                      'custom-properties': false
                    },
                    autoprefixer: {
                      flexbox: "no-2009"
                    }
                  }),
                  "postcss-normalize",
                  require('postcss-px-to-viewport')({
                    viewportWidth: 375,  // 设计稿宽度
                    unitPrecision: 2,  // 单位转换后保留的精度
                    viewportUnit: 'vw',  // 需要转换成的视口单位
                    selectorBlackList: ['.ignore'],  // 不转换的类
                    minPixelValue: 1,  // 最小的转换数值
                    mediaQuery: false  // 允许在媒体查询中转换
                  })
                ]
              : [
                  "tailwindcss",
                  "postcss-flexbugs-fixes",
                  require('postcss-preset-env')({
                    stage: 3,
                    features: {
                      'custom-properties': false
                    },
                    autoprefixer: {
                      flexbox: "no-2009"
                    }
                  }),
                  require('postcss-px-to-viewport')({
                    viewportWidth: 375,  // 设计稿宽度
                    unitPrecision: 2,  // 单位转换后保留的精度
                    viewportUnit: 'vw',  // 需要转换成的视口单位
                    selectorBlackList: ['.ignore'],  // 不转换的类
                    minPixelValue: 1,  // 最小的转换数值
                    mediaQuery: false  // 允许在媒体查询中转换
                  })
                ],
          },
          sourceMap: isEnvProduction ? shouldUseSourceMap : isEnvDevelopment,
        },
      },
      {
        loader: 'px2rem-loader',  // 添加 px2rem-loader
        options: {
          remUnit: 37.5,
          remPrecision: 2
        }
      }
    ].filter(Boolean);
    if (preProcessor) {
      loaders.push(
        {
          loader: require.resolve("resolve-url-loader"),
          options: {
            sourceMap: isEnvProduction ? shouldUseSourceMap : isEnvDevelopment,
            root: paths.appSrc,
          },
        },
        {
          loader: require.resolve(preProcessor),
          options: {
            sourceMap: true,
          },
        }
      );
    }
    return loaders;
  };

  return {
    target: ["browserslist"],
    // 将 Webpack 噪音限制为错误和警告
    stats: "errors-warnings",
    mode: isEnvProduction ? "production" : isEnvDevelopment && "development",
    // 在生产中提前停止编译
    bail: isEnvProduction,
    devtool: isEnvProduction
      ? shouldUseSourceMap
        ? "source-map"
        : false
      : isEnvDevelopment && "cheap-module-source-map",
    // 这些是我们应用程序的“入口点”。
    // 这意味着它们将是包含在 JS 包中的“根”导入。
    entry: paths.appIndexJs,
    output: {
      // 构建文件夹。
      path: paths.appBuild,
      // 在生成的 require() 中添加 /* filename */ 注释。
      pathinfo: isEnvDevelopment,
      // 将有一个主要的包，和一个异步块的文件。
      // 在开发中，它不会产生真正的文件。
      filename: isEnvProduction
        ? "static/js/[name].[contenthash:8].js"
        : isEnvDevelopment && "static/js/bundle.js",
      // 如果使用代码分割，还有额外的 JS 块文件。
      chunkFilename: isEnvProduction
        ? "static/js/[name].[contenthash:8].chunk.js"
        : isEnvDevelopment && "static/js/[name].chunk.js",
      assetModuleFilename: "static/media/[name].[hash][ext]",
      // webpack 使用 `publicPath` 来确定从哪里提供应用程序。
      // 它需要一个尾部斜杠，否则文件资产将获得错误的路径。
      // 我们从主页推断出“公共路径”（如 / 或 /my-project）。
      publicPath: paths.publicUrlOrPath,
      // 将源映射条目指向原始磁盘位置（在 Windows 上格式化为 URL）
      devtoolModuleFilenameTemplate: isEnvProduction
        ? (info) =>
            path
              .relative(paths.appSrc, info.absoluteResourcePath)
              .replace(/\\/g, "/")
        : isEnvDevelopment &&
          ((info) =>
            path.resolve(info.absoluteResourcePath).replace(/\\/g, "/")),
    },
    cache: {
      type: "filesystem",
      version: createEnvironmentHash(env.raw),
      cacheDirectory: paths.appWebpackCache,
      store: "pack",
      buildDependencies: {
        defaultWebpack: ["webpack/lib/"],
        config: [__filename],
        tsconfig: [paths.appTsConfig, paths.appJsConfig].filter((f) =>
          fs.existsSync(f)
        ),
      },
    },
    infrastructureLogging: {
      level: "none",
    },
    optimization: {
      minimize: isEnvProduction,
      minimizer: [
        // 这只在生产模式中使用
        new TerserPlugin({
          terserOptions: {
            parse: {
              // 我们希望 terser 解析 ecma 8 代码。然而，我们不希望它
              // 应用任何将有效的 ecma 5 代码
              // 转换为无效的 ecma 5 代码的最小化步骤。这就是为什么 'compress' 和 'output'
              // 部分只应用 ecma 5 安全的转换
              // https://github.com/facebook/create-react-app/pull/4234
              ecma: 8,
            },
            compress: {
              ecma: 5,
              warnings: false,
              // 禁用是因为有一个问题，Uglify 会破坏看似有效的代码：
              // https://github.com/facebook/create-react-app/issues/2376
              // 暂时搁置进一步调查：
              // https://github.com/mishoo/UglifyJS2/issues/2011
              comparisons: false,
              // 禁用是因为有一个问题，Terser 会破坏有效代码：
              // https://github.com/facebook/create-react-app/issues/5250
              // 暂时搁置进一步调查：
              // https://github.com/terser-js/terser/issues/120
              inline: 2,
            },
            mangle: {
              safari10: true,
            },
            // 为开发工具中的分析添加
            keep_classnames: isEnvProductionProfile,
            keep_fnames: isEnvProductionProfile,
            output: {
              ecma: 5,
              comments: false,
              // 开启是因为 emoji 和正则表达式使用默认设置没有被正确地缩小
              // https://github.com/facebook/create-react-app/issues/2488
              ascii_only: true,
            },
          },
        }),
        // 这只在生产模式中使用
        new CssMinimizerPlugin(),
      ],
    },
    resolve: {
      // 这允许您为 webpack 查找模块的位置设置一个回退。
      // 我们将这些路径放在第二位，因为我们希望 `node_modules` 在有冲突时“获胜”。
      // 这与 Node 解析机制相匹配。
      // https://github.com/facebook/create-react-app/issues/253
      modules: ["node_modules", paths.appNodeModules].concat(
        modules.additionalModulePaths || []
      ),
      // 这些是 Node 生态系统支持的合理默认值。
      // 我们还包括了 JSX 作为一个常见的组件文件名扩展名，以支持
      // 一些工具，尽管我们不建议使用它，请参见：
      // https://github.com/facebook/create-react-app/issues/290
      // 为了更好地支持 React Native Web，已添加了 `web` 扩展名前缀。
      extensions: paths.moduleFileExtensions
        .map((ext) => `.${ext}`)
        .filter((ext) => useTypeScript || !ext.includes("ts")),
      alias: {
        // 支持 React Native Web
        // https://www.smashingmagazine.com/2016/08/a-glimpse-into-the-future-with-react-native-for-web/
        "react-native": "react-native-web",
        // 允许使用 ReactDevTools 进行更好的分析
        ...(isEnvProductionProfile && {
          "react-dom$": "react-dom/profiling",
          "scheduler/tracing": "scheduler/tracing-profiling",
        }),
        ...(modules.webpackAliases || {}),
      },
      plugins: [
        // 防止用户从 src/ 之外导入文件（或 node_modules/）。
        // 这经常引起困惑，因为我们只在 src/ 中用 babel 处理文件。
        // 为了解决这个问题，我们阻止您从 src/ 之外导入文件 -- 如果您想这样做，
        // 请将文件链接到您的 node_modules/ 中，让模块解析发挥作用。
        // 确保您的源文件已编译，因为它们将不会以任何方式被处理。
        new ModuleScopePlugin(paths.appSrc, [
          paths.appPackageJson,
          reactRefreshRuntimeEntry,
          reactRefreshWebpackPluginRuntimeEntry,
          babelRuntimeEntry,
          babelRuntimeEntryHelpers,
          babelRuntimeRegenerator,
        ]),
      ],
    },
    module: {
      strictExportPresence: true,
      rules: [
        // 处理包含源映射的 node_modules 包
        shouldUseSourceMap && {
          enforce: "pre",
          exclude: /@babel(?:\/|\\{1,2})runtime/,
          test: /\.(js|mjs|jsx|ts|tsx|css)$/,
          loader: require.resolve("source-map-loader"),
        },
        {
          // "oneOf" 将遍历所有后续加载器，直到一个符合要求。如果没有加载器匹配，它将回退
          // 到加载器列表末尾的“文件”加载器。
          oneOf: [
            // TODO: 合并此配置一旦 `image/avif` 在 mime-db 中
            // https://github.com/jshttp/mime-db
            {
              test: [/\.avif$/],
              type: "asset",
              mimetype: "image/avif",
              parser: {
                dataUrlCondition: {
                  maxSize: imageInlineSizeLimit,
                },
              },
            },
            // “url”加载器的工作方式类似于“文件”加载器，不同之处在于它将小于指定限制的资产嵌入为数据 URL，以避免请求。
            // 缺少“测试”相当于匹配。
            {
              test: [/\.bmp$/, /\.gif$/, /\.jpe?g$/, /\.png$/],
              type: "asset",
              parser: {
                dataUrlCondition: {
                  maxSize: imageInlineSizeLimit,
                },
              },
            },
            {
              test: /\.svg$/,
              use: [
                {
                  loader: require.resolve("@svgr/webpack"),
                  options: {
                    prettier: false,
                    svgo: false,
                    svgoConfig: {
                      plugins: [{ removeViewBox: false }],
                    },
                    titleProp: true,
                    ref: true,
                  },
                },
                {
                  loader: require.resolve("file-loader"),
                  options: {
                    name: "static/media/[name].[hash].[ext]",
                  },
                },
              ],
              issuer: {
                and: [/\.(ts|tsx|js|jsx|md|mdx)$/],
              },
            },
            // 使用 Babel 处理应用程序 JS。
            // 该预设包括 JSX、Flow、TypeScript 和一些 ESnext 功能。
            {
              test: /\.(js|mjs|jsx|ts|tsx)$/,
              include: paths.appSrc,
              loader: require.resolve("babel-loader"),
              options: {
                customize: require.resolve(
                  "babel-preset-react-app/webpack-overrides"
                ),
                presets: [
                  [
                    require.resolve("babel-preset-react-app"),
                    {
                      runtime: hasJsxRuntime ? "automatic" : "classic",
                    },
                  ],
                  // 针对的新的 antd-mobile Babel 预设
                  [
                    "@babel/preset-env",
                    {
                      targets: {
                        chrome: "49",
                        ios: "10",
                      },
                    },
                  ],
                ],

                plugins: [
                  isEnvDevelopment &&
                    shouldUseReactRefresh &&
                    require.resolve("react-refresh/babel"),
                ].filter(Boolean),
                // 这是 `babel-loader` 的一个功能，用于 webpack（而不是 Babel 本身）。
                // 它启用了在 ./node_modules/.cache/babel-loader/ 目录中缓存结果
                // 以实现更快的重建。
                cacheDirectory: true,
                // 参见 #6846 了解为什么禁用 cacheCompression 的上下文
                cacheCompression: false,
                compact: isEnvProduction,
              },
            },
            // 使用 Babel 处理应用程序外的任何 JS。
            // 与应用程序 JS 不同，我们只编译标准 ES 功能。
            {
              test: /\.(js|mjs)$/,
              exclude: /@babel(?:\/|\\{1,2})runtime/,
              loader: require.resolve("babel-loader"),
              options: {
                babelrc: false,
                configFile: false,
                compact: false,
                presets: [
                  [
                    require.resolve("babel-preset-react-app/dependencies"),
                    { helpers: true },
                  ],
                ],
                cacheDirectory: true,
                // 参见 #6846 了解为什么禁用 cacheCompression 的上下文
                cacheCompression: false,

                // 调试 node_modules 中的代码需要 Babel 源映射
                // 没有下面的选项，调试器（如 VSCode）
                // 显示错误的代码并在错误的行上设置断点。
                sourceMaps: shouldUseSourceMap,
                inputSourceMap: shouldUseSourceMap,
              },
            },
            // “postcss”加载器将 autoprefixer 应用于我们的 CSS。
            // “css”加载器解析 CSS 中的路径并添加资产作为依赖项。
            // “style”加载器将 CSS 转换为注入 <style> 标签的 JS 模块。
            // 在生产中，我们使用 MiniCSSExtractPlugin 将该 CSS 提取到文件中，但在开发中，“style”加载器支持 CSS 的热编辑。
            // 默认情况下我们支持带有扩展名 .module.css 的 CSS Modules
            {
              test: cssRegex,
              exclude: cssModuleRegex,
              use: getStyleLoaders({
                importLoaders: 1,
                sourceMap: isEnvProduction
                  ? shouldUseSourceMap
                  : isEnvDevelopment,
                modules: {
                  mode: "icss",
                },
              }),
              // 即使
              // 包含的包声称没有副作用，也不要将 CSS 导入视为无用代码。
              // 当 webpack 为此添加警告或错误时删除此项。
              // 参见 https://github.com/webpack/webpack/issues/6571
              sideEffects: true,
            },
            // 添加对 CSS Modules 的支持（https://github.com/css-modules/css-modules）
            // 使用扩展名 .module.css
            {
              test: cssModuleRegex,
              use: getStyleLoaders({
                importLoaders: 1,
                sourceMap: isEnvProduction
                  ? shouldUseSourceMap
                  : isEnvDevelopment,
                modules: {
                  mode: "local",
                  getLocalIdent: getCSSModuleLocalIdent,
                },
              }),
            },
            // 开箱即用的支持 SASS（使用 .scss 或 .sass 扩展名）。
            // 默认情况下，我们支持带有
            // 扩展名 .module.scss 或 .module.sass 的 SASS Modules
            {
              test: sassRegex,
              exclude: sassModuleRegex,
              use: getStyleLoaders(
                {
                  importLoaders: 3,
                  sourceMap: isEnvProduction
                    ? shouldUseSourceMap
                    : isEnvDevelopment,
                  modules: {
                    mode: "icss",
                  },
                },
                "sass-loader"
              ),
              // 即使
              // 包含的包声称没有副作用，也不要将 CSS 导入视为无用代码。
              // 当 webpack 为此添加警告或错误时删除此项。
              // 参见 https://github.com/webpack/webpack/issues/6571
              sideEffects: true,
            },
            // 添加对 CSS Modules 的支持，但使用 SASS
            // 使用扩展名 .module.scss 或 .module.sass
            {
              test: sassModuleRegex,
              use: getStyleLoaders(
                {
                  importLoaders: 3,
                  sourceMap: isEnvProduction
                    ? shouldUseSourceMap
                    : isEnvDevelopment,
                  modules: {
                    mode: "local",
                    getLocalIdent: getCSSModuleLocalIdent,
                  },
                },
                "sass-loader"
              ),
            },
            // “文件”加载器确保这些资产由 WebpackDevServer 提供。
            // 当你 `import` 一个资产时，你得到它的（虚拟）文件名。
            // 在生产中，它们将被复制到 `build` 文件夹。
            // 此加载器不使用“测试”，因此它将捕获所有其他加载器未处理的模块。
            {
              // 排除 `js` 文件以保持“css”加载器的工作，因为它会注入
              // 它的运行时，否则将通过“文件”加载器处理。
              // 还排除了 `html` 和 `json` 扩展名，这样它们就会被 webpack 的内部加载器处理。
              exclude: [/^$/, /\.(js|mjs|jsx|ts|tsx)$/, /\.html$/, /\.json$/],
              type: "asset/resource",
            },
            // ** 停止 ** 您正在添加新的加载器？
            // 确保在“文件”加载器之前添加新的加载器。
          ],
        },
      ].filter(Boolean),
    },
    plugins: [
      // 生成一个带有 <script> 注入的 `index.html` 文件。
      new HtmlWebpackPlugin(
        Object.assign(
          {},
          {
            inject: true,
            template: paths.appHtml,
            templateParameters: {
              REACT_APP_VERSION: process.env.REACT_APP_VERSION,
            },
          },
          isEnvProduction
            ? {
                minify: {
                  removeComments: true,
                  collapseWhitespace: true,
                  removeRedundantAttributes: true,
                  useShortDoctype: true,
                  removeEmptyAttributes: true,
                  removeStyleLinkTypeAttributes: true,
                  keepClosingSlash: true,
                  minifyJS: true,
                  minifyCSS: true,
                  minifyURLs: true,
                },
              }
            : undefined
        )
      ),
      // 内联 webpack 运行时脚本。这个脚本太小，不值得一个网络请求。
      // https://github.com/facebook/create-react-app/issues/5358
      isEnvProduction &&
        shouldInlineRuntimeChunk &&
        new InlineChunkHtmlPlugin(HtmlWebpackPlugin, [/runtime-.+[.]js/]),
      // 使 index.html 中的一些环境变量可用。
      // 公共 URL 作为 %PUBLIC_URL% 在 index.html 中可用，例如：
      // <link rel="icon" href="%PUBLIC_URL%/favicon.ico">
      // 除非您在 `package.json` 中指定了“homepage”，否则它将是一个空字符串，
      // 在这种情况下，它将是该 URL 的路径名。
      new InterpolateHtmlPlugin(HtmlWebpackPlugin, env.raw),
      // 这为模块未找到的错误提供了一些必要的上下文，例如
      // 请求资源。
      new ModuleNotFoundPlugin(paths.appPath),
      // 使一些环境变量可用于 JS 代码，例如：
      // if (process.env.NODE_ENV === 'production') { ... }。参见 `./env.js`。
      // 在生产构建期间将 NODE_ENV 设置为 production 是绝对必要的。
      // 否则 React 将以非常慢的开发模式被编译。
      new webpack.DefinePlugin(env.stringified),
      // React 的实验性热重载。
      // https://github.com/facebook/react/tree/main/packages/react-refresh
      isEnvDevelopment &&
        shouldUseReactRefresh &&
        new ReactRefreshWebpackPlugin({
          overlay: false,
        }),
      // 如果你在路径中键入错误的大小写，观察者将无法正常工作，所以我们使用
      // 一个在你尝试这样做时会打印错误的插件。
      // 参见 https://github.com/facebook/create-react-app/issues/240
      isEnvDevelopment && new CaseSensitivePathsPlugin(),
      isEnvProduction &&
        new MiniCssExtractPlugin({
          // 选项类似于 webpackOptions.output 中的相同选项
          // 这两个选项都是可选的
          filename: "static/css/[name].[contenthash:8].css",
          chunkFilename: "static/css/[name].[contenthash:8].chunk.css",
        }),
      // 使用以下内容生成资产清单文件：
      // - “files”键：将所有资产文件名映射到它们对应的输出文件，以便工具可以在不解析的情况下拾取它们
      //   `index.html`
      // - “entrypoints”键：包含在 `index.html` 中的文件数组，
      //   可用于在必要时重建 HTML
      new WebpackManifestPlugin({
        fileName: "asset-manifest.json",
        publicPath: paths.publicUrlOrPath,
        generate: (seed, files, entrypoints) => {
          const manifestFiles = files.reduce((manifest, file) => {
            manifest[file.name] = file.path;
            return manifest;
          }, seed);
          const entrypointFiles = entrypoints.main.filter(
            (fileName) => !fileName.endsWith(".map")
          );

          return {
            files: manifestFiles,
            entrypoints: entrypointFiles,
          };
        },
      }),
      isEnvProduction && new CompressionPlugin({
        // 这里是可选的配置
        algorithm: 'gzip',
        test: /\.(js|css|html|svg)$/, // 压缩 js, css, html 和 svg 文件
        threshold: 10240, // 只处理大于此大小的文件（以字节为单位）
        minRatio: 0.8 // 只处理压缩比率小于这个值的文件
      }),
      // Moment.js 是一个非常流行的库，默认情况下会捆绑大型区域设置文件
      // 由于 webpack 如何解释它的代码。这是一个实际的解决方案，要求用户选择
      // 导入特定区域设置。
      // https://github.com/jmblog/how-to-optimize-momentjs-with-webpack
      // 如果你不使用 Moment.js，可以删除这个：
      new webpack.IgnorePlugin({
        resourceRegExp: /^\.\/locale$/,
        contextRegExp: /moment$/,
      }),
      // 生成一个服务工作者脚本，将预缓存，并保持最新，
      // 是 webpack 构建的一部分的 HTML 和资产。
      isEnvProduction &&
        fs.existsSync(swSrc) &&
        new WorkboxWebpackPlugin.InjectManifest({
          swSrc,
          dontCacheBustURLsMatching: /\.[0-9a-f]{8}\./,
          exclude: [/\.map$/, /asset-manifest\.json$/, /LICENSE/],
          // 提高默认的最大预缓存大小（2mb），使懒加载失败的场景不太可能发生。
          // 参见 https://github.com/cra-template/pwa/issues/13#issuecomment-722667270
          maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
        }),
      // TypeScript 类型检查
      useTypeScript &&
        new ForkTsCheckerWebpackPlugin({
          async: isEnvDevelopment,
          typescript: {
            typescriptPath: resolve.sync("typescript", {
              basedir: paths.appNodeModules,
            }),
            configOverwrite: {
              compilerOptions: {
                sourceMap: isEnvProduction
                  ? shouldUseSourceMap
                  : isEnvDevelopment,
                skipLibCheck: true,
                inlineSourceMap: false,
                declarationMap: false,
                noEmit: true,
                incremental: true,
                tsBuildInfoFile: paths.appTsBuildInfoFile,
              },
            },
            context: paths.appPath,
            diagnosticOptions: {
              syntactic: true,
            },
            mode: "write-references",
            // profile: true,
          },
          issue: {
            // 这个是专门为了在 CI 测试中匹配，
            // 因为 micromatch 不匹配
            // '../cra-template-typescript/template/src/App.tsx'
            // 否则。
            include: [
              { file: "../**/src/**/*.{ts,tsx}" },
              { file: "**/src/**/*.{ts,tsx}" },
            ],
            exclude: [
              { file: "**/src/**/__tests__/**" },
              { file: "**/src/**/?(*.){spec|test}.*" },
              { file: "**/src/setupProxy.*" },
              { file: "**/src/setupTests.*" },
            ],
          },
          logger: {
            infrastructure: "silent",
          },
        }),
      !disableESLintPlugin &&

      new ESLintPlugin({
        // 插件选项
        extensions: ['ts', 'tsx'],
        context: 'src',
        exclude: 'node_modules',
      }),
        // new ESLintPlugin({
        //   // 插件选项
        //   extensions: ["ts", "tsx"],
        //   formatter: require.resolve("react-dev-utils/eslintFormatter"),
        //   eslintPath: require.resolve("eslint"),
        //   failOnError: !(isEnvDevelopment && emitErrorsAsWarnings),
        //   context: paths.appSrc,
        //   cache: true,
        //   cacheLocation: path.resolve(
        //     paths.appNodeModules,
        //     ".cache/.eslintcache"
        //   ),
        //   // ESLint 类选项
        //   cwd: paths.appPath,
        //   resolvePluginsRelativeTo: __dirname,
        //   baseConfig: {
        //     extends: [require.resolve("eslint-config-react-app/base")],
        //     rules: {
        //       ...(!hasJsxRuntime && {
        //         "react/react-in-jsx-scope": "error",
        //       }),
        //     },
        //   },
        // }),
    ].filter(Boolean),
    // 关闭性能处理，因为我们通过 FileSizeReporter 利用
    // 我们自己的提示
    performance: false,
    resolve: {
      alias: {
        // 设置别名 "@/" 指向 "src" 目录
        '@': path.resolve(__dirname, '../src'),
      },
      extensions: ['.ts', '.tsx', '.json', '.js' , '.jsx'] // 根据需要添加更多文件扩展名
    },
  };
};