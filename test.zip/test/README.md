# Agent-mobile

## 初始化项目
1. npm i
2. npm run start

## 项目样式兼容 
1. iOS Safari >= 10 和 Chrome >= 49