const dotenv = require('dotenv');
dotenv.config();

const isProduction = process.env.NODE_ENV === 'production';
// const cacheName = isProduction ? 'hb-agent-h5-resources-release' : 'hb-agent-h5-resources-test'

console.log()
module.exports = {
  globDirectory: 'dist/',
  globPatterns: ['**/*.{js,css,json,svg,png,jpg,gif}'],
  swDest: 'dist/service-worker.js',
  runtimeCaching: [
    {
      urlPattern: /.*\.(?:png|jpg|jpeg|svg|gif|js|css)$/,
      //CacheFirst 缓存优先  NetworkFirst网络优先  StaleWhileRevalidate网络缓存  NetworkOnly只使用网络资源  CacheOnly只使用缓存
      handler: 'CacheFirst',
      options: {
        cacheName: `${isProduction ? 'hb-agent-h5-resources-release' : 'hb-agent-h5-resources-test'}-${domain}`,
        expiration: {
          maxEntries: 60,
          maxAgeSeconds: 30 * 24 * 60 * 60 // 30 Days
        }
      }
    },
    {
      urlPattern: /\/version\.json$/,
      handler: 'NetworkOnly'
    }
  ],
  skipWaiting: true,
  clientsClaim: true,
  // Adding hash to cached files
  dontCacheBustURLsMatching: new RegExp('.+\\.[a-f0-9]{8}\\..+')
}
